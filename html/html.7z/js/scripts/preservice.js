$(function(){
	$(".comboeditable").eComboBox();
	$(".formvalidate").validate();
});