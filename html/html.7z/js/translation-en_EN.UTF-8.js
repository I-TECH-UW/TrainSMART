function tr(phrase) {
	return phrase;
}
