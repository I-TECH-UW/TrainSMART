if (typeof ITECH == "undefined" || !ITECH) {
    /**
     * The ITECH global namespace object.  If ITECH is already defined, the
     * existing ITECH object will not be overwritten so that defined
     * namespaces are preserved.
     * @class ITECH
     * @static
     */
    var ITECH = {};
}

