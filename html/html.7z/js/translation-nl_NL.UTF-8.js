function tr(phrase) {
	switch (phrase) {
		case 'Remove':
			return 'Verwijder';
		case 'Deleting...':
			return 'Verwijder...';
		case 'Are you sure you want to remove':
			return 'Verwijder';
		case 'Undeleting...':
			return 'Undeleting...';
		case 'Saving...':
			return "Aan het opslaan...";
		case 'Edit':
			return 'Bewerken';
		case 'Delete':
			return 'Verwijderen';
		case 'Are you sure you want to delete':
			return 'Weet u zeker dat u wilt verwijderen';
		case 'Pick a Date':
			return 'Kies een datum';
		case 'No records found.':
			return 'Geen invoeringen gevonden.';
		case 'Loading...':
			return 'Aan het laden';
		case 'You have not selected a training category for your new title.':
			return "U heeft geen training categorie gekozen voor uw nieuwe naam.";
		case 'Do you still wish to add a title without a training category associated with it?':
			return 'Wilt u nog steeds een naan toevoegen zonder een training categorie eraan verbonden?';
	}
}