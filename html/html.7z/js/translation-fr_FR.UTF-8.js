﻿function tr(phrase) {
	switch (phrase) {
		case 'Remove':
			return 'Supprimer';
		case 'Deleting...':
			return 'Suppression';
		case 'Are you sure you want to remove':
			return 'Êtes-vous sûr de vouloir supprimer';
		case 'Undeleting...':
			return 'Undeleting...';
		case 'Saving...':
			return "D'épargne";
		case 'Edit':
			return 'Modifier';
		case 'Delete':
			return 'Supprimer';
		case 'Are you sure you want to delete':
			return 'Êtes-vous sûr de vouloir supprimer';
		case 'Pick a Date':
			return 'Choisissez une date';
		case 'No records found.':
			return 'Aucun enregistrement trouvé.';
		case 'Loading...':
			return 'Chargement...';
		case 'You have not selected a training category for your new title.':
			return "Vous n\'avez pas sélectionné une catégorie de formation pour votre nouveau titre.";
		case 'Do you still wish to add a title without a training category associated with it?':
			return 'Désirez-vous encore d\'ajouter un titre sans une catégorie de formation qui lui est associé?';
	}

	return phrase;
}

