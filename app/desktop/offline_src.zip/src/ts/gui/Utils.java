package ts.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import ts.config.Config;
import ts.db.SQLiteDB;
import ts.gui.components.utils.DefaultComboBox;
import ts.gui.components.utils.IdNameCheckBox;
import ts.gui.components.utils.IdNameComboBox;
import ts.gui.components.utils.IdNameComboBoxModel;

import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;

public class Utils {
	
	private static LinkedHashMap<String, String> gui_labels = null;
	
	//returns 'phrase' from 'translation' table
	public static String getGUILabel(String key){
		try{
		if(gui_labels == null)
			gui_labels = SQLiteDB.getDBConn().getGUILabels();
		if(gui_labels != null){
			String label = gui_labels.get(key);
			if(label != null)
				return label;
		}
		return key;
		}catch(Exception e){
			System.err.println(e.getMessage());
		}
		return key;
	}
	
	public static JPanel getInfoPanel(String title){
		JPanel p = new JPanel(new GridBagLayout());
		p.setBorder (BorderFactory.createTitledBorder (BorderFactory.createEtchedBorder(), title, TitledBorder.LEFT, TitledBorder.TOP));
		p.validate();
		return p;
	}
	
	/**
	 * Add row (label and component) to a form
	 * 
	 * right_extra_space - if right space is needed
	 * component_height - value >0 is required for tall components, for normal components component_height=0
	 * 
	 */
	public static void addFormRowInfo(Container container, JLabel label, Component component, int row, Insets insets, boolean right_extra_space, int component_height){
		GridBagConstraints gbc;
		if(label != null){
			int label_position = GridBagConstraints.EAST;
			if(component_height > 0)
				label_position = GridBagConstraints.NORTHEAST;
			gbc = new GridBagConstraints(0, row, 1, 1, 0.1, 1.0, label_position, GridBagConstraints.NONE, insets, 0, 0);
			container.add(label, gbc);
		}
		if(component != null){
			gbc = new GridBagConstraints(1, row, 1, 1, 0.4, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, component_height);
			container.add(component, gbc);
		}
		if(right_extra_space){// add right extra label to make a space
			gbc = new GridBagConstraints(2, row, 1, 1, 3.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0);
			container.add(new JLabel(""), gbc);
		}
	}
	
	/**
	 * Gets form title
	 * @param title
	 * @return
	 */
	public static JLabel getFormTitle(String title){
		JLabel form_title = new JLabel(title);
		form_title.setFont(Config.__FORM_TITLE_FONT);
		return form_title;
	}
	
	public static JPanel getCheckBoxesListPanel(List<String> list, List<String> sel_list){
		JPanel p_check_boxes = new JPanel(new GridBagLayout());
		Insets insets = new Insets(2,2,2,2);
		if(list != null){
			for(int i=0; i<list.size(); i++){
				String item = list.get(i);
				JCheckBox cb = new JCheckBox(item);
				cb.setSelected(sel_list.contains(item)?true:false);
				addFormRowInfo(p_check_boxes, null, cb, i, insets, false, 0);
			}
		}
		return p_check_boxes;
	}
	
	public static JPanel getCheckBoxesWithIdsListPanel(List<String[]> list, List<String[]> sel_list){
		JPanel p_check_boxes = new JPanel(new GridBagLayout());
		Insets insets = new Insets(2,2,2,2);
		if(list != null){
			for(int i=0; i<list.size(); i++){
				IdNameCheckBox cb = new IdNameCheckBox(list.get(i)[0], list.get(i)[1]);
				if(sel_list != null){
					for(int j=0; j<sel_list.size(); j++){
						if(sel_list.get(j)[1].equals(cb.getText()) && sel_list.get(j)[0].equals(cb.getId())){
							cb.setSelected(true);
						}
					}
				}
				addFormRowInfo(p_check_boxes, null, cb, i, insets, false, 0);
			}
		}
		return p_check_boxes;
	}
	
	/*
	 * Validate if value not empty
	 */
	public static boolean validateValueNotEmpty(Component parent, String label, String value){
		if(value == null || value.trim().equals("")){
			JOptionPane.showMessageDialog(parent, label + " cannot be empty.", "Value validation error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	
	/*
	 * Validate if value not empty
	 */
	public static boolean validateNotNullObject(Component parent, String label, Object value){
		if(value == null){
			JOptionPane.showMessageDialog(parent, label + " cannot be empty.", "Value validation error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	
	/*
	 * Validate if value is decimal number
	 */
	public static boolean validateDecimalNumber(Component parent, String label, String value){
		try{
			Double.parseDouble(value);
			return true;
		}catch(Exception e){
			JOptionPane.showMessageDialog(parent, label + " cannot be empty and must be number.", "Value validation error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static JDialog getDialog(String title, Component parent, int width, int height, Component content, boolean modal, boolean resizable){
		JDialog dialog = new JDialog();
			dialog.setTitle(title);
			dialog.setSize(width, height);
			dialog.setLocationRelativeTo(parent);
			dialog.setModal(modal);
			dialog.add(content);
			dialog.setResizable(resizable);
		return dialog;
	}
	
	public static JDateChooser getDateChooser(Date date, boolean editable, boolean show_calendar_button){
		JDateChooser date_chooser = new JDateChooser();
		if(date != null)
			date_chooser.setDate(date);
		date_chooser.getDateEditor().setEnabled(editable);
		date_chooser.getCalendarButton().setVisible(show_calendar_button);
		((JTextFieldDateEditor)date_chooser.getDateEditor()).setDisabledTextColor(Color.black);
		date_chooser.setForeground(Color.white);
		return date_chooser;
	}
	
	/*
	 * Get current date with format yyyy-MM-dd
	 */
	public static String getCurrentDate(){
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    return dateFormat.format(new Date());
	}
	
	/*
	 * Get current date with format yyyy-MM-dd
	 */
	public static String getCurrentDateTime(){
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    return dateFormat.format(new Date());
	}

	
	/*
	 * Get current date with format yyyy-MM-dd
	 */
	public static String getDate(Date date){
		if(date == null)
			return "";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    return dateFormat.format(date);
	}
	
	public static Date getDate(String str) throws Exception{
		if(str == null || str.trim().equals("") || str.trim().equals("0000-00-00"))
			return null;
		try{
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		return format.parse(str);
		}catch(Exception e){
			try{
				DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				return format.parse(str);
			}catch(Exception ex){
				e.printStackTrace();
				throw new Exception("ERROR: Wrong date string format: " + str + ". Date string format must be yyyy-MM-dd.");
			}	
		}
	}
	
	public static int getAge(Date data_of_birth) throws Exception{
		if(data_of_birth == null)
			return 0;
		SimpleDateFormat simpleDateformat=new SimpleDateFormat("yyyy");
		return Integer.parseInt(simpleDateformat.format(Utils.getDate(Utils.getCurrentDate())))- Integer.parseInt(simpleDateformat.format(data_of_birth));
	}
	
	public static int getYears(Date start_date, Date end_date) throws Exception{
		if(start_date == null)
			throw new Exception("Start date is NULL.");
		if(end_date == null)
			throw new Exception("End date is NULL.");
		SimpleDateFormat simpleDateformat=new SimpleDateFormat("yyyy");
		int years = Integer.parseInt(simpleDateformat.format(end_date))- Integer.parseInt(simpleDateformat.format(start_date));
		if(years <0)
			return 0;
		return years;
	}
	
	public static JComboBox getComboBoxOfNames(List<String> db_data, String default_item){
		JComboBox cb = new JComboBox();
		if(db_data != null)
			cb = new JComboBox(db_data.toArray());
		if(default_item != null)
		cb.insertItemAt(default_item, 0);
		return cb;
	}
	
	public static JComboBox getComboBoxOfNameWithIds(List<String[]> db_data, String default_item) throws Exception{
		JComboBox cb = new JComboBox(new IdNameComboBoxModel(db_data, default_item));
		return cb;
	}
	
	public static void selectComboBoxNameId(IdNameComboBox cb, int id, String default_value){
		cb.setSelectedItem(default_value);
		cb.setSelectedIdName(id);
	}
	
	public static void selectComboBoxItem(DefaultComboBox cb, String value, String default_value){
		cb.setSelectedItem(default_value);
		if(value != null && !value.equals(""))
			cb.setSelectedItem(value);
	}
	
	public static JLabel getRequiredLabel(String label){
		return new JLabel("<html><font color='red'>*</font> " + label + "</html>");
	}
	
	public static void printRawData(LinkedHashMap<String, String> data){
		Iterator<String> keySetIterator = data.keySet().iterator();
		while(keySetIterator.hasNext()){
		  String key = keySetIterator.next();
		  System.out.println(key + "=>" + data.get(key));
		}
		System.out.println("\n\n");
	}
	
	public static String wrapTableHeader(String header){
		if(header == null)
			return "";
		return "<html>" + String.join("<br>", header.trim().split("\\s+")) + "</html>";
	}
	
	public static String getCurrentYear(){
		Calendar now = Calendar.getInstance();
		int year = now.get(Calendar.YEAR);
		return String.valueOf(year);
	}
	
	public static void  main(String[] args){
		String str = "aaa    bbb";
		System.out.println(wrapTableHeader(str));
	}


}
