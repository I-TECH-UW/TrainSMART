package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import ts.db.SQLiteDB;
import ts.ds.Cohort;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultTable;
import ts.gui.components.utils.FirstColumnCheckBoxTableModel;

public class CohortClassesAssociatedTablePanel extends TablePanel{
	
	JComponent parent = null;
	Cohort cohort = null;
	
	public CohortClassesAssociatedTablePanel(Cohort cohort, JComponent parent, int width, int height) throws Exception{
		this.parent = parent;
		this.cohort = cohort;
		if(cohort.getId() == 0){
			throw new Exception("Cohort id is undefined.");
		}
		
		List<LinkedHashMap<String, String>> results = SQLiteDB.getDBConn().getAllClassesAssociatedWithCohort(String.valueOf(cohort.getId()));
		final List<String> associated_classes_ids = new ArrayList<String>();
		//prepare data for table
		Object[][] data = new Object[results.size()][5];
		for(int i=0; i<results.size(); i++){
			associated_classes_ids.add(results.get(i).get("id"));
			data[i][0] = Integer.parseInt(results.get(i).get("id"));
			data[i][1] = results.get(i).get("classname");
			String first_name = results.get(i).get("first_name");
			String last_name = results.get(i).get("last_name");
			data[i][2] = first_name != null?first_name:"" + " " + last_name != null?last_name:"";
			data[i][3] = results.get(i).get("startdate");
			data[i][4] = results.get(i).get("enddate");
		}
		//draw table
		String[] columnNames = {"ID", "Class Name", "Tutor", "Start date", "End date"};
		//set model with correct column sorting type
		DefaultTableModel model = new DefaultTableModel(data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		        if (column == 0 ) {//columns are sorted as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		
		DefaultTable table = new DefaultTable(model, true);
		table.getColumnModel().getColumn(0).setMaxWidth(50);
		
		JButton b_update_classes = new JButton("Update associated classes");
		b_update_classes.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
					getDialogToUpdateAssociatedClasses(associated_classes_ids);
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(parent, "Cannot get classes for this cohort\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
		    }
		});
		init("Classes associated with the Cohort", table, b_update_classes, width, height);
	}
	
private void getDialogToUpdateAssociatedClasses(List<String> associatd_classes) throws Exception{
		
		JPanel p_main = new JPanel(new BorderLayout());
		final JDialog dialog = Utils.getDialog("Update classes", parent, 500, 500, p_main, true, false);
		
		List<LinkedHashMap<String, String>> results_all_classes = SQLiteDB.getDBConn().getAllClasses();
		//prepare data for table
		Object[][] data = new Object[results_all_classes.size()][6];
		for(int i=0; i<results_all_classes.size(); i++){
			data[i][0] = associatd_classes.contains(results_all_classes.get(i).get("id"))?Boolean.TRUE:Boolean.FALSE;
			data[i][1] = Integer.parseInt(results_all_classes.get(i).get("id"));
			data[i][2] = results_all_classes.get(i).get("classname");
			String first_name = results_all_classes.get(i).get("first_name");
			if(first_name == null){
				first_name = "";
			}
			String last_name = results_all_classes.get(i).get("last_name");
			if(last_name == null){
				last_name = "";
			}
			data[i][3] = first_name + " " + last_name;
			data[i][4] = results_all_classes.get(i).get("startdate");
			data[i][5] = results_all_classes.get(i).get("enddate");
		}
		//draw table
		String[] columnNames = {"", "ID", "Class Name", "Tutor", "Start date", "End date"};
		final FirstColumnCheckBoxTableModel model = new FirstColumnCheckBoxTableModel(columnNames, data);
		DefaultTable table = new DefaultTable(model, true);
		JScrollPane scrollPane = new JScrollPane(table);
		//set column width
		table.getColumnModel().getColumn(0).setMaxWidth(30);
		table.setRowHeight(table.getRowHeight() + 10);
		p_main.add(scrollPane, BorderLayout.WEST);
		
		JPanel p_button = new JPanel(new BorderLayout());
		JButton b_update = new JButton("Update");
		b_update.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
					List<String> true_cb = model.getCheckBoxesValues(1, FirstColumnCheckBoxTableModel.__CHECK_BOXES_STRING_VALUE_TRUE);
					List<String> false_cb = model.getCheckBoxesValues(1, FirstColumnCheckBoxTableModel.__CHECK_BOXES_STRING_VALUE_FALSE);
					SQLiteDB.getDBConn().updateAllClassesAssociatedWithCohort(String.valueOf(cohort.getId()), true_cb, false_cb);
					JOptionPane.showMessageDialog(parent, "Classes associated with this cohort are updated in database", "Message", JOptionPane.INFORMATION_MESSAGE);
					MainPanel.getInstance().showCohortEditPage(String.valueOf(cohort.getId()));
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(parent, "Cannot get classes for this cohort\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}finally{
					dialog.dispose();
				}
		    }
		});
		p_button.add(b_update, BorderLayout.EAST);
		p_main.add(p_button, BorderLayout.SOUTH);
		
		dialog.setVisible(true);
	}

}
