package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.toedter.calendar.JDateChooser;

import ts.config.Config;
import ts.db.SQLiteDB;
import ts.ds.Cohort;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultTable;
import ts.gui.components.utils.DeleteButtonTableModel;
import ts.gui.components.utils.FacilityWithLocationComboBoxModel;
import ts.gui.components.utils.TableButtonMouseListener;
import ts.gui.components.utils.TableButtonRenderer;
import ts.gui.components.utils.TutorComboBoxModel;

public class CohortClinicalTablePanel extends TablePanel{
	
	private static final String __LABEL_CLINICAL_NAME = "Name";
	private static final String __LABEL_CLINICAL_DATE = "Date";
	private static final String __LABEL_CLINICAL_HOURS = "Hours Required";
	private static final String __LABEL_CLINICAL_FACILITY = "Facility";
	private static final String __LABEL_CLINICAL_TUTOR = "Advisor";
	private static final String __ITEM_SELECT = "-- SELECT --";
	
	private static final String __MODE_ADD = "Add";
	private static final String __MODE_EDIT = "Edit";
		
		JComponent parent = null;
		Cohort cohort = null;
		
		public CohortClinicalTablePanel(Cohort cohort, JComponent parent, int width, int height) throws Exception{
			this.parent = parent;
			this.cohort = cohort;
			if(cohort.getId() == 0){
				throw new Exception("Cohort id is undefined.");
			}
			
			List<LinkedHashMap<String, String>> results = SQLiteDB.getDBConn().getAllClinicalForCohort(String.valueOf(cohort.getId()));
			//prepare data for table
			Object[][] data = new Object[results.size()][7];
			for(int i=0; i<results.size(); i++){
				data[i][0] = Integer.parseInt(results.get(i).get("id"));
				data[i][1] = results.get(i).get("practicumname");
				data[i][2] = results.get(i).get("practicumdate");
				data[i][3] = results.get(i).get("facility_name");
				String fn = results.get(i).get("first_name");
				if(fn == null)
					fn = "";
				String ln = results.get(i).get("last_name");
				if(ln == null)
					ln = "";
				data[i][4] = fn + " " + ln;
				data[i][5] = results.get(i).get("hoursrequired");
				data[i][6] = "Delete";
			}
			//draw table
			String[] columnNames = {"ID", "Name", "Date", "Facility", "Advisor", "Hours Required", ""};
			DefaultTable table = new DefaultTable(new DeleteButtonTableModel(columnNames,data, 6, String.valueOf(cohort.getId()), MainPanel.__DELETE_CLINICAL_ALLOCATION_FROM_COHORT), true);
			table.getColumnModel().getColumn(0).setMaxWidth(30);
			table.getColumnModel().getColumn(6).setMaxWidth(90);
			table.getColumn("").setCellRenderer(new TableButtonRenderer());
			table.addMouseListener(new TableButtonMouseListener(table){
				public void mouseClicked(MouseEvent e) {
					int column = table.getColumnModel().getColumnIndexAtX(e.getX());
					int row    = e.getY()/table.getRowHeight(); 
					if(column == 6){
						if (row < table.getRowCount() && row >= 0 && column < table.getColumnCount() && column >= 0) {
							Object value = table.getValueAt(row, column);
							if (value instanceof JButton) {
								((JButton)value).doClick();
							}
						}
					}else{
						try{
							getDialogEditPracticum(__MODE_EDIT, table.getValueAt(table.getSelectedRow(), 0).toString(),
									table.getValueAt(table.getSelectedRow(), 1).toString(),
									table.getValueAt(table.getSelectedRow(), 2).toString(),
									table.getValueAt(table.getSelectedRow(), 3).toString(),
									table.getValueAt(table.getSelectedRow(), 4).toString(),
									table.getValueAt(table.getSelectedRow(), 5).toString());
						}catch(Exception ex){
							JOptionPane.showMessageDialog(CohortClinicalTablePanel.this, "Cannot open edit licence dialog.\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			});
			
			
			JButton b_add_practicum = new JButton("Add a practicum");
			b_add_practicum.addActionListener( new ActionListener(){
				@Override
			    public void actionPerformed(ActionEvent e){
					try{
						getDialogEditPracticum(__MODE_ADD,null, null, null, null, null, null);
					}catch(Exception ex){
						ex.printStackTrace();
					}
			    }
			});
			init("Clinical Allocation", table, b_add_practicum, width, height);
		}
		
		private void getDialogEditPracticum(String mode, String id, String name, String date, String facility, String advisor, String hours) throws Exception{
			JPanel p_main = new JPanel(new BorderLayout());
			final JDialog dialog = Utils.getDialog(mode + " a practicum", parent, 600, 250, p_main, true, false);
			p_main.add(new JLabel("All form fields are required"), BorderLayout.NORTH);
			
			JPanel p_content = new JPanel(new GridBagLayout());
			Insets insets = new Insets(2,2,2,2);
			int row = 0;
			JTextField tf_name = new JTextField();
			tf_name.setText(name == null?"":name);
			tf_name.setPreferredSize(new Dimension(250, 25));
			Utils.addFormRowInfo(p_content, Utils.getRequiredLabel(__LABEL_CLINICAL_NAME), tf_name, row++, insets, true, 0);
			
			JDateChooser tf_date = Utils.getDateChooser(null, false, true);
			if(date != null){
				tf_date.setDate(Utils.getDate(date));
			}
			Utils.addFormRowInfo(p_content, Utils.getRequiredLabel(__LABEL_CLINICAL_DATE), tf_date, row++, insets, true, 0);
			
			List<LinkedHashMap<String, String>> db_facility = SQLiteDB.getDBConn().getAllFacilityWithLocation();
			JComboBox cb_facility = new JComboBox(new FacilityWithLocationComboBoxModel(db_facility));
			if(facility != null){
				cb_facility.getModel().setSelectedItem(facility);
			}
			Utils.addFormRowInfo(p_content, Utils.getRequiredLabel(__LABEL_CLINICAL_FACILITY), cb_facility, row++, insets, true, 0);
			
			List<LinkedHashMap<String, String>> db_tutors = SQLiteDB.getDBConn().getAllTutors();
			JComboBox cb_tutors = new JComboBox(new TutorComboBoxModel(db_tutors));
			if(advisor != null){
				cb_tutors.getModel().setSelectedItem(advisor);
			}
			Utils.addFormRowInfo(p_content, Utils.getRequiredLabel(__LABEL_CLINICAL_TUTOR), cb_tutors, row++, insets, true, 0);
			
			JTextField tf_hours = new JTextField();
			tf_hours.setText(hours == null?"":hours);
			tf_hours.setPreferredSize(new Dimension(250, 25));
			Utils.addFormRowInfo(p_content, Utils.getRequiredLabel(__LABEL_CLINICAL_HOURS), tf_hours, row++, insets, true, 0);
			
			p_main.add(p_content, BorderLayout.CENTER);
			
			JPanel p_buttons = new JPanel();
			JButton b_save = new JButton("Save");
			b_save.addActionListener( new ActionListener(){
				@Override
			    public void actionPerformed(ActionEvent e){
					try{
						if(!Utils.validateValueNotEmpty(dialog, __LABEL_CLINICAL_NAME, tf_name.getText()))
							return;
						if(!Utils.validateNotNullObject(dialog, __LABEL_CLINICAL_DATE, tf_date.getDate()))
							return;
						if(cb_facility.getSelectedItem().equals(FacilityWithLocationComboBoxModel.__DEFAULT_ITEM_SELECT)){
							JOptionPane.showMessageDialog(CohortClinicalTablePanel.this, "Facility cannot be empty.", "Value validation error", JOptionPane.ERROR_MESSAGE);
							return;
						}
						if(cb_tutors.getSelectedItem().equals(FacilityWithLocationComboBoxModel.__DEFAULT_ITEM_SELECT)){
							JOptionPane.showMessageDialog(CohortClinicalTablePanel.this, "Advisor cannot be empty.", "Value validation error", JOptionPane.ERROR_MESSAGE);
							return;
						}
						if(!Utils.validateDecimalNumber(dialog, __LABEL_CLINICAL_HOURS, tf_hours.getText()))
							return;
						if(mode.equals(__MODE_ADD)){
						SQLiteDB.getDBConn().addClinicalForCohort(String.valueOf(cohort.getId()), tf_name.getText(), tf_date.getDate(), 
								((FacilityWithLocationComboBoxModel)cb_facility.getModel()).getSelectedFacilityId(), ((TutorComboBoxModel)cb_tutors.getModel()).getSelectedTutorId(),  tf_hours.getText());
						}else if(mode.equals(__MODE_EDIT)){
							SQLiteDB.getDBConn().editClinicalForCohort(id, tf_name.getText(), tf_date.getDate(), 
									((FacilityWithLocationComboBoxModel)cb_facility.getModel()).getSelectedFacilityId(), ((TutorComboBoxModel)cb_tutors.getModel()).getSelectedTutorId(),  tf_hours.getText());
						}
						MainPanel.getInstance().showCohortEditPage(String.valueOf(cohort.getId()));
						dialog.dispose();
					}catch(Exception ex){
						ex.printStackTrace();
						JOptionPane.showMessageDialog(parent, "Cannot add clinical allocation for this cohort\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					}
			    }
			});
			p_buttons.add(b_save);
			p_main.add(p_buttons, BorderLayout.SOUTH);
			dialog.setVisible(true);
		}

}
