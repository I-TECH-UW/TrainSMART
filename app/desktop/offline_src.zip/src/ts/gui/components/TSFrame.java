package ts.gui.components;

import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

public class TSFrame extends JFrame{
	
	MainPanel main_panel = MainPanel.getInstance();
	
	 public TSFrame() {
		 
		 try {
			    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
			        if ("Nimbus".equals(info.getName())) {
			            UIManager.setLookAndFeel(info.getClassName());
			            break;
			        }
			    }
			} catch (Exception e) {
				System.out.println("If Nimbus is not available, you can set the GUI to another look and feel");   
			}
		 
		 	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 
			setTitle("TrainSMART");
			setSize(600,150); 
			setLocation(100,100); 
			Container contentPane = getContentPane();
			
			TSLoginPanel login_panel = new TSLoginPanel(this);
			contentPane.add( login_panel); 
			
			//for development addMainPanel();	
			
		  }
	 
	 public void addMainPanel(){
		 Container contentPane = getContentPane();
		 contentPane.removeAll();
		 contentPane.add( main_panel);
		 setJMenuBar(new TSTopMenuBar(TSTopMenuBar.__MODE_PRE_SERVICE));
		 setSize(900,700);
		 validate();
           repaint();
	 }
		
		  public static void main(String[] args) {
		    JFrame f = new TSFrame();
		    f.setVisible(true);
		  }

}
