package ts.gui.components;

import java.awt.BorderLayout;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import ts.config.Config;
import ts.db.SQLiteDB;
import ts.gui.components.utils.DefaultTable;

public class CohortSearchPagePanel extends JPanel{
	
	public CohortSearchPagePanel() throws Exception{
		//get data from database
		List<LinkedHashMap<String, String>> results = SQLiteDB.getDBConn().getAllCohortsInfo();
		
		//draw table
		String[] columnNames = {"ID", "Name", "Start Date", "Graduation Date", "Institution", "Number of Members", "Cadre"};
		
		//prepare data for table
				Object[][] data = new Object[results.size()][7];
				for(int i=0; i<results.size(); i++){
					data[i][0] = new Integer(results.get(i).get("id"));
					data[i][1] = results.get(i).get("cohortname");
					data[i][2] = results.get(i).get("startdate");
					data[i][3] = results.get(i).get("graddate");
					data[i][4] = results.get(i).get("institutionname");
					data[i][5] = new Integer(results.get(i).get("students_count"));
					data[i][6] = results.get(i).get("cadrename");
				}
				
		//set model with correct column sorting type
		DefaultTableModel model = new DefaultTableModel(data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		        if (column == 0 || column == 5) {//first and fifth columns sort as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		final DefaultTable table = new DefaultTable(model, true);
		JScrollPane scrollPane = new JScrollPane(table);
		table.setFillsViewportHeight(true);
		table.setAutoCreateRowSorter(true);
		//set column width
		table.getColumnModel().getColumn(0).setMaxWidth(50);
		//make table row click
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
	        public void valueChanged(ListSelectionEvent event) {
	        	MainPanel.getInstance().showCohortEditPage(table.getValueAt(table.getSelectedRow(), 0).toString());
	        }
	    });
				
		table.setSelectionBackground(Config.__TABLE_SELECTION_BG_COLOR);
		setLayout(new BorderLayout());
		add(table.getTableHeader(), BorderLayout.PAGE_START);
		add(scrollPane, BorderLayout.CENTER);
	}

}
