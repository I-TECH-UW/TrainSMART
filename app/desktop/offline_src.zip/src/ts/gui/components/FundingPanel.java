package ts.gui.components;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FundingPanel extends JPanel{
	
	String fund_source_id = "0";
	JCheckBox cb_fund_name = new JCheckBox();
	JTextField tf_fund_amount = new JTextField();
	
	public FundingPanel(String id, String name){
		fund_source_id = id;
		cb_fund_name.setText(name); 
		cb_fund_name.setPreferredSize(new Dimension(300, 25));
		setLayout(new GridBagLayout());
		tf_fund_amount.setToolTipText("Funding amount");
		Insets insets = new Insets(2,2,2,2);
		add(cb_fund_name, new GridBagConstraints(0, 0, 1, 1, 0.1, 1.0, GridBagConstraints.WEST, GridBagConstraints.NONE, insets, 0, 0));
		add(tf_fund_amount, new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0));
	}
	
	public void setAmount(String funding_amount){
		cb_fund_name.setSelected(true);
		tf_fund_amount.setText(String.valueOf(funding_amount));		
	}
	
	public String getFundingSourceId(){
		return fund_source_id;
	}
	
	public String getFundingName(){
		return cb_fund_name.getText();
	}
	
	public String getFundingAmount(){
		return tf_fund_amount.getText();
	}
	
	public boolean isSelected(){
		return cb_fund_name.isSelected();
	}

}
