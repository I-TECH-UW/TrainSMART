package ts.gui.components;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class TSTopMenuBar extends JMenuBar{
	
	public static final int __MODE_IN_SERVICE = 0;
	public static final int __MODE_PRE_SERVICE = 1;
	
	int mode = 0;
	
	public TSTopMenuBar(int mode){
		
		this.mode = mode;
		
		MouseListener ml = new MouseListener(){
		    public void mouseEntered(MouseEvent e) {
		    	((JMenu)e.getSource()).doClick();
		    }
		    public void mouseClicked(MouseEvent e) {}
		    public void mousePressed(MouseEvent e) {}
		    public void mouseReleased(MouseEvent e) {}
		    public void mouseExited(MouseEvent e) {} 
		};
		
		//add menus depends on mode
		if(mode == __MODE_PRE_SERVICE){
			addHomeMenu();
			addInstitutionMenu();
			addCohortMenu();
			addPeopleMenu();
		}
		
		for (Component c: getComponents()) {
		    if (c instanceof JMenu){
		        c.addMouseListener(ml);
		    }
		}
	}
	
	private void addHomeMenu(){
		JMenu home_menu = new JMenu("Home");
		home_menu.addMouseListener(new MouseListener() {
	        @Override
	        public void mouseReleased(MouseEvent e) {}
	        @Override
	        public void mousePressed(MouseEvent e) {}
	        @Override
	        public void mouseExited(MouseEvent e) {}
	        @Override
	        public void mouseEntered(MouseEvent e) {}
	        @Override
	        public void mouseClicked(MouseEvent e) {
	        	MainPanel.getInstance().showHomePage();
	        }
	    });
		add(home_menu);
	}
	
	private void addInstitutionMenu(){
		JMenu inst_menu = new JMenu("Institution");
		JMenuItem inst_add = new JMenuItem("Add Institution");
		inst_add.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				MainPanel.getInstance().showInstituteAddPage();
		    }
		});
		JMenuItem inst_edit = new JMenuItem("Edit Institution");
		inst_edit.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				MainPanel.getInstance().showInstituteSearchPage();
		    }
		});
		inst_menu.add(inst_add);
		inst_menu.add(inst_edit);
		add(inst_menu);
	}
	
	private void addCohortMenu(){
		JMenu cohort_menu = new JMenu("Cohort");
		JMenuItem cohort_add = new JMenuItem("Add Cohort");
		cohort_add.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				MainPanel.getInstance().showCohortAddPage();
		    }
		});
		JMenuItem cohort_edit = new JMenuItem("Edit Cohort");
		cohort_edit.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				MainPanel.getInstance().showCohortSearchPage();
		    }
		});
		cohort_menu.add(cohort_add);
		cohort_menu.add(cohort_edit);
		add(cohort_menu);
	}
	
	private void addPeopleMenu(){
		JMenu people_menu = new JMenu("People");
		JMenuItem people_add = new JMenuItem("Add People");
		people_add.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				MainPanel.getInstance().showPeopleAddPage();
		    }
		});
		JMenuItem people_edit = new JMenuItem("Edit People");
		people_edit.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				MainPanel.getInstance().showPersonSearchPage();
		    }
		});
		people_menu.add(people_add);
		people_menu.add(people_edit);
		add(people_menu);
	}

}
