package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import ts.db.SQLiteDB;
import ts.ds.Person;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultTable;


public class StudentClinicalAllocationTablePanel extends TablePanel{
	
	JComponent parent = null;
	Person person = null;
	
	public StudentClinicalAllocationTablePanel(Person person, JComponent parent, int width, int height) throws Exception{
		this.parent = parent;
		this.person = person;
//		if(person.getStudent().getStudent_id() == 0){
//			throw new Exception("Student id is undefined.");
//		}
		List<LinkedHashMap<String, String>> student_clinical_results = SQLiteDB.getDBConn().getStudentClinical(person.getStudent());
		String[] columnNames = {"ID", Utils.wrapTableHeader("Practicum Name"), "Date", "Facility", "Advisor", Utils.wrapTableHeader("Hours required"), Utils.wrapTableHeader("Hours completed"), "Grade"};
		//prepare data for table
		Object[][] student_clinical_data = new Object[student_clinical_results.size()][8];
		for(int i=0; i<student_clinical_results.size(); i++){
			student_clinical_data[i][0] = Integer.parseInt(student_clinical_results.get(i).get("id"));
			student_clinical_data[i][1] = student_clinical_results.get(i).get("practicumname");
			student_clinical_data[i][2] = student_clinical_results.get(i).get("practicumdate");
			student_clinical_data[i][3] = student_clinical_results.get(i).get("facility_name");
			student_clinical_data[i][4] = student_clinical_results.get(i).get("first_name") + " " + student_clinical_results.get(i).get("last_name");
			student_clinical_data[i][5] = student_clinical_results.get(i).get("hoursrequired");
			student_clinical_data[i][6] = student_clinical_results.get(i).get("hourscompleted");
			student_clinical_data[i][7] = student_clinical_results.get(i).get("grade");
		}
		DefaultTableModel model = new DefaultTableModel(student_clinical_data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		        if (column == 0 ) {//columns are sorted as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		
		DefaultTable table = new DefaultTable(model, true);
		table.getColumnModel().getColumn(0).setMaxWidth(30);
		
		JButton b_update_clinical = new JButton("Update Clinical Allocation");
		b_update_clinical.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
				getDialogUpdateClinical(student_clinical_results);
				}catch(Exception ex){
					ex.printStackTrace();
				}
		    }
		});
		init("Clinical Allocation", table, b_update_clinical, width, height);
	}
	
private void getDialogUpdateClinical(List<LinkedHashMap<String, String>> student_clinical_results) throws Exception{
		
		JPanel p_main = new JPanel(new BorderLayout());
		final JDialog dialog = Utils.getDialog("Update Clinical Allocation", parent, 800, 500, p_main, true, false);
		String[] columnNames = {"ID", Utils.wrapTableHeader("Practicum Name"), Utils.wrapTableHeader("Practicum Date"), Utils.wrapTableHeader("Hours required"), 
				Utils.wrapTableHeader("Hours completed"), "Grade"};
		
		//prepare data for table
		Object[][] student_clinical_data = new Object[student_clinical_results.size()][6];
		for(int i=0; i<student_clinical_results.size(); i++){
			student_clinical_data[i][0] = Integer.parseInt(student_clinical_results.get(i).get("id"));
			student_clinical_data[i][1] = student_clinical_results.get(i).get("practicumname");
			student_clinical_data[i][2] = student_clinical_results.get(i).get("practicumdate");
			student_clinical_data[i][3] = student_clinical_results.get(i).get("hoursrequired");
			student_clinical_data[i][4] = student_clinical_results.get(i).get("hourscompleted");
			student_clinical_data[i][5] = student_clinical_results.get(i).get("grade");
		}
		//draw table
		//set model with correct column sorting type
		DefaultTableModel model = new DefaultTableModel(student_clinical_data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		    	if (column == 0 ) {//columns are sorted as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		
		DefaultTable table = new DefaultTable(model, true){
			public boolean isCellEditable(int row, int column) {
				if(column == 4 || column == 5)
					return true;
				return false;
			}};
		table.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);	//take value even cell focused
		table.getColumnModel().getColumn(0).setMaxWidth(30);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(800, 500));
		p_main.add(scrollPane, BorderLayout.WEST);
		
		JPanel p_button = new JPanel(new BorderLayout());
		JButton b_update = new JButton("Update");
		b_update.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
					List<LinkedHashMap<String, String>> student_classes_to_update = new ArrayList<LinkedHashMap<String, String>>();
					for(int i=0; i<model.getRowCount(); i++){
						LinkedHashMap<String, String> class_info = new LinkedHashMap<String, String>();
						class_info.put("practicum_id", model.getValueAt(i, 0).toString());
						class_info.put("grade", model.getValueAt(i, 5).toString());
						class_info.put("hours_completed", model.getValueAt(i, 4).toString());
						student_classes_to_update.add(class_info);
					}
					SQLiteDB.getDBConn().updateStudentClinical(student_classes_to_update, person.getStudent());
					JOptionPane.showMessageDialog(parent, "Students clinical allocation is updated in database", "Message", JOptionPane.INFORMATION_MESSAGE);
					MainPanel.getInstance().showPersonEditPage(String.valueOf(person.getPersonId()), PersonEditPagePanel.__SELECT_NEW_PERSON_TYPE_STUDENT);
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(parent, "Cannot update students clinical allocation\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}finally{
					dialog.dispose();
				}
		    }
		});
		p_button.add(b_update, BorderLayout.EAST);
		p_main.add(p_button, BorderLayout.SOUTH);
		
		dialog.setVisible(true);
	}

}
