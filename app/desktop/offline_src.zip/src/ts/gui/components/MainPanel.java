package ts.gui.components;

import java.awt.BorderLayout;
import java.util.LinkedHashMap;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import ts.config.Config;
import ts.db.SQLiteDB;

public class MainPanel extends JPanel{
	
	public static final int __DELETE_LICENSE_FROM_COHORT = 0;
	public static final int __DELETE_CLINICAL_ALLOCATION_FROM_COHORT = 1;
	
	private JPanel center_panel = new JPanel(new BorderLayout());
	private BannerPanel banner_panel = new BannerPanel("");
	
	private static MainPanel main_panel = null;
	
	private MainPanel(){
		this.setLayout(new BorderLayout());
		
		this.add(banner_panel, BorderLayout.NORTH);
		this.add(new TSBottomBar(), BorderLayout.SOUTH);
		
		JScrollPane scrollPane = new JScrollPane(center_panel);
		
		this.add(scrollPane, BorderLayout.CENTER);
		
		showHomePage();
	}
	
	public static MainPanel getInstance(){
		if(main_panel == null)
			main_panel = new MainPanel();
		return main_panel;
	}
	
	private void showMainPanelContent(String title, JPanel panel){
		banner_panel.setTitle(title);
		center_panel.removeAll();
		center_panel.add(panel, BorderLayout.CENTER);
	}
	
	public void showHomePage(){
		try{
		showMainPanelContent("Home", new HomePagePanel());
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void showInstituteSearchPage(){
		try{
		showMainPanelContent("All Institutions", new InstitutionSearchPagePanel());
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void showInstituteEditPage(String id){
		try{
		showMainPanelContent("View/Edit Institution Record", new InstitutionEditPagePanel(id));
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void showInstituteAddPage(){
		try{
		showMainPanelContent("Add New Institution", new InstitutionEditPagePanel(null));
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void showCohortSearchPage(){
		try{
		showMainPanelContent("All Cohorts", new CohortSearchPagePanel());
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void showCohortEditPage(String id){
		try{
		showMainPanelContent("View/Edit Cohort Record", new CohortEditPagePanel(id));
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void showCohortAddPage(){
		try{
		showMainPanelContent("Add Cohort", new CohortEditPagePanel(null));
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void showPeopleAddPage(){
		try{
			showMainPanelContent("Add a New Student or Tutor Record", new PersonEditPagePanel(null, null));
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void showPersonSearchPage(){
		try{
		showMainPanelContent("All Persons", new PersonSearchPagePanel());
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void showPersonEditPage(String id, String type){
		try{
			showMainPanelContent("View/Edit " + type + "'s Record", new PersonEditPagePanel(id, type));
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(MainPanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	
	public void doAction(int mode, String[] params){
		if(mode == __DELETE_LICENSE_FROM_COHORT){
			try{
				//params[0] - cohort_id, params[1] - license_id,
				if(JOptionPane.showConfirmDialog(this, "Do you want to delete the license with id " + params[1] + " from this cohort?",
				        "Confirmation", JOptionPane.OK_CANCEL_OPTION) == 0){
						SQLiteDB.getDBConn().deleteLicenseForCohort(params[1]);
						JOptionPane.showMessageDialog(this, "License with id " + params[1] + " is deleted from this cohort." , "Message", JOptionPane.INFORMATION_MESSAGE);
				}
				MainPanel.getInstance().showCohortEditPage(params[0]);
			}catch(Exception e){
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, "Cannot delete license with id " + params[1] + " for this cohort\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
		}else if(mode == __DELETE_CLINICAL_ALLOCATION_FROM_COHORT){
			try{
				//params[0] - cohort_id, params[1] - clinical_id,
				if(JOptionPane.showConfirmDialog(this, "Do you want to delete the clinical allocation with id " + params[1] + " from this cohort?",
				        "Confirmation", JOptionPane.OK_CANCEL_OPTION) == 0){
						SQLiteDB.getDBConn().deleteClinicalForCohort(params[1]);
						JOptionPane.showMessageDialog(this, "Clinical allocation with id " + params[1] + " is deleted from this cohort." , "Message", JOptionPane.INFORMATION_MESSAGE);
				}
				MainPanel.getInstance().showCohortEditPage(params[0]);
			}catch(Exception e){
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, "Cannot delete clinical allocation with id " + params[1] + " for this cohort\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
		}else{
			JOptionPane.showMessageDialog(MainPanel.this, "No action selected for mode:" + mode, "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	

}
