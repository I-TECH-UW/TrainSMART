package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ts.db.SQLiteDB;
import ts.ds.Cohort;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultComboBox;
import ts.gui.components.utils.IdNameComboBox;

import com.toedter.calendar.JDateChooser;

public class CohortEditPagePanel extends JPanel{
	private static final String __LABEL_COHORT_NAME_ = "Cohort Name";
	private static final String __ITEM_SELECT = "--select--";
	
	Cohort cohort;
	
	JTextField tf_cohort_id = new JTextField();
	JTextField tf_cohort_name = new JTextField();	
	DefaultComboBox cb_degree = new DefaultComboBox();
	IdNameComboBox cb_inst_name = new IdNameComboBox();
	DefaultComboBox cb_cadre = new DefaultComboBox();
	JDateChooser tf_cohort_start_date = null;
	JDateChooser tf_cohort_grad_date = null;
	JTextField tf_cohort_participants_start = new JTextField();
	JTextField tf_cohort_participants_drop = new JTextField();
	JTextField tf_cohort_participants_current = new JTextField();
	
	public CohortEditPagePanel(String cohort_id) throws Exception{
		
		if(cohort_id != null){
			cohort = new Cohort(SQLiteDB.getDBConn().getCohortById(cohort_id));
			String student_grad_count = SQLiteDB.getDBConn().getCohortStudentGraduatedCount(cohort_id);
			if(student_grad_count != null){
				cohort.setParticipants_current(Integer.parseInt(student_grad_count));
			}
			String student_drop_count = SQLiteDB.getDBConn().getCohortStudentDroppedCount(cohort_id);
			if(student_drop_count != null){
				cohort.setParticipants_dropped(Integer.parseInt(student_drop_count));
			}
		}
		else cohort = new Cohort();
		
		//list of institution
		List<String[]> db_all_inst = SQLiteDB.getDBConn().getAllInstitutions();
		if(db_all_inst != null){
			cb_inst_name = new IdNameComboBox(db_all_inst, __ITEM_SELECT);
		}
		
		//list of degrees
		List<String> db_degree = SQLiteDB.getDBConn().getAllQualifications();
		if(db_degree != null)
			cb_degree = new DefaultComboBox(db_degree.toArray());
		cb_degree.insertItemAt(__ITEM_SELECT, 0);
		
		//list of cadres
		List<String> db_all_cadres = SQLiteDB.getDBConn().getAllCadresNames();
		if(db_all_cadres != null)
			cb_cadre = new DefaultComboBox(db_all_cadres.toArray());
		cb_cadre.insertItemAt(__ITEM_SELECT, 0);
		
		this.setLayout(new BorderLayout());
		
		JPanel container = new JPanel(new GridBagLayout());
		
		addComponentInfo(container, cohort_id);
		
		this.add(container, BorderLayout.NORTH);
        
	}
	
	private void addComponentInfo(JPanel container, String cohort_id) throws Exception{
		Insets insets = new Insets(2,2,2,2);
		int row=0;
		
		Utils.addFormRowInfo(container, null, Utils.getFormTitle("Enter details"), row++, insets, true, 0);
		
		if(cohort.getId() > 0){
			tf_cohort_id.setEditable(false);
			tf_cohort_id.setText(String.valueOf(cohort.getId()));
			Utils.addFormRowInfo(container, new JLabel("Cohort ID"), tf_cohort_id, row++, insets, true, 0);
		}
		
		if(cohort.getId() > 0){
			tf_cohort_name.setEditable(false);
		}
		tf_cohort_name.setText(cohort.getName());
		Utils.addFormRowInfo(container, Utils.getRequiredLabel(__LABEL_COHORT_NAME_), tf_cohort_name, row++, insets, true, 0);
		
		Utils.selectComboBoxItem(cb_degree, cohort.getDegree(), __ITEM_SELECT);
		Utils.addFormRowInfo(container, new JLabel("Degree Information"), cb_degree, row++, insets, true, 0);
		
		cb_inst_name.setEditable(false);
	    cb_inst_name.setSelectedItem(cohort.getInstitution());
		Utils.addFormRowInfo(container, new JLabel("Institution"), cb_inst_name, row++, insets, true, 0);
		
		Utils.selectComboBoxItem(cb_cadre, cohort.getCadre(), __ITEM_SELECT);
		Utils.addFormRowInfo(container, new JLabel("Cadre"), cb_cadre, row++, insets, true, 0);
		
		
		tf_cohort_start_date = Utils.getDateChooser(Utils.getDate(cohort.getStart_date()), false, true);
		Utils.addFormRowInfo(container, new JLabel("Cohort Start Date"), tf_cohort_start_date, row++, insets, true, 0);
		
		tf_cohort_grad_date = Utils.getDateChooser(Utils.getDate(cohort.getGrad_date()), false, true);
		Utils.addFormRowInfo(container, new JLabel("Cohort Graduation Date"), tf_cohort_grad_date, row++, insets, true, 0);
		
		if(cohort.getId() > 0){
		tf_cohort_participants_start.setEditable(false);
		tf_cohort_participants_start.setText(String.valueOf(cohort.getParticipants_start()));
		Utils.addFormRowInfo(container, new JLabel("Cohort Participants st Start"), tf_cohort_participants_start, row++, insets, true, 0);
		
		tf_cohort_participants_drop.setEditable(false);
		tf_cohort_participants_drop.setText(String.valueOf(cohort.getParticipants_dropped()));
		Utils.addFormRowInfo(container, new JLabel("Cohort Participants Dropped Out"), tf_cohort_participants_drop, row++, insets, true, 0);
		
		tf_cohort_participants_current.setEditable(false);
		tf_cohort_participants_current.setText(String.valueOf(cohort.getParticipants_current()));
		Utils.addFormRowInfo(container, new JLabel("Cohort Current or Graduating Number"), tf_cohort_participants_current, row++, insets, true, 0);
		}
		//add buttons
		JPanel buttons_panel = new JPanel(new BorderLayout());
		JButton b_delete = new JButton("Delete");
		b_delete.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
				SQLiteDB.getDBConn().deleteCohort(String.valueOf(cohort.getId()));
				JOptionPane.showMessageDialog(CohortEditPagePanel.this, "Cohort with id=" + cohort.getId() + " is deleted from database", "Message", JOptionPane.INFORMATION_MESSAGE);
				MainPanel.getInstance().showCohortSearchPage();
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(CohortEditPagePanel.this, "Cohort with id=" + cohort.getId() + " cannot be deleted from database\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
		    }
		});
		
		JButton b_update = new JButton("Update Cohort");
		b_update.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				updateCohort();
		    }
		});
		JPanel p = new JPanel();
		if(cohort.getId() > 0){
		//if(cohort.getId() > 0 && cohort.getId()>SQLiteDB.getDBConn().getLastCohortId()){
			p.add(b_delete);
		}else{
			b_update.setText("Add Cohort");
		}
		p.add(b_update);
		buttons_panel.add(p, BorderLayout.EAST);
		Utils.addFormRowInfo(container, new JLabel(""), buttons_panel, row++, insets, true, 0);
		
		if(cohort.getId() > 0){
		try{
			container.add(new CohortAssociatedStudentsTablePanel(cohort, CohortEditPagePanel.this, TablePanel.__DEFAULT_WIDTH, TablePanel.__DEFAULT_HEIGHT), new GridBagConstraints(0, row++, 3, 1, 0.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0 ));
			container.add(new CohortLicenseTablePanel(cohort, CohortEditPagePanel.this, TablePanel.__DEFAULT_WIDTH, TablePanel.__DEFAULT_HEIGHT), new GridBagConstraints(0, row++, 3, 1, 0.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0 ));
			container.add(new CohortClassesAssociatedTablePanel(cohort, CohortEditPagePanel.this, TablePanel.__DEFAULT_WIDTH, TablePanel.__DEFAULT_HEIGHT), new GridBagConstraints(0, row++, 3, 1, 0.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0 ));
			container.add(new CohortClinicalTablePanel(cohort, CohortEditPagePanel.this, TablePanel.__DEFAULT_WIDTH, TablePanel.__DEFAULT_HEIGHT), new GridBagConstraints(0, row++, 3, 1, 0.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0 ));
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(CohortEditPagePanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
		}
		
	}
	
	private void addTablePanel(TablePanel table_panel, int row, Insets insets){
		add(table_panel, new GridBagConstraints(0, row, 3, 1, 1.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0 ));
	}
	
	private void updateCohort(){
		
		if(!Utils.validateValueNotEmpty(CohortEditPagePanel.this, __LABEL_COHORT_NAME_, tf_cohort_name.getText()))
			return;
		
		try{
		
		cohort.setName(tf_cohort_name.getText()); 
		cohort.setDegree(cb_degree.getSelectedItem().toString());
		cohort.setInstitution(cb_inst_name.getSelectedItem().toString());
		cohort.setCadre(cb_cadre.getSelectedItem().toString());
		cohort.setStart_date(Utils.getDate(tf_cohort_start_date.getDate()));
		cohort.setGrad_date(Utils.getDate(tf_cohort_grad_date.getDate()));
		
		if(cohort.getId() == 0){
			String cohort_id = SQLiteDB.getDBConn().addCohort(cohort);
			JOptionPane.showMessageDialog(CohortEditPagePanel.this, "New Cohort is added into database", "Message", JOptionPane.INFORMATION_MESSAGE);
			MainPanel.getInstance().showCohortEditPage(cohort_id);
		}else{
			SQLiteDB.getDBConn().updateCohort(cohort);
			JOptionPane.showMessageDialog(CohortEditPagePanel.this, "Cohort details are updated in database", "Message", JOptionPane.INFORMATION_MESSAGE);
		}
		}catch(Exception e){
			if(cohort.getId() == 0){
				JOptionPane.showMessageDialog(CohortEditPagePanel.this, "New Cohort is not added into database.\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}else{
				JOptionPane.showMessageDialog(CohortEditPagePanel.this, "Cohort details are not updated in database.\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
			e.getStackTrace();
		}
		
	}
	


	
}
	

