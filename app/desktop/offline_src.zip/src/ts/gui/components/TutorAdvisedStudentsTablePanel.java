package ts.gui.components;

import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.table.DefaultTableModel;

import ts.db.SQLiteDB;
import ts.ds.Person;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultTable;

public class TutorAdvisedStudentsTablePanel extends TablePanel{
	
	JComponent parent = null;
	Person person = null;
	
	public TutorAdvisedStudentsTablePanel(Person person, JComponent parent, int width, int height) throws Exception{
		
		this.parent = parent;
		this.person = person;
		if(!person.isTutor()){
			throw new Exception("Tutor id is undefined.");
		}
		String[] columnNames = {"ID", "Student Name", Utils.wrapTableHeader("Graduation Year"), "Cohort"};
		List<LinkedHashMap<String, String>> students = SQLiteDB.getDBConn().getTutorStudents(person.getTutor());
		//prepare data for table
		Object[][] students_data = new Object[students.size()][4];
		for(int i=0; i<students.size(); i++){
			students_data[i][0] = Integer.parseInt(students.get(i).get("id"));
			students_data[i][1] = students.get(i).get("first_name") + " " + students.get(i).get("last_name");
			students_data[i][2] = students.get(i).get("graddate");
			students_data[i][3] = students.get(i).get("cohortname");
		}
		//draw table
		//set model with correct column sorting type
		DefaultTableModel model = new DefaultTableModel(students_data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		        if (column == 0 ) {//columns are sorted as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		
		DefaultTable table = new DefaultTable(model, true);
		table.getColumnModel().getColumn(0).setMaxWidth(50);
		
		init("Students Advised", table, null, width, height);
		
	}

}
