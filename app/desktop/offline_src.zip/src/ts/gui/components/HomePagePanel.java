package ts.gui.components;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import ts.config.Config;
import ts.db.SQLiteDB;
import ts.gui.components.utils.DefaultTable;

public class HomePagePanel extends JPanel{
	
	public HomePagePanel() throws Exception{
		List<LinkedHashMap<String, String>> results = SQLiteDB.getDBConn().getInstituteWithCohortAndStudentCount();
		List<LinkedHashMap<String, String>> inst_student_count_all = SQLiteDB.getDBConn().getInstituteStudentCountAll();
		List<LinkedHashMap<String, String>> inst_student_count_grad = SQLiteDB.getDBConn().getInstituteStudentCountGraduated();
		List<LinkedHashMap<String, String>> inst_student_count_drop = SQLiteDB.getDBConn().getInstituteStudentCountDropped();
		
		//key - institute name, value - Institute object// count students count depends on cohorts for ecah institute
		LinkedHashMap<String, Institute> formatted_results = new LinkedHashMap<String, Institute>();
		for(int i=0; i<results.size(); i++){
			Institute inst = formatted_results.get(results.get(i).get("institutionname"));
			if(inst == null){
				inst = new Institute(results.get(i).get("inst_id"), results.get(i).get("institutionname"));
			}
			for(int j=0; j<inst_student_count_all.size(); j++){
				if(inst_student_count_all.get(j).get("institutionid").equals(inst.id)){
					inst.student_count_all = Integer.parseInt(inst_student_count_all.get(j).get("count"));
				}
			}
			for(int j=0; j<inst_student_count_grad.size(); j++){
				if(inst_student_count_grad.get(j).get("institutionid").equals(inst.id)){
					inst.student_count_graduated = Integer.parseInt(inst_student_count_grad.get(j).get("count"));
				}
			}
			for(int j=0; j<inst_student_count_drop.size(); j++){
				if(inst_student_count_drop.get(j).get("institutionid").equals(inst.id)){
					inst.student_count_dropped = Integer.parseInt(inst_student_count_drop.get(j).get("count"));
				}
			}
			Cohort cohort = new Cohort(results.get(i).get("cohortname"), Integer.parseInt(results.get(i).get("cohort_student_count")), 
					Integer.parseInt(results.get(i).get("active_students")));
			if(results.get(i).get("cohortname") != null){
				inst.addCohort(cohort);
			}
			formatted_results.put(results.get(i).get("institutionname"), inst);
		}
		
		//prepare data for table model
		List<String[]> temp = new ArrayList<String[]>();
		Iterator<String> keySetIterator = formatted_results.keySet().iterator();
		while(keySetIterator.hasNext()){
		  String key = keySetIterator.next();
		  Institute inst = formatted_results.get(key);
		  String[] row = {key, String.valueOf(inst.student_count_all), String.valueOf(inst.getActiveStudentCount())};  
		  temp.add(row);
		  //add cohorts data
		  List<Cohort> cohorts = inst.cohorts;
		  for(int i=0; i<cohorts.size(); i++){
			  Cohort cohort = cohorts.get(i);
			  String[] row_cohort = {"       " + cohort.name, String.valueOf(cohort.student_count),String.valueOf(cohort.active_student_count)};
			  temp.add(row_cohort);
		  }
		}
		Object[][] data = new Object[temp.size()][3];
		for(int i=0; i<temp.size(); i++){
			data[i] = temp.get(i);
		}
		
		//draw table
		String[] columnNames = {"Training Institution", "# of students", "Active students"};
		DefaultTable table = new DefaultTable(data, columnNames, false);
		JScrollPane scrollPane = new JScrollPane(table);
		table.getColumnModel().getColumn(1).setMaxWidth(150);
		table.getColumnModel().getColumn(1).setMinWidth(150);
		table.getColumnModel().getColumn(2).setMaxWidth(150);
		table.getColumnModel().getColumn(2).setMinWidth(150);
		table.setSelectionBackground(Config.__TABLE_SELECTION_BG_COLOR);
		setLayout(new BorderLayout());
		add(table.getTableHeader(), BorderLayout.PAGE_START);
		add(scrollPane, BorderLayout.CENTER);
	}
	
	/*
	 * Institute object inner class 
	 */
	class Institute{
		String id;
		String name;
		int student_count_all = 0;
		int student_count_graduated = 0;
		int student_count_dropped = 0;
		List<Cohort> cohorts = new ArrayList<Cohort>();
		
		Institute(String id_, String name_){
			id = id_;
			name = name_;
		}
		
		public void addCohort(Cohort cohort){
			cohorts.add(cohort);
		}
		
		public int getActiveStudentCount(){
			return student_count_all - student_count_graduated - student_count_dropped;
		}
	}
	
	/*
	 * Cohort object inner class
	 */
	class Cohort{
		String name;
		int student_count;
		int active_student_count;
		
		Cohort(String name_, int student_count_, int active_student_count_){
			name = name_;
			student_count = student_count_;
			active_student_count = active_student_count_;
		}
		
	}

}
