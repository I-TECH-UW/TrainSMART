package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import ts.db.SQLiteDB;
import ts.ds.Person;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultTable;

public class StudentExamsTablePanel extends TablePanel{
	
	JComponent parent = null;
	Person person = null;
	
	public StudentExamsTablePanel(Person person, JComponent parent, int width, int height) throws Exception{
		this.parent = parent;
		this.person = person;
		if(person.getStudent().getStudent_id() == 0){
			throw new Exception("Student id is undefined.");
		}
		String[] columnNames = {"ID", "License Name", "Date", "Grade"};
		List<LinkedHashMap<String, String>> student_lic_results = SQLiteDB.getDBConn().getStudentLicenses(person.getStudent());
		//prepare data for table
				Object[][] student_lic_data = new Object[student_lic_results.size()][4];
				for(int i=0; i<student_lic_results.size(); i++){
					student_lic_data[i][0] = Integer.parseInt(student_lic_results.get(i).get("id"));
					student_lic_data[i][1] = student_lic_results.get(i).get("licensename");
					student_lic_data[i][2] = student_lic_results.get(i).get("licensedate");
					student_lic_data[i][3] = student_lic_results.get(i).get("grade");
				}
				//draw table
				//set model with correct column sorting type
				DefaultTableModel model = new DefaultTableModel(student_lic_data, columnNames) {
				    @Override
				    public Class<?> getColumnClass(int column) {
				        if (column == 0 ) {//columns are sorted as integer
				            return Integer.class; 
				        }
				        return String.class;   
				    }
				};
				
				DefaultTable table = new DefaultTable(model, true);
				table.getColumnModel().getColumn(0).setMaxWidth(30);
				
				JButton b_update_exams = new JButton("Update exams");
				b_update_exams.addActionListener( new ActionListener(){
					@Override
				    public void actionPerformed(ActionEvent e){
						try{
							getDialogUpdateExams(student_lic_data, columnNames);
						}catch(Exception ex){
							ex.printStackTrace();
						}
				    }
				});
				init("Exams(License And Registration)", table, b_update_exams, width, height);
		
	}
	
private void getDialogUpdateExams(Object[][] student_lic_data, String[] columnNames) throws Exception{
		
		JPanel p_main = new JPanel(new BorderLayout());
		final JDialog dialog = Utils.getDialog("Update Exams", parent, 800, 500, p_main, true, false);
		//set model with correct column sorting type
		DefaultTableModel model = new DefaultTableModel(student_lic_data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		    	if (column == 0 ) {//columns are sorted as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		
		DefaultTable table = new DefaultTable(model, true){
			public boolean isCellEditable(int row, int column) {
				if(column == 3 )
					return true;
				return false;
			}};
		table.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);	//take value even cell focused
		table.getColumnModel().getColumn(0).setMaxWidth(30);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(800, 500));
		p_main.add(scrollPane, BorderLayout.WEST);
		
		JPanel p_button = new JPanel(new BorderLayout());
		JButton b_update = new JButton("Update");
		b_update.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
					List<LinkedHashMap<String, String>> student_lic_to_update = new ArrayList<LinkedHashMap<String, String>>();
					for(int i=0; i<model.getRowCount(); i++){
						LinkedHashMap<String, String> lic_info = new LinkedHashMap<String, String>();
						lic_info.put("license_id", model.getValueAt(i, 0).toString());
						lic_info.put("grade", model.getValueAt(i, 3).toString());
						student_lic_to_update.add(lic_info);
					}
					SQLiteDB.getDBConn().updateStudentLicenses(student_lic_to_update, person.getStudent());
					JOptionPane.showMessageDialog(parent, "Students exams is updated in database", "Message", JOptionPane.INFORMATION_MESSAGE);
					MainPanel.getInstance().showPersonEditPage(String.valueOf(person.getPersonId()), PersonEditPagePanel.__SELECT_NEW_PERSON_TYPE_STUDENT);
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(parent, "Cannot update students exams\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}finally{
					dialog.dispose();
				}
		    }
		});
		p_button.add(b_update, BorderLayout.EAST);
		p_main.add(p_button, BorderLayout.SOUTH);
		
		dialog.setVisible(true);
	}

}
