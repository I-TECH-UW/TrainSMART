package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ts.db.SQLiteDB;
import ts.ds.Person;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultComboBox;
import ts.gui.components.utils.FormTextField;
import ts.gui.components.utils.IdNameCheckBox;
import ts.gui.components.utils.IdNameComboBox;

import com.toedter.calendar.JDateChooser;

public class PersonEditPagePanel extends JPanel{
	
	private static final String __ITEM_SELECT = "--select--";
	private static final String __LABEL_PERSON_FIRST_NAME = "First Name";
	private static final String __LABEL_PERSON_LAST_NAME = "Last Name";
	private static final String __LABEL_FACILITY = "Facility";
	private static final String __SELECT_YES = "yes";
	private static final String __SELECT_NO = "no";
	public static final String __SELECT_NEW_PERSON_TYPE_STUDENT = "Student";
	public static final String __SELECT_NEW_PERSON_TYPE_TUTOR = "Tutor";
	
	Person person = null;
	
	JPanel container = new JPanel(new GridBagLayout());
	
	String[] yes_no_selection = {__SELECT_NO, __SELECT_YES};
	JComboBox cb_graduated = new JComboBox(yes_no_selection);
	IdNameComboBox cb_cohort = new IdNameComboBox();
	FormTextField tf_person_id = new FormTextField();
	IdNameComboBox cb_title = new IdNameComboBox();
	FormTextField tf_person_first_name = new FormTextField();
	FormTextField tf_person_middle_name = new FormTextField();
	FormTextField tf_person_last_name = new FormTextField();
	FormTextField tf_person_school_id = new FormTextField();
	IdNameComboBox cb_nationality = new IdNameComboBox();
	String[] gender_selection = {"male", "female"};
	DefaultComboBox cb_gender = new DefaultComboBox(__ITEM_SELECT, gender_selection);
	JDateChooser tf_person_dob = null;
	FormTextField tf_person_age = new FormTextField();
	String[] marital_status_selection = {"Single", "Married", "Divorced", "Widowed"};
	DefaultComboBox cb_marital_status = new DefaultComboBox(__ITEM_SELECT, marital_status_selection);
	FormTextField tf_spouse_name = new FormTextField();
	ZoneDistrctComboBoxPanel location_panel= null;
	FormTextField tf_address1 = new FormTextField();
	FormTextField tf_address2 = new FormTextField();
	FormTextField tf_city = new FormTextField();
	FormTextField tf_postal_code = new FormTextField();
	JCheckBox cb_resident_address = new JCheckBox();
	ZoneDistrctComboBoxPanel location_panel_perm= null;
	FormTextField tf_address1_perm = new FormTextField();
	FormTextField tf_address2_perm = new FormTextField();
	FormTextField tf_city_perm = new FormTextField();
	FormTextField tf_postal_code_perm = new FormTextField();
	FormTextField tf_phone = new FormTextField();
	FormTextField tf_cell_phone = new FormTextField();
	FormTextField tf_cell_phone2 = new FormTextField();
	FormTextField tf_email = new FormTextField();
	FormTextField tf_email2 = new FormTextField();
	FormTextField tf_emergency_contact = new FormTextField();
	FormTextField tf_student_id = new FormTextField();
	IdNameComboBox cb_religious = new IdNameComboBox();
	JDateChooser tf_join_date = new JDateChooser();
	IdNameComboBox cb_join_reasons = new IdNameComboBox();
	JDateChooser tf_drop_date = new JDateChooser();
	IdNameComboBox cb_drop_reasons = new IdNameComboBox();
	IdNameComboBox cb_cadre = new IdNameComboBox();
	FormTextField tf_years_of_study = new FormTextField();
	JPanel funding_panel = new JPanel();
	JTextArea  ta_comments = new JTextArea();
	FormTextField tf_custom_field1 = new FormTextField();
	FormTextField tf_custom_field2 = new FormTextField();
	FormTextField tf_custom_field3 = new FormTextField();
	IdNameComboBox cb_advisor = new IdNameComboBox();
	JDateChooser tf_pe_hs_end_date = new JDateChooser();
	FormTextField tf_pe_last_school = new FormTextField();
	JDateChooser tf_pe_hs_start_date = new JDateChooser();
	JCheckBox cb_equval = new JCheckBox();
	FormTextField tf_pe_last_univer = new FormTextField();
	FormTextField tf_pe_person_in_charge = new FormTextField();
	IdNameComboBox cb_facilities = new IdNameComboBox();
	IdNameComboBox cb_inst = new IdNameComboBox();
	JScrollPane cbs_tutor_types = new JScrollPane();
	DefaultComboBox cb_tutor_since = new DefaultComboBox();
	DefaultComboBox cb_tutor_here_since = new DefaultComboBox();
	FormTextField tf_tutor_degree_inst = new FormTextField();
	IdNameComboBox cb_degrees = new IdNameComboBox();
	FormTextField tf_tutor_degree_year = new FormTextField();
	JScrollPane cbs_tutor_lang = new JScrollPane();
	JTextArea  ta_tutor_position_held = new JTextArea();
	
	String[] new_person_type = {__ITEM_SELECT, __SELECT_NEW_PERSON_TYPE_STUDENT, __SELECT_NEW_PERSON_TYPE_TUTOR};
	DefaultComboBox cb_new_person_type = new DefaultComboBox(null, new_person_type);
	
	public PersonEditPagePanel(String person_id, String type) throws Exception{
		if(person_id != null){
			if(type.equals(this.__SELECT_NEW_PERSON_TYPE_TUTOR)){
				LinkedHashMap<String, LinkedHashMap<String, String>> data = SQLiteDB.getDBConn().getTutorById(person_id);
				person = new Person(data.get("person"));
				person.getTutor().init(data.get("tutor"));
				person.getTutor().init(data.get("tutor_address"));
			}else{
				person = new Person(SQLiteDB.getDBConn().getStudentById(person_id));
			}
		}
		else person = new Person();
		
		cb_cohort = new IdNameComboBox(SQLiteDB.getDBConn().getAllCohorts(),__ITEM_SELECT);
		cb_title = new IdNameComboBox(SQLiteDB.getDBConn().getAllPersonTitle(),__ITEM_SELECT);
		cb_nationality = new IdNameComboBox(SQLiteDB.getDBConn().getAllNationalities(),__ITEM_SELECT);
		cb_religious = new IdNameComboBox(SQLiteDB.getDBConn().getAllReligious(),__ITEM_SELECT);
		cb_join_reasons = new IdNameComboBox(SQLiteDB.getDBConn().getAllJoinReasons(),__ITEM_SELECT);
		cb_drop_reasons =  new IdNameComboBox(SQLiteDB.getDBConn().getAllDropReasons(),__ITEM_SELECT);
		cb_cadre =  new IdNameComboBox(SQLiteDB.getDBConn().getAllCadres(),__ITEM_SELECT);
		cb_advisor = new IdNameComboBox(SQLiteDB.getDBConn().getAllTutors(String.valueOf(person.getStudent().getCohort_id())),__ITEM_SELECT);
		cb_facilities = new IdNameComboBox(SQLiteDB.getDBConn().getAllFacilities(true),__ITEM_SELECT);
		cb_inst = new IdNameComboBox(SQLiteDB.getDBConn().getAllInstitutions(),__ITEM_SELECT);
		cb_degrees = new IdNameComboBox(SQLiteDB.getDBConn().getAllQualificationsWithIds(),__ITEM_SELECT);
		
		Insets insets = new Insets(2,2,2,2);
		int row=0;
		setLayout(new BorderLayout());
		
		if(person.isStudent()){
			container.add(getStudentTopInfoPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 0.5, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
		}
		container.add(getPersonalInfoPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
		container.add(getLocalAddressInfoPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
		if(person.isNew()){
			container.add(getNewPersonTypePanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
		}
		if(person.isStudent()){
			container.add(getStudentPermanentAddressInfoPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
			container.add(getStudentOtherContactInfoPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
			container.add(getStudentInfoPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
			funding_panel = getStudentFundingInfoPanel();
			container.add(funding_panel, new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
			container.add(getStudentAdvisorPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
			container.add(getStudentPriorEducationPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
			container.add(getStudentFacilityAfterGraduationPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
		}
		if(person.isTutor()){
			container.add(getTutorFacilityInfoPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
		}
		if(!person.isNew()){
			container.add(getOtherInfoPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
		}
		container.add(getButtonsPanel(), new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, GridBagConstraints.BOTH, insets, 0, 0 ));
	
		if(person.isStudent()){
			try{
				addTablePanel( new StudentClassHistoryTablePanel(person, PersonEditPagePanel.this, TablePanel.__DEFAULT_WIDTH, TablePanel.__DEFAULT_HEIGHT), row++, insets);
				addTablePanel( new StudentClinicalAllocationTablePanel(person, PersonEditPagePanel.this,TablePanel.__DEFAULT_WIDTH, TablePanel.__DEFAULT_HEIGHT), row++, insets);
				addTablePanel( new StudentExamsTablePanel(person, PersonEditPagePanel.this, TablePanel.__DEFAULT_WIDTH, TablePanel.__DEFAULT_HEIGHT), row++, insets);
			}catch(Exception e){
				e.printStackTrace();
				JOptionPane.showMessageDialog(PersonEditPagePanel.this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
			}
		add(container, BorderLayout.NORTH);
	}
	
	private void addTablePanel(TablePanel table_panel, int row, Insets insets){
		container.add(table_panel, new GridBagConstraints(0, row, 3, 1, 1.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0 ));
	}
	
	private JPanel getStudentTopInfoPanel(){
		JPanel p = Utils.getInfoPanel("");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		cb_graduated.setEnabled(person.getStudent().getStudent_id() != null);
		cb_graduated.setSelectedItem(person.getStudent().isGraduated()?__SELECT_YES:__SELECT_NO);
		Utils.addFormRowInfo(p, new JLabel("Graduated?"), cb_graduated, row++, insets, true, 0);
		
		if(person.getStudent().getCohort_id() > 0){
			cb_cohort.setEnabled(false);
			cb_cohort.setForeground(Color.black);
		}
		Utils.selectComboBoxNameId(cb_cohort, person.getStudent().getCohort_id(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Cohort"), cb_cohort, row++, insets, true, 0);
		return p;
	}
	
	private JPanel getPersonalInfoPanel() throws Exception{
		int height = 400;
		if(person.isNew())
			height = 250;
		JPanel p = Utils.getInfoPanel("Personal Information");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		if(!person.isNew()){
			tf_person_id.setEditable(false);
			tf_person_id.setText(String.valueOf(person.getPersonId()));
			Utils.addFormRowInfo(p, new JLabel("TS ID"), tf_person_id, row++, insets, true, 0);
		}
		
		cb_title.setMinimumSize(new Dimension(200, 25));
		Utils.selectComboBoxNameId(cb_title, person.getTitle(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Title"), cb_title, row++, insets, true, 0);
		
		tf_person_first_name.setText(person.getFirst_name());
		//tf_person_first_name.setEditable(false);
		Utils.addFormRowInfo(p, Utils.getRequiredLabel(__LABEL_PERSON_FIRST_NAME), tf_person_first_name, row++, insets, true, 0);
		
		tf_person_middle_name.setText(person.getMiddle_name());
		//tf_person_middle_name.setEditable(false);
		Utils.addFormRowInfo(p, new JLabel("Middle Name"), tf_person_middle_name, row++, insets, true, 0);
		
		tf_person_last_name.setText(person.getLast_name());
		//tf_person_last_name.setEditable(false);
		Utils.addFormRowInfo(p, Utils.getRequiredLabel(__LABEL_PERSON_LAST_NAME), tf_person_last_name, row++, insets, true, 0);
		
		if(!person.isNew()){
			tf_person_school_id.setText(person.getNational_id());
			Utils.addFormRowInfo(p, new JLabel("School ID"), tf_person_school_id, row++, insets, true, 0);
		
			Utils.selectComboBoxNameId(cb_nationality, person.getNationality(), __ITEM_SELECT);
			Utils.addFormRowInfo(p, new JLabel("Nationality"), cb_nationality, row++, insets, true, 0);
		}
		
		Utils.selectComboBoxItem(cb_gender, person.getGender(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Gender"), cb_gender, row++, insets, true, 0);
		
		tf_person_dob = Utils.getDateChooser(person.getBirth_date(), false, true);
		tf_person_dob.getJCalendar().setMaxSelectableDate(new Date());
		Utils.addFormRowInfo(p, new JLabel("Date of birth"), tf_person_dob, row++, insets, true, 0);
		
		if(person.isNew()){
			Utils.addFormRowInfo(p, new JLabel("Institution"), cb_inst, row++, insets, true, 1);
		}else{
			tf_person_age.setEditable(false);
			tf_person_age.setText(String.valueOf(Utils.getAge(person.getBirth_date())));
			Utils.addFormRowInfo(p, new JLabel("Age"), tf_person_age, row++, insets, true, 0);
		
			Utils.selectComboBoxItem(cb_marital_status, person.getMarital_status(), __ITEM_SELECT);
			Utils.addFormRowInfo(p, new JLabel("Marital Status"), cb_marital_status, row++, insets, true, 0);
		
			tf_spouse_name.setText(person.getSpouse_name());
			Utils.addFormRowInfo(p, new JLabel("Spouse Name"), tf_spouse_name, row++, insets, true, 0);
		}
		return p;
	}
	
	private JPanel getLocalAddressInfoPanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Local Address");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		if(person.isTutor()){
			LinkedHashMap<String, String> locs = SQLiteDB.getDBConn().getLocationNamesByDistrictId(String.valueOf(person.getHome_location_id()));
			if(locs == null){
				location_panel = new ZoneDistrctComboBoxPanel(SQLiteDB.getDBConn().getAllZonesWithDistricts(), null, null);
			}else{
				location_panel = new ZoneDistrctComboBoxPanel(SQLiteDB.getDBConn().getAllZonesWithDistricts(), locs.get("zone_name"), locs.get("district_name"));
			}
		}else{ //for student
			location_panel = new ZoneDistrctComboBoxPanel(SQLiteDB.getDBConn().getAllZonesWithDistricts(), person.getStudent().getZone_name(), person.getStudent().getDistrict_name());
		}
		Utils.addFormRowInfo(p, new JLabel(Utils.getGUILabel("Region A (Province)") + "/" + Utils.getGUILabel("Region B (Health District)")), location_panel, row++, insets, true, 1);
		
		if(person.isNew()){
			Utils.addFormRowInfo(p, Utils.getRequiredLabel(__LABEL_FACILITY), cb_facilities, row++, insets, true, 1);
		}
		
		tf_address1.setText(person.getAddress1());
		Utils.addFormRowInfo(p, new JLabel("Address 1"), tf_address1, row++, insets, true, 0);
		
		tf_address2.setText(person.getAddress2());
		Utils.addFormRowInfo(p, new JLabel("Address 2"), tf_address2, row++, insets, true, 0);
		
		tf_city.setText(person.getCity());
		Utils.addFormRowInfo(p, new JLabel("City"), tf_city, row++, insets, true, 0);
		
		if(!person.isNew()){
			tf_postal_code.setText(person.getPostal_code());
			Utils.addFormRowInfo(p, new JLabel("Postal Code / ZIP"), tf_postal_code, row++, insets, true, 0);
		
			if(person.isStudent()){
				cb_resident_address.setSelected(person.isHome_is_residential());
				Utils.addFormRowInfo(p, new JLabel("Residential Address?"), cb_resident_address, row++, insets, true, 0);
			}
			
			if(person.isTutor()){
				tf_cell_phone.setText(person.getCell_phone());
				Utils.addFormRowInfo(p, new JLabel("Cellphone"), tf_cell_phone, row++, insets, true, 0);
			
				tf_cell_phone2.setText(person.getCell_phone2());
				Utils.addFormRowInfo(p, new JLabel("Cellphone 2"), tf_cell_phone2, row++, insets, true, 0);
			}
		}
		
		return p;
	}
	
	private JPanel getTutorFacilityInfoPanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Facility Information");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		Utils.selectComboBoxNameId(cb_facilities, person.getTutor().getFacility_id(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Facility"), cb_facilities, row++, insets, true, 1);
		
		Utils.selectComboBoxNameId(cb_inst, person.getTutor().getInst_id(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Instituion"), cb_inst, row++, insets, true, 1);
		
		String[] years_selection = new String[100];
		int cur_year = Integer.parseInt(Utils.getCurrentYear());
		for(int i=0; i<100; i++){
			years_selection[i] = String.valueOf(cur_year);
			cur_year--;
		}
		cb_tutor_since = new DefaultComboBox(__ITEM_SELECT, years_selection);
		cb_tutor_since.setSelectedItem(person.getTutor().getTutor_since());
		Utils.addFormRowInfo(p, new JLabel("Tutor Since"), cb_tutor_since, row++, insets, true, 1);
		
		List<String[]> all_tutor_types = SQLiteDB.getDBConn().getAllTutorTypes();
		List<String[]> tutor_types = SQLiteDB.getDBConn().getTutorTypesForTutorId(person.getTutor());
		cbs_tutor_types.getViewport().add(Utils.getCheckBoxesWithIdsListPanel(all_tutor_types, tutor_types));
		Utils.addFormRowInfo(p, new JLabel("Tytor Type"), cbs_tutor_types, row++, insets, true, 30);
		
		cb_tutor_here_since = new DefaultComboBox(__ITEM_SELECT, years_selection);
		cb_tutor_here_since.setSelectedItem(person.getTutor().getTutor_time_here());
		Utils.addFormRowInfo(p, new JLabel("Tutor at this Inst. Since"), cb_tutor_here_since, row++, insets, true, 1);
		
		tf_tutor_degree_inst.setText(person.getTutor().getDegree_inst());
		Utils.addFormRowInfo(p, new JLabel("Degree Institution"), tf_tutor_degree_inst, row++, insets, true, 1);
		
		Utils.selectComboBoxNameId(cb_degrees, person.getTutor().getDegree_id(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Degree"), cb_degrees, row++, insets, true, 1);
		
		tf_tutor_degree_year.setText(person.getTutor().getDegree_year());
		Utils.addFormRowInfo(p, new JLabel("Year"), tf_tutor_degree_year, row++, insets, true, 1);
		
		cbs_tutor_lang.setPreferredSize(new Dimension(300, 100));
		List<String[]> all_lang = SQLiteDB.getDBConn().getAllLanguages();
		List<String[]> tutor_lang = SQLiteDB.getDBConn().getTutorLanguages(person.getTutor());
		cbs_tutor_lang.getViewport().add(Utils.getCheckBoxesWithIdsListPanel(all_lang, tutor_lang));
		Utils.addFormRowInfo(p, new JLabel("Languages Spoken"), cbs_tutor_lang, row++, insets, true, 30);
		
		addTablePanel(new TutorAdvisedStudentsTablePanel(person, p, TablePanel.__DEFAULT_WIDTH, TablePanel.__DEFAULT_HEIGHT), row++, insets);
		addTablePanel(new TutorCoursesTablePanel(person, p, TablePanel.__DEFAULT_WIDTH, TablePanel.__DEFAULT_HEIGHT), row++, insets);
		
		return p;
	}
	
	private JPanel getStudentPermanentAddressInfoPanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Next of Kin/Permanent Address");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		location_panel_perm = new ZoneDistrctComboBoxPanel(SQLiteDB.getDBConn().getAllZonesWithDistricts(), person.getStudent().getZone_name_perm(), person.getStudent().getDistrict_name_perm());
		Utils.addFormRowInfo(p, new JLabel(Utils.getGUILabel("Region A (Province)") + "/" + Utils.getGUILabel("Region B (Health District)")), location_panel_perm, row++, insets, true, 1);
		
		tf_address1_perm.setText(person.getStudent().getAddress1_perm());
		Utils.addFormRowInfo(p, new JLabel("Address 1"), tf_address1_perm, row++, insets, true, 0);
		
		tf_address2_perm.setText(person.getStudent().getAddress2_perm());
		Utils.addFormRowInfo(p, new JLabel("Address 2"), tf_address2_perm, row++, insets, true, 0);
		
		tf_city_perm.setText(person.getStudent().getCity_perm());
		Utils.addFormRowInfo(p, new JLabel("City"), tf_city_perm, row++, insets, true, 0);
		
		tf_postal_code_perm.setText(person.getStudent().getPostal_code_perm());
		Utils.addFormRowInfo(p, new JLabel("Postal Code / ZIP"), tf_postal_code_perm, row++, insets, true, 0);
		return p;
	}
	
	private JPanel getStudentOtherContactInfoPanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Other Contact Information");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		tf_phone.setText(person.getPhone());
		Utils.addFormRowInfo(p, new JLabel("Phone"), tf_phone, row++, insets, true, 0);
		
		tf_cell_phone.setText(person.getCell_phone());
		Utils.addFormRowInfo(p, new JLabel("Cellphone"), tf_cell_phone, row++, insets, true, 0);
		
		tf_cell_phone2.setText(person.getCell_phone2());
		Utils.addFormRowInfo(p, new JLabel("Cellphone 2"), tf_cell_phone2, row++, insets, true, 0);
		
		tf_email.setText(person.getEmail());
		Utils.addFormRowInfo(p, new JLabel("Email"), tf_email, row++, insets, true, 0);
		
		tf_email2.setText(person.getEmail2());
		Utils.addFormRowInfo(p, new JLabel("Email 2"), tf_email2, row++, insets, true, 0);
		
		tf_emergency_contact.setText(person.getStudent().getEmergency_contact());
		Utils.addFormRowInfo(p, new JLabel("Emergency Contact"), tf_emergency_contact, row++, insets, true, 0);
		return p;
	}
	
	private JPanel getStudentInfoPanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Student Information");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		/*TA:83 if(person.isStudent()){
			tf_student_id.setEditable(false);
			tf_student_id.setText(String.valueOf(person.getStudent().getStudent_id()));
			Utils.addFormRowInfo(p, new JLabel("Student ID"), tf_student_id, row++, insets, true, 0);
		}*/
		
		Utils.selectComboBoxNameId(cb_religious, person.getStudent().getReligious(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Religious Denomination"), cb_religious, row++, insets, true, 0);
		
		tf_join_date = Utils.getDateChooser(person.getStudent().getJoin_date(), false, true);
		Utils.addFormRowInfo(p, new JLabel("Date of Enrollment"), tf_join_date, row++, insets, true, 0);
		
		Utils.selectComboBoxNameId(cb_join_reasons, person.getStudent().getJoinreason(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Reason for Enrollment"), cb_join_reasons, row++, insets, true, 0);
		
		tf_drop_date = Utils.getDateChooser(person.getStudent().getDrop_date(), false, true);
		Utils.addFormRowInfo(p, new JLabel("Date of Separation"), tf_drop_date, row++, insets, true, 0);
		
		JPanel p_button = new JPanel(new BorderLayout());
		JButton b_remode_drop_date = new JButton("Remove separation date");
		b_remode_drop_date.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				((JTextField)tf_drop_date.getDateEditor().getUiComponent()).setText("");
		    }
		});
		p_button.add(b_remode_drop_date, BorderLayout.EAST);
		Utils.addFormRowInfo(p, new JLabel(""), p_button, row++, insets, true, 0);
		
		Utils.selectComboBoxNameId(cb_drop_reasons, person.getStudent().getDropreason(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Reason for Separation"), cb_drop_reasons, row++, insets, true, 0);
		
		
		cb_drop_reasons.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	//new ts.gui.components.utils.IdNameComboBoxModel();
		    	//System.out.println(((IdNameComboBoxModel)cb_drop_reasons.getModel()).getSelectedNameId());
		    }
		});
		
		cb_cadre.setSelectedIdName(person.getStudent().getCadre());
		Utils.addFormRowInfo(p, new JLabel("Program Enrolled In"), cb_cadre, row++, insets, true, 0);
		
		tf_years_of_study.setEditable(false);
		tf_years_of_study.setText(String.valueOf(person.getStudent().getYearofstudy()));
		Utils.addFormRowInfo(p, new JLabel("Years of Study"), tf_years_of_study, row++, insets, true, 0);
		
		return p;
	}
	
	private JPanel getStudentFundingInfoPanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Funding");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		//all fundings 
		List<String[]> all_fundings = SQLiteDB.getDBConn().getAllFundingNames();
		//get fundings for student ????? use student.id OR person.id
		List<LinkedHashMap<String, String>> student_fundings = SQLiteDB.getDBConn().getStudentFundingByStudentId(String.valueOf(person.getStudent().getPrimary_key_student_id()));
		for(int i=0; i<all_fundings.size(); i++){
			String[] funding = all_fundings.get(i);
			FundingPanel fund_panel = new FundingPanel(funding[0], funding[1]);
			//find funding for student
			for(int j=0; j<student_fundings.size(); j++){
				LinkedHashMap<String, String> f = student_fundings.get(j);
				if(fund_panel.getFundingSourceId().trim().equals(f.get("fundingsource").trim())){
					fund_panel.setAmount(f.get("fundingamount"));
					break;
				}
			}
			p.add(fund_panel, new GridBagConstraints(0, row++, 1, 1, 1.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0));
		}
		
		return p;
	}
	
	private JPanel getStudentAdvisorPanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Advisor");
		Insets insets = new Insets(2,2,2,2);
		Utils.selectComboBoxNameId(cb_advisor, person.getStudent().getAdvisor_id(), __ITEM_SELECT);
		Utils.addFormRowInfo(p, new JLabel("Advisor"), cb_advisor, 0, insets, true, 0);
		return p;
	}
	
	private JPanel getNewPersonTypePanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Type");
		Insets insets = new Insets(2,2,2,2);
		
		cb_new_person_type.setSelectedItem(__ITEM_SELECT);
		Utils.addFormRowInfo(p, Utils.getRequiredLabel(" "), cb_new_person_type, 0, insets, true, 0);
		return p;
	}
	
	private JPanel getStudentPriorEducationPanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Prior Education");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		tf_pe_hs_end_date = Utils.getDateChooser(person.getStudent().getStudent_hs_end_date(), false, true);
		Utils.addFormRowInfo(p, new JLabel("High School Completion Date"), tf_pe_hs_end_date, row++, insets, true, 0);
		
		tf_pe_last_school.setText(person.getStudent().getStudent_last_school());
		Utils.addFormRowInfo(p, new JLabel("Last School Attended"), tf_pe_last_school, row++, insets, true, 0);
		
		tf_pe_hs_start_date = Utils.getDateChooser(person.getStudent().getStudent_hs_start_date(), false, true);
		Utils.addFormRowInfo(p, new JLabel("Admission to School Date"), tf_pe_hs_start_date, row++, insets, true, 0);
		
		cb_equval.setSelected(person.getStudent().isStudent_equival());
		Utils.addFormRowInfo(p, new JLabel("Equivalence"), cb_equval, row++, insets, true, 0);
		
		tf_pe_last_univer.setText(person.getStudent().getStudent_last_univer());
		Utils.addFormRowInfo(p, new JLabel("Last University Attended"), tf_pe_last_univer, row++, insets, true, 0);
		
		tf_pe_person_in_charge.setText(person.getStudent().getStudent_person_in_charge());
		Utils.addFormRowInfo(p, new JLabel("Person In Charge"), tf_pe_person_in_charge, row++, insets, true, 0);
		
		return p;
	}
	
	private JPanel getStudentFacilityAfterGraduationPanel() throws Exception{
		JPanel p = Utils.getInfoPanel("Facility After Graduation");
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		cb_facilities.setSelectedItem(person.getStudent().getAfter_grad_facility_name());
		//cb_facilities.setEnabled(person.getStudent().getAfter_grad_facility_name() == "0"?true:false);
		Utils.addFormRowInfo(p, new JLabel("Facility Name"), cb_facilities, row++, insets, true, 1);
		
		return p;
	}
	
	private JPanel getOtherInfoPanel() throws Exception{
		JPanel p = new JPanel(new GridBagLayout());
		p.setPreferredSize(new Dimension(500, 200));
		int row = 0;
		Insets insets = new Insets(2,2,2,2);
		
		if(person.isTutor()){
			p.setPreferredSize(new Dimension(500, 250));
			JScrollPane sp_tutor_position_held = new JScrollPane(ta_tutor_position_held);
			ta_tutor_position_held.setLineWrap(true);
			ta_tutor_position_held.setWrapStyleWord(true);
			ta_tutor_position_held.setMinimumSize(new Dimension(180, 50));
			ta_tutor_position_held.setText(person.getTutor().getPositionsheld());	
			Utils.addFormRowInfo(p, new JLabel("Positions held (committees, etc.)"), sp_tutor_position_held, row++, insets, true, 50);
		}
		
		JScrollPane sp_comments = new JScrollPane(ta_comments);
		ta_comments.setLineWrap(true);
		ta_comments.setWrapStyleWord(true);
		ta_comments.setMinimumSize(new Dimension(180, 50));
		ta_comments.setText(person.getComments());
		
		Utils.addFormRowInfo(p, new JLabel("Comments"), sp_comments, row++, insets, true, 50);
		tf_custom_field1.setText(person.getCustom_field1());
		
		Utils.addFormRowInfo(p, new JLabel("Custom Field 1"), tf_custom_field1, row++, insets, true, 0);
		tf_custom_field2.setText(person.getCustom_field2());
		Utils.addFormRowInfo(p, new JLabel("Custom Field 2"), tf_custom_field2, row++, insets, true, 0);
		tf_custom_field3.setText(person.getCustom_field3());
		Utils.addFormRowInfo(p, new JLabel("Custom Field 3"), tf_custom_field3, row++, insets, true, 0);
		return p;
	}
	
	
	private JPanel getButtonsPanel() throws Exception{
		JPanel p = new JPanel(new BorderLayout());
		JPanel p_buttons = new JPanel();
		JButton b_update = new JButton("Update");
		if(person.isNew()){
			b_update.setText("Add person");
		}
		b_update.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	updatePerson();
		    }
		});
		JButton b_back = new JButton("Back");
		b_back.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		    	MainPanel.getInstance().showPersonSearchPage();
		    }
		});
		p_buttons.add(b_update);
		if(!person.isNew()){
			p_buttons.add(b_back);
		}
		p.add(p_buttons, BorderLayout.EAST);
		return p;
	}

	
	private void updatePerson(){
		if(!Utils.validateValueNotEmpty(PersonEditPagePanel.this, __LABEL_PERSON_FIRST_NAME, tf_person_first_name.getText()))
			return;
		if(!Utils.validateValueNotEmpty(PersonEditPagePanel.this, __LABEL_PERSON_LAST_NAME, tf_person_last_name.getText()))
			return;
		if(person.isNew()){
			if(cb_facilities.getSelectedItem().equals(__ITEM_SELECT)){
				JOptionPane.showMessageDialog(PersonEditPagePanel.this, "Facility cannot be empty.", "Value validation error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(cb_new_person_type.getSelectedItem().equals(__ITEM_SELECT)){
				JOptionPane.showMessageDialog(PersonEditPagePanel.this, "Type cannot be empty.", "Value validation error", JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		
		try{
			//person table info
			person.setFirst_name(tf_person_first_name.getText()); 
			person.setLast_name(tf_person_last_name.getText()); 
			person.setMiddle_name(tf_person_middle_name.getText());
			person.setTitle(String.valueOf(cb_title.getSelectedIdName()));
			person.setNational_id(tf_person_school_id.getText());
			person.setNationality(String.valueOf(cb_nationality.getSelectedIdName()));
			String gender = cb_gender.getSelectedItem().toString();
			if(gender.equals(__ITEM_SELECT))
				gender = "";
			person.setGender(gender);
			person.setBirth_date(tf_person_dob.getDate());
			String marital_status = cb_marital_status.getSelectedItem().toString();
			if(marital_status.equals(__ITEM_SELECT))
				marital_status = "";
			person.setMarital_status(marital_status);
			person.setSpouse_name(tf_spouse_name.getText());
			person.setAddress1(tf_address1.getText());
			person.setAddress2(tf_address2.getText());
			person.setCity(tf_city.getText());
			person.setPostal_code(tf_postal_code.getText());
			person.setHome_is_residential(cb_resident_address.isSelected());
			person.setPhone(tf_phone.getText());
			person.setCell_phone(tf_cell_phone.getText());
			person.setCell_phone2(tf_cell_phone2.getText());
			person.setEmail(tf_email.getText());
			person.setEmail2(tf_email2.getText());
			person.setCustom_field1(tf_custom_field1.getText());
			person.setCustom_field2(tf_custom_field2.getText());
			person.setCustom_field3(tf_custom_field3.getText());
			person.setComments(ta_comments.getText());
			person.setFacility_id(String.valueOf(cb_facilities.getSelectedIdName()));
			
			if(person.isStudent()){
				//student table info
				person.getStudent().setCohort_id(String.valueOf(cb_cohort.getSelectedIdName()));
				person.getStudent().setEmergency_contact(tf_emergency_contact.getText());
				person.getStudent().setGraduated(cb_graduated.getSelectedItem()==__SELECT_YES?true:false);	
				//person.getStudent().setStudent_id(tf_student_id.getText());
				person.getStudent().setReligious(String.valueOf(cb_religious.getSelectedIdName()));
				person.getStudent().setZone_name(location_panel.getSelectedZoneName());
				person.getStudent().setDistrict_name(location_panel.getSelectedDistrictName());
				person.getStudent().setCadre(String.valueOf(cb_cadre.getSelectedIdName()));
				person.getStudent().setAdvisor_id(String.valueOf(cb_advisor.getSelectedIdName()));
				person.getStudent().setStudent_hs_start_date(tf_pe_hs_start_date.getDate());
				person.getStudent().setStudent_hs_end_date(tf_pe_hs_end_date.getDate());
				person.getStudent().setStudent_last_school(tf_pe_last_school.getText());
				person.getStudent().setStudent_last_univer(tf_pe_last_univer.getText());
				person.getStudent().setStudent_person_in_charge(tf_pe_person_in_charge.getText());
				person.getStudent().setStudent_equival(cb_equval.isSelected());
				person.getStudent().setAfter_grad_facility_name(cb_facilities.getSelectedItem().toString().equals(__ITEM_SELECT)?"":cb_facilities.getSelectedItem().toString());
				person.getStudent().setInst_id(String.valueOf(cb_inst.getSelectedIdName()));
				
				//addresses table info
				if(location_panel_perm != null){
					person.getStudent().setZone_name_perm(location_panel_perm.getSelectedZoneName());
					person.getStudent().setDistrict_name_perm(location_panel_perm.getSelectedDistrictName());
				}
				person.getStudent().setAddress1_perm(tf_address1_perm.getText());
				person.getStudent().setAddress2_perm(tf_address2_perm.getText());
				person.getStudent().setCity_perm(tf_city_perm.getText());
				person.getStudent().setPostal_code_perm(tf_postal_code_perm.getText());
				
				//link_student_cohort table info
				person.getStudent().setJoin_date(tf_join_date.getDate());
				person.getStudent().setDrop_date(tf_drop_date.getDate());
				person.getStudent().setJoinreason(String.valueOf(cb_join_reasons.getSelectedIdName()));
				person.getStudent().setDropreason(String.valueOf(cb_drop_reasons.getSelectedIdName()));
				
				//set up fundings (link_student_funding table info) 
				List<String[]> fundings = new ArrayList<String[]>();
				for(int i=0; i<funding_panel.getComponentCount(); i++){
					FundingPanel p_fund = (FundingPanel)funding_panel.getComponent(i);
					if(p_fund.isSelected()){
//						if(p_fund.getFundingAmount().equals("")){
//							JOptionPane.showMessageDialog(PersonEditPagePanel.this, "Funding amount is not defined.", "Error", JOptionPane.ERROR_MESSAGE);
//						return;
//						}else{
							fundings.add(new String[]{ p_fund.getFundingSourceId(), p_fund.getFundingAmount()});
//						}
					}
				}
				person.getStudent().setFundings(fundings);
			}else if(person.isTutor()){
				person.setHome_district_name(location_panel.getSelectedDistrictName());
				person.setHome_zone_name(location_panel.getSelectedZoneName());
				person.getTutor().setFacility_id(String.valueOf(cb_facilities.getSelectedIdName()));
				person.getTutor().setInst_id(String.valueOf(cb_inst.getSelectedIdName()));
				String tutor_since = cb_tutor_since.getSelectedItem().toString();
				if(tutor_since.equals(__ITEM_SELECT)){
					tutor_since = "";
				}
				person.getTutor().setTutor_since(tutor_since);
				String tutor_time_here = cb_tutor_here_since.getSelectedItem().toString();
				if(tutor_time_here.equals(__ITEM_SELECT)){
					tutor_time_here = "";
				}
				person.getTutor().setTutor_time_here(tutor_time_here);
				person.getTutor().setDegree_id(String.valueOf(cb_degrees.getSelectedIdName()));
				person.getTutor().setDegree_year(tf_tutor_degree_year.getText());
				person.getTutor().setDegree_inst(tf_tutor_degree_inst.getText());
				person.getTutor().setPositionsheld(ta_tutor_position_held.getText());
				
				JPanel vp = (JPanel)cbs_tutor_types.getViewport().getComponent(0);
				List<String> tutor_types = new ArrayList<String>();
				for(int i=0; i<vp.getComponentCount(); i++){
					IdNameCheckBox cb = (IdNameCheckBox)vp.getComponent(i);
					if(cb.isSelected()){
						tutor_types.add(cb.getId());
					}
				}
				person.getTutor().setTypes(tutor_types);
				
				
				JPanel vp2 = (JPanel)cbs_tutor_lang.getViewport().getComponent(0);
				List<String> tutor_langs = new ArrayList<String>();
				for(int i=0; i<vp2.getComponentCount(); i++){
					IdNameCheckBox cb = (IdNameCheckBox)vp2.getComponent(i);
					if(cb.isSelected()){
						tutor_langs.add(cb.getId());
					}
				}
				person.getTutor().setLanguages(tutor_langs);
			}
			
			if(person.isNew()){
				person.setInst_id(String.valueOf(cb_inst.getSelectedIdName()));
				String person_id = SQLiteDB.getDBConn().addPerson(person, cb_new_person_type.getSelectedItem().toString());
				JOptionPane.showMessageDialog(PersonEditPagePanel.this, "New person is added into database", "Message", JOptionPane.INFORMATION_MESSAGE);
				person.setPersonId(Integer.parseInt(person_id));
			}else{
				if(person.isTutor()){
					SQLiteDB.getDBConn().updateTutor(person);
					JOptionPane.showMessageDialog(PersonEditPagePanel.this, "Tutor details are updated in database", "Message", JOptionPane.INFORMATION_MESSAGE);
				}else{
					SQLiteDB.getDBConn().updateStudent(person);
					JOptionPane.showMessageDialog(PersonEditPagePanel.this, "Student details are updated in database", "Message", JOptionPane.INFORMATION_MESSAGE);
				}
			}
			MainPanel.getInstance().showPersonEditPage(String.valueOf(person.getPersonId()), person.isTutor()?PersonEditPagePanel.__SELECT_NEW_PERSON_TYPE_TUTOR: PersonEditPagePanel.__SELECT_NEW_PERSON_TYPE_STUDENT);
			
		}catch(Exception e){
			e.printStackTrace();
			if(person.getPersonId() == 0){
				JOptionPane.showMessageDialog(PersonEditPagePanel.this, "New Person is not added into database.\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}else{
				if(person.isTutor()){
					JOptionPane.showMessageDialog(PersonEditPagePanel.this, "Tutor details are not updated in database.\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}else{
					JOptionPane.showMessageDialog(PersonEditPagePanel.this, "Student details are not updated in database.\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}
	
}
