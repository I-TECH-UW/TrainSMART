package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import ts.db.SQLiteDB;
import ts.ds.Cohort;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultTable;
import ts.gui.components.utils.FirstColumnCheckBoxTableModel;

public class CohortAssociatedStudentsTablePanel extends TablePanel{
	
	JComponent parent = null;
	Cohort cohort = null;
	
	public CohortAssociatedStudentsTablePanel(Cohort cohort, JComponent parent, int width, int height) throws Exception{
		this.parent = parent;
		this.cohort = cohort;
		if(cohort.getId() == 0){
			throw new Exception("Cohort id is undefined.");
		}
		List<LinkedHashMap<String, String>> results = SQLiteDB.getDBConn().getAllStudentsAssociatedWithCohort(String.valueOf(cohort.getId()));
		final List<String> associated_student_ids = new ArrayList<String>();
		//prepare data for table
		Object[][] data = new Object[results.size()][5];
		for(int i=0; i<results.size(); i++){
			associated_student_ids.add(results.get(i).get("student_id"));
			data[i][0] = Integer.parseInt(results.get(i).get("student_id"));
			data[i][1] = results.get(i).get("first_name") + " " + results.get(i).get("last_name");
			data[i][2] = results.get(i).get("gender");
			data[i][3] = results.get(i).get("birthdate");
			if (results.get(i).get("isgraduated").trim().equals("1")){
				data[i][4] = "Graduated";
			} else if (!results.get(i).get("dropdate").trim().equals("0000-00-00")){
				data[i][4] = "Dropped";
			} else {
				data[i][4] = "Active";
			}
		}
		//draw table
		String[] columnNames = {"Student ID", "Name", "Gender", "DOB", "Status"};
		//set model with correct column sorting type
				DefaultTableModel model = new DefaultTableModel(data, columnNames) {
				    @Override
				    public Class<?> getColumnClass(int column) {
				        if (column == 0 ) {//columns are sorted as integer
				            return Integer.class; 
				        }
				        return String.class;   
				    }
				};
				
				DefaultTable table = new DefaultTable(model, true);
		table.getColumnModel().getColumn(0).setMaxWidth(100);
		
		JButton b_update_students = new JButton("Update associated students");
		b_update_students.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
					getDialogToUpdateAssociatedStudents(associated_student_ids);
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(parent, "Cannot get students for this cohort\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
		    }
		});
		init("Students associated with the cohort", table, b_update_students, width, height);
	}
	
private void getDialogToUpdateAssociatedStudents(List<String> associatd_students) throws Exception{
		
		JPanel p_main = new JPanel(new BorderLayout());
		final JDialog dialog = Utils.getDialog("Update students", parent, 500, 500, p_main, true, false);
		
		List<LinkedHashMap<String, String>> results_all_students = SQLiteDB.getDBConn().getAllStudentsForCohort(String.valueOf(cohort.getId()));
		//prepare data for table
		Object[][] data = new Object[results_all_students.size()][5];
		for(int i=0; i<results_all_students.size(); i++){
			data[i][0] = associatd_students.contains(results_all_students.get(i).get("student_id"))?Boolean.TRUE:Boolean.FALSE;
			data[i][1] = Integer.parseInt(results_all_students.get(i).get("student_id"));
			data[i][2] = results_all_students.get(i).get("first_name") + " " + results_all_students.get(i).get("last_name");
			data[i][3] = results_all_students.get(i).get("gender");
			data[i][4] = results_all_students.get(i).get("birthdate");
		}
		//draw table
		String[] columnNames = {"", "Student ID", "Name", "Gender", "DOB"};
		final FirstColumnCheckBoxTableModel model = new FirstColumnCheckBoxTableModel(columnNames, data);
		DefaultTable table = new DefaultTable(model, true);
		JScrollPane scrollPane = new JScrollPane(table);
		//set column width
		table.getColumnModel().getColumn(0).setMaxWidth(10);
		table.getColumnModel().getColumn(0).setMaxWidth(90);
		table.setRowHeight(table.getRowHeight() + 10);
		p_main.add(scrollPane, BorderLayout.WEST);
		
		JPanel p_button = new JPanel(new BorderLayout());
		JButton b_update = new JButton("Update");
		b_update.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
					List<String> true_cb = model.getCheckBoxesValues(1, FirstColumnCheckBoxTableModel.__CHECK_BOXES_STRING_VALUE_TRUE);
					List<String> false_cb = model.getCheckBoxesValues(1, FirstColumnCheckBoxTableModel.__CHECK_BOXES_STRING_VALUE_FALSE);
					SQLiteDB.getDBConn().updateAllStudentsAssociatedWithCohort(String.valueOf(cohort.getId()), true_cb, false_cb);
					JOptionPane.showMessageDialog(parent, "Students associated with this cohort are updated in database", "Message", JOptionPane.INFORMATION_MESSAGE);
					MainPanel.getInstance().showCohortEditPage(String.valueOf(cohort.getId()));
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(parent, "Cannot get students for this cohort\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}finally{
					dialog.dispose();
				}
		    }
		});
		p_button.add(b_update, BorderLayout.EAST);
		p_main.add(p_button, BorderLayout.SOUTH);
		
		dialog.setVisible(true);
	}

}
