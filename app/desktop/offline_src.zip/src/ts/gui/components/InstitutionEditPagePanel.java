package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ts.db.SQLiteDB;
import ts.ds.Institution;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultComboBox;

public class InstitutionEditPagePanel extends JPanel{
	
	private static final String __LABEL_INSTITUTION_NAME_ = "Institution Name";
	private static final String __ITEM_SELECT = "--select--";
	
	Institution inst;
	
	JTextField tf_inst_id = new JTextField();
	JTextField tf_inst_name = new JTextField();
	JTextField tf_inst_address1 = new JTextField();
	JTextField tf_inst_address2 = new JTextField();
	JTextField tf_inst_city = new JTextField();
	JTextField tf_inst_postal_code = new JTextField();
	JTextField tf_inst_phone = new JTextField();
	JTextField tf_inst_fax = new JTextField();
	DefaultComboBox cb_inst_type = new DefaultComboBox();
	DefaultComboBox cb_inst_sponsor = new DefaultComboBox();
	JTextField tf_computer_count = new JTextField();
	JTextField tf_tutor_count = new JTextField();
	JTextField tf_student_count = new JTextField();
	JTextField tf_tutor_student_ratio = new JTextField();
	String[] yes_no_selection = {"no", "yes"};
	JComboBox cb_has_dorm = new JComboBox(yes_no_selection);
	JTextField tf_dorm_count = new JTextField();
	JTextField tf_beds_count = new JTextField();
	JComboBox cb_tutor_housing = new JComboBox(yes_no_selection);
	JTextField tf_tutor_houses_count = new JTextField();
	JTextField tf_year_founded = new JTextField();
	JTextArea ta_comments = new JTextArea();
	JScrollPane cbs_cadres = new JScrollPane();
	JScrollPane cbs_quals = new JScrollPane();
	ZoneDistrctComboBoxPanel location_panel;
	
	public InstitutionEditPagePanel(String inst_id) throws Exception{
		
		if(inst_id != null)
			inst = new Institution(SQLiteDB.getDBConn().getInstituteById(inst_id));
		else inst = new Institution();
		
		//get zones with districts
		location_panel = new ZoneDistrctComboBoxPanel(SQLiteDB.getDBConn().getAllZonesWithDistricts(), inst.getZone_name(), inst.getDistrict_name());
		
		//list of types
		List<String> db_inst_type = SQLiteDB.getDBConn().getAllInstitutionTypes();
		if(db_inst_type != null)
			cb_inst_type = new DefaultComboBox(db_inst_type.toArray());
		cb_inst_type.insertItemAt(__ITEM_SELECT, 0);
		
		//list of sponsors
		List<String> db_inst_sponsor = SQLiteDB.getDBConn().getAllSponsors();
		if(db_inst_sponsor != null)
			cb_inst_sponsor = new DefaultComboBox(db_inst_sponsor.toArray());
		cb_inst_sponsor.insertItemAt(__ITEM_SELECT, 0);
		
		//list of cadres
		List<String> db_all_cadres = SQLiteDB.getDBConn().getAllCadresNames();
		List<String> db_inst_cadre = SQLiteDB.getDBConn().getInstutionCadres(Integer.valueOf(inst.getId()));
		cbs_cadres.setMinimumSize(new Dimension(50, 50));
		cbs_cadres.setPreferredSize(new Dimension(50, 50));
		cbs_cadres.getViewport().add(Utils.getCheckBoxesListPanel(db_all_cadres, db_inst_cadre));
		
		//list of qualifications
		List<String> db_all_qual = SQLiteDB.getDBConn().getAllQualifications();
		List<String> db_inst_qual = SQLiteDB.getDBConn().getInstutionQualifications(Integer.valueOf(inst.getId()));
		cbs_quals.setMinimumSize(new Dimension(50, 50));
		cbs_quals.setPreferredSize(new Dimension(50, 50));
		cbs_quals.getViewport().add(Utils.getCheckBoxesListPanel(db_all_qual, db_inst_qual));
		
		this.setLayout(new BorderLayout());
		
		JPanel container = new JPanel(new GridBagLayout());
		
		addComponentInfo(container);
		
		this.add(container, BorderLayout.NORTH);
        
	}
	
	private void addComponentInfo(JPanel container){
		Insets insets = new Insets(2,2,2,2);
		int row=0;
		
		Utils.addFormRowInfo(container, null, Utils.getFormTitle("Enter details"), row++, insets, true, 0);
		
		if(inst.getId() > 0){
			tf_inst_id.setEditable(false);
			tf_inst_id.setText(String.valueOf(inst.getId()));
			Utils.addFormRowInfo(container, new JLabel("Institution ID"), tf_inst_id, row++, insets, true, 0);
		}
		
		if(inst.getId() > 0){
			tf_inst_name.setEditable(false);
		}
		tf_inst_name.setText(inst.getName());
		Utils.addFormRowInfo(container, Utils.getRequiredLabel(__LABEL_INSTITUTION_NAME_), tf_inst_name, row++, insets, true, 0);
		
		tf_inst_address1.setText(inst.getAddress1());
		Utils.addFormRowInfo(container, new JLabel("Address 1"), tf_inst_address1, row++, insets, true, 0);
		
		tf_inst_address2.setText(inst.getAddress2());
		Utils.addFormRowInfo(container, new JLabel("Address 2"), tf_inst_address2, row++, insets, true, 0);
		
		tf_inst_city.setText(inst.getCity());
		Utils.addFormRowInfo(container, new JLabel("City"), tf_inst_city, row++, insets, true, 0);
		
		
		Utils.addFormRowInfo(container, new JLabel(Utils.getGUILabel("Region A (Province)") + "/" + Utils.getGUILabel("Region B (Health District)")), location_panel, row++, insets, true, 1); 
		
		tf_inst_postal_code.setText(inst.getPostal_code());
		Utils.addFormRowInfo(container, new JLabel("Postal Code"), tf_inst_postal_code, row++, insets, true, 0);
		
		tf_inst_phone.setText(inst.getPhone());
		Utils.addFormRowInfo(container, new JLabel("Phone"), tf_inst_phone, row++, insets, true, 0);
		
		tf_inst_fax.setText(inst.getFax());
		Utils.addFormRowInfo(container, new JLabel("Fax"), tf_inst_fax, row++, insets, true, 0);
		
		Utils.selectComboBoxItem(cb_inst_type, inst.getType(), __ITEM_SELECT);
		Utils.addFormRowInfo(container, new JLabel("Institution Type"), cb_inst_type, row++, insets, true, 0);
		
		Utils.selectComboBoxItem(cb_inst_sponsor, inst.getSponsor(), __ITEM_SELECT);
		Utils.addFormRowInfo(container, new JLabel("Sponsor"), cb_inst_sponsor, row++, insets, true, 0);
		
		Utils.addFormRowInfo(container, new JLabel("Cadres Trained"), cbs_cadres, row++, insets, true, 40);
		
		Utils.addFormRowInfo(container, new JLabel("Qualification Attained"), cbs_quals, row++, insets, true, 40);
		
		tf_computer_count.setText(String.valueOf(inst.getComputer_count()));
		Utils.addFormRowInfo(container, new JLabel("Number of Computers"), tf_computer_count, row++, insets, true, 0);
		
		tf_tutor_count.setEditable(false);
		tf_tutor_count.setText(String.valueOf(inst.getTutor_count()));
		Utils.addFormRowInfo(container, new JLabel("Number of Tutors"), tf_tutor_count, row++, insets, true, 0);
		
		tf_student_count.setEditable(false);
		tf_student_count.setText(String.valueOf(inst.getStudent_count()));
		Utils.addFormRowInfo(container, new JLabel("Active Students"), tf_student_count, row++, insets, true, 0);
		
		tf_tutor_student_ratio.setEditable(false);
		if(inst.getId() > 0 && inst.getTutor_count() != 0){
			String student_tutor_ratio = String.format("%.2f", (double)inst.getStudent_count()/(double)inst.getTutor_count());
			tf_tutor_student_ratio.setText("1:" + student_tutor_ratio);
			}else{
			tf_tutor_student_ratio.setText("0");
		}
		Utils.addFormRowInfo(container, new JLabel("Tutor to Student Ratio"), tf_tutor_student_ratio, row++, insets, true, 0);
		
		cb_has_dorm.setSelectedItem(inst.isHas_dorm()?"yes":"no");
		Utils.addFormRowInfo(container, new JLabel("Dormitories?(y/n)"), cb_has_dorm, row++, insets, true, 0);
		
		tf_dorm_count.setText(String.valueOf(inst.getDorm_count()));
		Utils.addFormRowInfo(container, new JLabel("Number of Dormitories"), tf_dorm_count, row++, insets, true, 0);
		
		tf_beds_count.setText(String.valueOf(inst.getBed_count()));
		Utils.addFormRowInfo(container, new JLabel("Number of beds (students)"), tf_beds_count, row++, insets, true, 0);
		
		cb_tutor_housing.setSelectedItem(inst.isTutor_house()?"yes":"no");
		Utils.addFormRowInfo(container, new JLabel("Tutor housing?(y/n)"), cb_tutor_housing, row++, insets, true, 0);
		
		tf_tutor_houses_count.setText(String.valueOf(inst.getTutor_house_count()));
		Utils.addFormRowInfo(container, new JLabel("Number of Tutor houses"), tf_tutor_houses_count, row++, insets, true, 0);
		
		tf_year_founded.setText(String.valueOf(inst.getYear_founded()));
		Utils.addFormRowInfo(container, new JLabel("Year Founded"), tf_year_founded, row++, insets, true, 0);
		
		ta_comments.setColumns(10);
		ta_comments.setText(String.valueOf(inst.getComments()));
		Utils.addFormRowInfo(container, new JLabel("Comments"), ta_comments, row++, insets, true, 40);
		
		//add buttons
		JPanel buttons_panel = new JPanel(new BorderLayout());
		JButton b_back = new JButton("Back");
		b_back.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				MainPanel.getInstance().showInstituteSearchPage();
		    }
		});
		JButton b_update = new JButton("Update Institution");
		b_update.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				updateInstitution();
		    }
		});
		JPanel p = new JPanel();
		if(inst.getId() > 0){
			p.add(b_back);
		}else{
			b_update.setText("Add Institution");
		}
		p.add(b_update);
		buttons_panel.add(p, BorderLayout.EAST);
		Utils.addFormRowInfo(container, new JLabel(""), buttons_panel, row++, insets, true, 0);
	}
	
	private void updateInstitution(){
		
		if(!Utils.validateValueNotEmpty(InstitutionEditPagePanel.this, __LABEL_INSTITUTION_NAME_, tf_inst_name.getText()))
			return;
		
		try{
		inst.setName(tf_inst_name.getText()); 
		inst.setAddress1(tf_inst_address1.getText());
		inst.setAddress2(tf_inst_address2.getText());
		inst.setCity(tf_inst_city.getText());
		inst.setZone_name(location_panel.getSelectedZoneName());
		inst.setDistrict_name(location_panel.getSelectedDistrictName());
		inst.setPostal_code(tf_inst_postal_code.getText());
		inst.setPhone(tf_inst_phone.getText());
		inst.setFax(tf_inst_fax.getText());
		inst.setType(cb_inst_type.getSelectedItem().toString());
		inst.setSponsor(cb_inst_sponsor.getSelectedItem().toString());
		
		JPanel vp = (JPanel)cbs_cadres.getViewport().getComponent(0);
		List<String> cadres = new ArrayList<String>();
		for(int i=0; i<vp.getComponentCount(); i++){
			JCheckBox cb = (JCheckBox)vp.getComponent(i);
			if(cb.isSelected()){
				cadres.add(cb.getText());
			}
		}
		inst.setCadres(cadres);
		
		vp = (JPanel)cbs_quals.getViewport().getComponent(0);
		List<String> quals = new ArrayList<String>();
		for(int i=0; i<vp.getComponentCount(); i++){
			JCheckBox cb = (JCheckBox)vp.getComponent(i);
			if(cb.isSelected()){
				quals.add(cb.getText());
			}
		}
		inst.setQuals(quals);
			
		inst.setComputer_count(Integer.parseInt(tf_computer_count.getText()));
		inst.setHas_dorm(cb_has_dorm.getSelectedItem().equals("yes")?true:false);
		inst.setDorm_count(Integer.parseInt(tf_dorm_count.getText()));
		inst.setBed_count(Integer.parseInt(tf_beds_count.getText()));
		inst.setTutor_house(cb_tutor_housing.getSelectedItem().equals("yes")?true:false);
		inst.setTutor_house_count(Integer.parseInt(tf_tutor_houses_count.getText()));
		inst.setYear_founded(tf_year_founded.getText());
		inst.setComments(ta_comments.getText());
		
		if(inst.getId() == 0){
			String inst_id = SQLiteDB.getDBConn().addInstitution(inst);
			JOptionPane.showMessageDialog(InstitutionEditPagePanel.this, "New Institution is added into database", "Message", JOptionPane.INFORMATION_MESSAGE);
			MainPanel.getInstance().showInstituteEditPage(inst_id);
		}else{
			SQLiteDB.getDBConn().updateInstitution(inst);
			JOptionPane.showMessageDialog(InstitutionEditPagePanel.this, "Institution details are updated in database", "Message", JOptionPane.INFORMATION_MESSAGE);
		}
		}catch(Exception e){
			e.printStackTrace();
			if(inst.getId() == 0){
				JOptionPane.showMessageDialog(InstitutionEditPagePanel.this, "New Institution is not added into database.\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}else{
				JOptionPane.showMessageDialog(InstitutionEditPagePanel.this, "Institution details are not updated in database.\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		
	}
	

}
