package ts.gui.components;

import java.awt.BorderLayout;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import ts.config.Config;
import ts.db.SQLiteDB;
import ts.gui.components.utils.DefaultTable;

public class InstitutionSearchPagePanel extends JPanel{
	
	public InstitutionSearchPagePanel() throws Exception{
		//get data from database
		List<LinkedHashMap<String, String>> results = SQLiteDB.getDBConn().getAllInstitutesInfo();
		
		String[] columnNames = {"ID", "Name", "Zone", "Sponsor", "Type"};
		//prepare data for table
		Object[][] data = new Object[results.size()][5];
		for(int i=0; i<results.size(); i++){
			data[i][0] = new Integer(results.get(i).get("inst_id"));
			data[i][1] = results.get(i).get("inst_name");
			data[i][2] = results.get(i).get("geo1");
			data[i][3] = results.get(i).get("sponsor_name");
			data[i][4] = results.get(i).get("type_name");
		}
		//set model with correct column sorting type
		DefaultTableModel model = new DefaultTableModel(data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		        if (column == 0) {//first column sort as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		
		//draw table
		final DefaultTable table = new DefaultTable(model, true);
		JScrollPane scrollPane = new JScrollPane(table);
		//set column width
		table.getColumnModel().getColumn(0).setMaxWidth(50);
		//make table row click
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
	        public void valueChanged(ListSelectionEvent event) {
	        	MainPanel.getInstance().showInstituteEditPage(table.getValueAt(table.getSelectedRow(), 0).toString());
	        }
	    });
				
		table.setSelectionBackground(Config.__TABLE_SELECTION_BG_COLOR);
		setLayout(new BorderLayout());
		add(table.getTableHeader(), BorderLayout.PAGE_START);
		add(scrollPane, BorderLayout.CENTER);
	}

}
