package ts.gui.components;

import java.awt.BorderLayout;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import ts.config.Config;
import ts.db.SQLiteDB;
import ts.gui.components.utils.DefaultTable;

public class PersonSearchPagePanel extends JPanel{
	
	public static final String __IS_TUTOR_YES = "X";
	public static final String __IS_TUTOR_NO = "";
	
	public PersonSearchPagePanel() throws Exception{
		
		//get data from database
				List<LinkedHashMap<String, String>> results = SQLiteDB.getDBConn().getAllPersonsInfo();
				
				Object[] columnNames = {"ID", "First Name", "Middle Name", "Last Name", "Date of Birth", "Qualification", "Facility", "Location", "Trainer"};
				
				//prepare data for table
				Object[][] data = new Object[results.size()][9];
				for(int i=0; i<results.size(); i++){
					data[i][0] = new Integer(results.get(i).get("person_id"));
					data[i][1] = results.get(i).get("first_name");
					data[i][2] = results.get(i).get("middle_name");
					data[i][3] = results.get(i).get("last_name");
					data[i][4] = results.get(i).get("birthdate");
					data[i][5] = results.get(i).get("qualification_phrase");
					data[i][6] = results.get(i).get("facility_name");
					data[i][7] = results.get(i).get("location_name");
					data[i][8] = __IS_TUTOR_NO;
					if(results.get(i).get("tutor_id") != null)
						data[i][8] = __IS_TUTOR_YES;
				}
				
				//set model with correct column sorting type
				DefaultTableModel model = new DefaultTableModel(data, columnNames) {
				    @Override
				    public Class<?> getColumnClass(int column) {
				        if (column == 0) {//first column sort as integer
				            return Integer.class; 
				        }
				        return String.class;   
				    }
				};
				
				final DefaultTable table = new DefaultTable(model, true);
				
				JScrollPane scrollPane = new JScrollPane(table);
				//set column width
				table.getColumnModel().getColumn(0).setMaxWidth(50);
				//make table row click
				table.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
			        public void valueChanged(ListSelectionEvent event) {
			        	String type = PersonEditPagePanel.__SELECT_NEW_PERSON_TYPE_STUDENT;
			        	if(table.getValueAt(table.getSelectedRow(), 8).toString().equals(__IS_TUTOR_YES))
			        		type = PersonEditPagePanel.__SELECT_NEW_PERSON_TYPE_TUTOR;
			        		MainPanel.getInstance().showPersonEditPage(table.getValueAt(table.getSelectedRow(), 0).toString(), type);
			        }
			    });
						
				table.setSelectionBackground(Config.__TABLE_SELECTION_BG_COLOR);
				setLayout(new BorderLayout());
				add(table.getTableHeader(), BorderLayout.PAGE_START);
				add(scrollPane, BorderLayout.CENTER);
		
	}

}
