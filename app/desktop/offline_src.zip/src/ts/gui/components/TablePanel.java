package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

import ts.gui.components.utils.DefaultTable;

public class TablePanel extends JPanel{
	
	public static final int __DEFAULT_HEIGHT = 100;
	public static final int __DEFAULT_WIDTH = 800;
	
	JPanel p_button = new JPanel(new BorderLayout());
	
	public TablePanel(){
		
	}
	
	public TablePanel(String title, DefaultTable table, JButton button){
		init(title, table, button, __DEFAULT_WIDTH, __DEFAULT_HEIGHT);
	}
	
	public TablePanel(String title, DefaultTable table, JButton button, int width){
		init(title, table, button, width, __DEFAULT_HEIGHT);
	}
	
	public TablePanel(String title, DefaultTable table, JButton button, int width, int height){
		init(title, table, button, width, height);
	}
	
	protected void init(String title, DefaultTable table, JButton button, int width, int height){
		setLayout(new BorderLayout());
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(width, height));
		add(scrollPane, BorderLayout.WEST);
	    setBorder (BorderFactory.createTitledBorder (BorderFactory.createEtchedBorder(), title, TitledBorder.LEFT, TitledBorder.TOP));
	    add(p_button, BorderLayout.SOUTH);
	    if(button != null)
	    	p_button.add(button,BorderLayout.WEST);
	}
	
}
