package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.toedter.calendar.JDateChooser;

import ts.config.Config;
import ts.db.SQLiteDB;
import ts.ds.Cohort;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultTable;
import ts.gui.components.utils.DeleteButtonTableModel;
import ts.gui.components.utils.TableButtonMouseListener;
import ts.gui.components.utils.TableButtonRenderer;

public class CohortLicenseTablePanel extends TablePanel{
	
	private static final String __LABEL_LICENSE_NAME= "Name";
	private static final String __LABEL_LICENSE_DATE= "Date";
	
	private static final String __MODE_ADD = "Add";
	private static final String __MODE_EDIT = "Edit";
	
	JComponent parent = null;
	Cohort cohort = null;
	
	public CohortLicenseTablePanel(Cohort cohort, JComponent parent, int width, int height) throws Exception{
		this.parent = parent;
		this.cohort = cohort;
		if(cohort.getId() == 0){
			throw new Exception("Cohort id is undefined.");
		}
		
		List<LinkedHashMap<String, String>> results = SQLiteDB.getDBConn().getAllLicensesForCohort(String.valueOf(cohort.getId()));
		//prepare data for table
		Object[][] data = new Object[results.size()][4];
		for(int i=0; i<results.size(); i++){
			data[i][0] = Integer.parseInt(results.get(i).get("id"));
			data[i][1] = results.get(i).get("licensename");
			data[i][2] = results.get(i).get("licensedate");
			data[i][3] = "Delete";
		}
		//draw table
		String[] columnNames = { "ID", "Name", "Date", "" };
		DefaultTable table = new DefaultTable(new DeleteButtonTableModel(
				columnNames, data, 3, String.valueOf(cohort.getId()),
				MainPanel.__DELETE_LICENSE_FROM_COHORT), true);
		table.getColumnModel().getColumn(0).setMaxWidth(50);
		table.getColumnModel().getColumn(3).setMaxWidth(90);
		table.getColumn("").setCellRenderer(new TableButtonRenderer());
		table.addMouseListener(new TableButtonMouseListener(table){
			public void mouseClicked(MouseEvent e) {
				int column = table.getColumnModel().getColumnIndexAtX(e.getX());
				int row    = e.getY()/table.getRowHeight(); 
				if(column == 3){
					if (row < table.getRowCount() && row >= 0 && column < table.getColumnCount() && column >= 0) {
						Object value = table.getValueAt(row, column);
						if (value instanceof JButton) {
							((JButton)value).doClick();
						}
					}
				}else{
					try{
						getDialogEditLicense(__MODE_EDIT, table.getValueAt(table.getSelectedRow(), 0).toString(),
								table.getValueAt(table.getSelectedRow(), 1).toString(),
								table.getValueAt(table.getSelectedRow(), 2).toString());
					}catch(Exception ex){
						JOptionPane.showMessageDialog(CohortLicenseTablePanel.this, "Cannot open edit licence dialog.\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});


		JButton b_add_license = new JButton("Add a license");
		b_add_license.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try{
				getDialogEditLicense(__MODE_ADD, null, null, null);
				}catch(Exception ex){
					JOptionPane.showMessageDialog(CohortLicenseTablePanel.this, "Cannot open add licence dialog.\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		init("License / Registration", table, b_add_license, width, height);
	}
	
	private void getDialogEditLicense(String mode, String licence_id, String name, String date) throws Exception{
		JPanel p_main = new JPanel(new BorderLayout());
		final JDialog dialog = Utils.getDialog(mode + " a license", parent, 500, 150, p_main, true, false);
		p_main.add(new JLabel("All form fields are required"), BorderLayout.NORTH);
		
		JPanel p_content = new JPanel(new GridBagLayout());
		Insets insets = new Insets(2,2,2,2);
		JTextField tf_name = new JTextField();
		tf_name.setText(name == null?"":name);
		tf_name.setPreferredSize(new Dimension(250, 25));
		Utils.addFormRowInfo(p_content, Utils.getRequiredLabel(__LABEL_LICENSE_NAME), tf_name, 0, insets, true, 0);
		
		JDateChooser tf_date = Utils.getDateChooser(null, false, true);
		Utils.addFormRowInfo(p_content, Utils.getRequiredLabel(__LABEL_LICENSE_DATE), tf_date, 1, insets, true, 0);
		if(date != null){
			tf_date.setDate(Utils.getDate(date));
		}
		
		p_main.add(p_content, BorderLayout.CENTER);
		
		JPanel p_buttons = new JPanel();
		JButton b_save = new JButton("Save");
		b_save.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				if(!Utils.validateValueNotEmpty(dialog, __LABEL_LICENSE_NAME, tf_name.getText()))
					return;
				if(!Utils.validateNotNullObject(dialog, __LABEL_LICENSE_DATE, tf_date.getDate()))
					return;
				try{
					if(mode.equals(__MODE_ADD)){
						SQLiteDB.getDBConn().addLicenseForCohort(String.valueOf(cohort.getId()), tf_name.getText(), tf_date.getDate());
					}else if(mode.equals(__MODE_EDIT)){
						SQLiteDB.getDBConn().editLicenseForCohort(licence_id, tf_name.getText(), tf_date.getDate());
					}
					MainPanel.getInstance().showCohortEditPage(String.valueOf(cohort.getId()));
					dialog.dispose();
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(parent, "Cannot add license for this cohort\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
		    }
		});
		p_buttons.add(b_save);
		p_main.add(p_buttons, BorderLayout.SOUTH);
		dialog.setVisible(true);
	}

}
