package ts.gui.components;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

import ts.config.Config;

public class TSBottomBar extends JPanel{
	
	public TSBottomBar(){
		//panel settings
		setBackground(Config.__MAIN_BG_COLOR);
		setOpaque(true);
		
		//label settings
		JLabel ts_info_label = new JLabel("Developed and funded by I-TECH.");
		ts_info_label.setBackground(Config.__MAIN_BG_COLOR);
		ts_info_label.setForeground(Color.white);
		ts_info_label.setFont(new Font(Config.__MAIN_FONT_FAMILIY, Font.PLAIN, 11));
		ts_info_label.setOpaque(true);
		
		add(ts_info_label);
	}

}
