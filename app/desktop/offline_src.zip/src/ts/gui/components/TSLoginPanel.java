package ts.gui.components;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ts.config.Config;

public class TSLoginPanel extends JPanel{
	
	private JButton b_login = new JButton("Continue");
	private JTextField tf_password = new JTextField();
	
	public TSLoginPanel(final TSFrame frame){
		
		JPanel form = new JPanel(new GridLayout(2, 3, 20, 20));
		form.add(new JLabel("Please enter your password"));
		form.add(new JLabel(""));
		form.add(new JLabel(""));
		form.add(new JLabel("Password"));
		form.add(tf_password);
		
		b_login.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				if(!tf_password.getText().trim().equals(Config.__APP_PASSWORD)){
					JOptionPane.showMessageDialog(TSLoginPanel.this, "Wrong password.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				frame.addMainPanel();
		    }
		});
		
		form.add(b_login);
		frame.getRootPane().setDefaultButton(b_login);//when ENTER key is pressed
		
		add(form);
	}

}
