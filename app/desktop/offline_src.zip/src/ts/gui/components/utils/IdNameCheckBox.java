package ts.gui.components.utils;

import javax.swing.JCheckBox;

public class IdNameCheckBox extends JCheckBox{
	
	String id;
	
	public IdNameCheckBox(String id, String name){
		this.id =id;
		this.setText(name);
	}
	
	public String getId(){
		return id;
	}

}
