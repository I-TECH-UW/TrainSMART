package ts.gui.components.utils;

import java.awt.Dimension;

import javax.swing.JTextField;

public class FormTextField extends JTextField{
	
	public static final int __DEFAULT_WIDTH = 180;
	public static final int __DEFAULT_HEIGHT = 25;
	
	public FormTextField(){
		setMinimumSize(new Dimension(__DEFAULT_WIDTH, __DEFAULT_HEIGHT));
	}
	
	public FormTextField(int width){
		setMinimumSize(new Dimension(width, __DEFAULT_HEIGHT));
	}

}
