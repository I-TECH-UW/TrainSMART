package ts.gui.components.utils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;

import ts.ds.Facility;

public class FacilityWithLocationComboBoxModel extends AbstractListModel
		implements ComboBoxModel {
	
	public static final String __DEFAULT_ITEM_SELECT = "-- Select --";
	
	List<Facility> facilities = new ArrayList<Facility>();
	Facility selection = null;

	public FacilityWithLocationComboBoxModel(List<LinkedHashMap<String, String>> data) {
		if(data != null){
			for(int i=0; i<data.size(); i++){
				facilities.add(new Facility(data.get(i)));
			}
		}
	}

	public Object getElementAt(int index) {
		Facility facility = facilities.get(index);
		return facility.getNameWithLocations();
	}

	public int getSize() {
		return facilities.size();
	}

	public void setSelectedItem(Object anItem) {
		for(int i=0; i<facilities.size(); i++){
			if(facilities.get(i).getName().trim().equals(Facility.getPlainNameFromFullName(anItem.toString()))){
				selection = facilities.get(i);
				break;
			}
		}
	} 

	public Object getSelectedItem() {
		if(selection == null)
			return __DEFAULT_ITEM_SELECT;
		return selection.getNameWithLocations(); 
	}
	
	public String getSelectedFacilityId(){
		if(selection == null){
			return null;
		}
		return String.valueOf(selection.getId());
	}

}
