package ts.gui.components.utils;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class test {
	
	public static void main(String[] args){
		
		
		LinkedHashMap<String, String> ru_map = readFile("ru.po");
		LinkedHashMap<String, String> fr_map = readFile("fr.po");
		
	//	System.out.println("===========================================");
		String out = "";
	Iterator<String> keySetIterator = ru_map.keySet().iterator();
		while(keySetIterator.hasNext()){
		  String key = keySetIterator.next();
		  String value = fr_map.get(key);
		  if(value == null)
			  value = "";
			 System.out.println("msgid \"" + key + "\"\nmsgstr \"" + value + "\"\n\n");
			 out = out + "msgid \"" + key + "\"\nmsgstr \"" + value + "\"\n\n";
			 if(value != null)
			 fr_map.remove(key);
		}
		
		try{
		
			PrintWriter out1 = new PrintWriter(new File("out-fr.po"), "UTF-8");
			out1.write("\uFEFF");
			out1.write(out);
			out1.flush();
			out1.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
//		System.out.println("*****************************");
//		
//		keySetIterator = fr_map.keySet().iterator();
//		while(keySetIterator.hasNext()){
//		  String key = keySetIterator.next();
//		  String value = fr_map.get(key);
//		  if(value == null)
//			  value = "";
//			 System.out.println("msgid \"" + key + "\"\nmsgstr \"" + value + "\"\n\n");
//			 if(value != null)
//			 fr_map.remove(key);
//		}
		
		
//		try{
//			String res = new String(Files.readAllBytes(Paths.get("ru.po")));
//			
//		}catch(Exception e){
//			e.printStackTrace();
//		}
		
	}
	
	
	
	public static LinkedHashMap<String, String> readFile(String file){
		LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();
		try {
			String[] res = new String(Files.readAllBytes(Paths.get(file))).split("\n");
			String key = null;
			for(int i=0; i<res.length; i++){
				res[i]= res[i].replaceAll("\n", "");
				if(res[i].startsWith("#~"))
						res[i] = res[i].replaceFirst("#~", "").replaceFirst("\\s+", "");
				if(res[i].startsWith("msgid")){
					key = res[i].replaceFirst("msgid", "").trim().replaceAll("\"", "");
				}else if(res[i].startsWith("msgstr")){
					hm.put(key, res[i].replaceFirst("msgstr", "").trim().replaceAll("\"", ""));
				}else{
					//System.out.println(res[i]);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return hm;
	}

}
