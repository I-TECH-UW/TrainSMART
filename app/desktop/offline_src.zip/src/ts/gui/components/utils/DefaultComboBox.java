package ts.gui.components.utils;

import java.awt.Dimension;
import java.util.List;

import javax.swing.JComboBox;

public class DefaultComboBox extends JComboBox{
	
	public static final int __DEFAULT_WIDTH = 200;
	public static final int __DEFAULT_HEIGHT = 27;
	String default_item = null;
	
	public DefaultComboBox(){
		init();
	}
	
	public DefaultComboBox(String default_item){
		super();
		if(default_item != null)
			this.insertItemAt(default_item, 0);
		this.default_item = default_item;
		init();
	}
	
	public DefaultComboBox(Object[] data){
		super(data);
		init();
	}
	
	public DefaultComboBox(String default_item, String[] data){
		super(data);
		if(default_item != null)
			this.insertItemAt(default_item, 0);
		this.default_item = default_item;
		init();
	}
	
	public DefaultComboBox(List<String[]> data, String default_item){
		super(data.toArray());
		if(default_item != null)
			this.insertItemAt(default_item, 0);
		this.default_item = default_item;
		init();
	}
	
	private void init(){
		setPreferredSize(new Dimension(__DEFAULT_WIDTH, __DEFAULT_HEIGHT));
		setSelectedItem(default_item);
	}
	
//	public String getSelectedItem(){
//		String sel_item = this.getSelectedItem();
//		if(default_item != null && sel_item!= null && sel_item.trim().equals(default_item)){
//			return "";
//		}
//		return sel_item;
//	}

}
