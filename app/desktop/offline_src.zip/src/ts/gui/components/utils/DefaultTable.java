package ts.gui.components.utils;

import java.awt.Dimension;

import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;

import ts.config.Config;

public class DefaultTable extends JTable{
	
	public DefaultTable(Object[][] data, String[] column_names, boolean sorted_rows){
		super(data, column_names);
		setTable(sorted_rows, false);
	}
	
	public DefaultTable(AbstractTableModel model, boolean sorted_rows){
		super(model);
		setTable(sorted_rows, false);
	}
	
	public DefaultTable(DefaultTableModel model, boolean sorted_rows){
		super(model);
		setTable(sorted_rows, false);
	}
	
	public DefaultTable(Object[][] data, String[] column_names, boolean sorted_rows, boolean adjust_column_with_to_header){
		super(data, column_names);
		setTable(sorted_rows, adjust_column_with_to_header);
	}
	
	public DefaultTable(AbstractTableModel model, boolean sorted_rows, boolean adjust_column_with_to_header){
		super(model);
		setTable(sorted_rows, adjust_column_with_to_header);
	}
	
	public DefaultTable(DefaultTableModel model, boolean sorted_rows, boolean adjust_column_with_to_header){
		super(model);
		setTable(sorted_rows, adjust_column_with_to_header);
	}
	
	private void setTable(boolean sorted_rows, boolean adjust_column_with_to_header){
		getTableHeader().setPreferredSize(new Dimension(getTableHeader().getWidth(), 30));
		getTableHeader().setFont(Config.__TABLE_HEADER_FONT);
		setRowHeight(getRowHeight() + 5);
		setFillsViewportHeight(true);
		setAutoCreateRowSorter(sorted_rows);
		if(adjust_column_with_to_header){
			setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			TableColumnAdjuster tca = new TableColumnAdjuster(this);
			tca.adjustColumns();
		}
	}

}
