package ts.gui.components.utils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;

import ts.ds.Person;
import ts.ds.Tutor;

public class TutorComboBoxModel extends AbstractListModel implements ComboBoxModel {
	
List<Person> tutors = new ArrayList<Person>();
Person selection = null;

public TutorComboBoxModel (List<LinkedHashMap<String, String>> data) throws Exception {
if(data != null){
	for(int i=0; i<data.size(); i++){
		Person tutor = new Person(data.get(i));
		tutors.add(tutor);
	}
}
}

public Object getElementAt(int index) {
	Person tutor = tutors.get(index);
return tutor.getFullName();
}

public int getSize() {
return tutors.size();
}

public void setSelectedItem(Object anItem) {
for(int i=0; i<tutors.size(); i++){
	if(tutors.get(i).getFullName().toUpperCase().trim().equals(anItem.toString().toUpperCase())){
		selection = tutors.get(i);
		break;
	}
}
} 

public Object getSelectedItem() {
if(selection == null)
	return "-- Select --";
return selection.getFullName(); 
}

public String getSelectedTutorId(){
	if(selection == null){
		return null;
	}
	return String.valueOf(selection.getTutor().getTutor_id());
}

}

