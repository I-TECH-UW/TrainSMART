package ts.gui.components.utils;

import java.util.List;

import javax.swing.JComboBox;

public class IdNameComboBox extends DefaultComboBox{
	
	public IdNameComboBox(){
		
	}

	
	public IdNameComboBox(List<String[]> data, String default_value) throws Exception{
		this.setModel(new IdNameComboBoxModel(data, default_value));
	}
	
	public void setSelectedIdName(int id){
		((IdNameComboBoxModel)getModel()).setSelectedId(id);
	}
	
	public int getSelectedIdName(){
		String sel = ((IdNameComboBoxModel)getModel()).getSelectedNameId();
		if(sel != null && !sel.trim().equals(""))
		return Integer.parseInt(sel);
		else return 0;
	}

}
