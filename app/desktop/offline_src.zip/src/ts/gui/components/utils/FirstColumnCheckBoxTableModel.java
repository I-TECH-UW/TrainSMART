package ts.gui.components.utils;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

public class FirstColumnCheckBoxTableModel extends AbstractTableModel {
	
	public static final String __CHECK_BOXES_STRING_VALUE_TRUE = "true";
	public static final String __CHECK_BOXES_STRING_VALUE_FALSE = "false";
	
	  Object[][] rowData;
	  String columnNames[];
	  
	  public FirstColumnCheckBoxTableModel(String[] columnNames, Object[][] rowData){
		  this.columnNames = columnNames;
		  this.rowData = rowData;
	  }

	  public int getColumnCount() {
	    return columnNames.length;
	  }

	  public String getColumnName(int column) {
	    return columnNames[column];
	  }

	  public int getRowCount() {
	    return rowData.length;
	  }

	  public Object getValueAt(int row, int column) {
	    return rowData[row][column];
	  }

	  @Override
	  public Class getColumnClass(int column) {
		  if(column == 0){
			  return (getValueAt(0, column).getClass());
		  }
		  if (column == 1 ) {//columns are sorted as integer
	            return Integer.class; 
	        }
	        return String.class;  
	  }

	  public void setValueAt(Object value, int row, int column) {
	    rowData[row][column] = value;
	  }

	  public boolean isCellEditable(int row, int column) {
	    return (column == 0);
	  }
	  
	  /*
	   * value can be only from selected options: __CHECK_BOXES_STRING_VALUE_TRUE or __CHECK_BOXES_STRING_VALUE_FALSE
	   */
	  public List<String> getCheckBoxesValues(int column, String value){
		  List<String> list = new ArrayList<String>();
		  for(int i=0; i<rowData.length; i++){
			  if(getValueAt(i, 0).toString().equals(value)){
				  list.add(getValueAt(i, column).toString());
			  }
		  }
		  return list;
	  }
	  
	}
