package ts.gui.components.utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;

public class IdNameComboBoxModel extends AbstractListModel
implements ComboBoxModel {

//List of string[0] - id, string[1] - name
List<String[]> names = new ArrayList<String[]>();
String[] selected_name = null;

public IdNameComboBoxModel(List<String[]> data, String default_value) throws Exception{
	if(data != null)
		names = data;
	if(default_value != null && !default_value.trim().equals("")){
		selected_name = new String[]{ "0", default_value};
		names.add(0, selected_name);
	}
}

public Object getElementAt(int index) {
return names.get(index)[1];
}

public int getSize() {
return names.size();
}

public void setSelectedItem(Object anItem) {
	for(int i=0; i<names.size(); i++){
		if(anItem != null && anItem.equals(names.get(i)[1])){
			selected_name = names.get(i);
			break;
		}
	}
} 

public void setSelectedId(int id) {
	for(int i=0; i<names.size(); i++){
		if(id == Integer.parseInt(names.get(i)[0])){
			selected_name = names.get(i);
			break;
		}
	}
}

public Object getSelectedItem() {
return selected_name[1]; 
}

public String getSelectedNameId(){
return selected_name[0];
}

}

