package ts.gui.components.utils;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.AbstractTableModel;

import ts.gui.components.MainPanel;

public class DeleteButtonTableModel extends AbstractTableModel {
	private static final long serialVersionUID = 1L;
	Object[][] rowData;
	 int column_index_delete_button = 0;
	
	String[] column_names;
	String id_belong_to;
	int mode_delete_button_action = -1;
	
	public DeleteButtonTableModel(String[] column_names, Object[][] rowData, int column_index_delete_button, String id_belong_to, int mode_delete_button_action){
		this.column_names = column_names;
		this.rowData = rowData;
		this.column_index_delete_button =column_index_delete_button;
		this.id_belong_to = id_belong_to;
		this.mode_delete_button_action = mode_delete_button_action;
	}
	
	@Override 
	public int getColumnCount() {
		return column_names.length;
	}

	@Override public int getRowCount() {
		return rowData.length;
	}
	
	@Override public String getColumnName(int columnIndex) {
        return column_names[columnIndex];
    }
	
	@Override public Class<?> getColumnClass(int columnIndex) {
		if(columnIndex == column_index_delete_button)
			return JButton.class;
		 if (columnIndex == 0 ) {//columns are sorted as integer
	            return Integer.class; 
	        }
		else return String.class;
	}

	@Override public Object getValueAt(final int rowIndex, final int columnIndex) {
		if(columnIndex == column_index_delete_button){
			final JButton button = new JButton(rowData[rowIndex][columnIndex].toString());
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					MainPanel.getInstance().doAction(mode_delete_button_action, new String[]{id_belong_to, rowData[rowIndex][0].toString()});
				}
			});
			return button;
		}else{
			return rowData[rowIndex][columnIndex];
		}
	}

}
