package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

import ts.config.Config;

public class BannerPanel extends JPanel{
	
	JLabel l_title = new JLabel();
	
	public BannerPanel(String title){
		this.setPreferredSize(new Dimension(500,100));
		this.setLayout(new BorderLayout());
		this.setBackground(Config.__BANNER_BG_COLOR);
		
		JLabel l_ts_title = new JLabel("    TrainSMART");
		l_ts_title.setFont(new Font(Config.__MAIN_FONT_FAMILIY, Font.PLAIN, 30));
		l_ts_title.setForeground(Config.__BANNER_FONT_COLOR);
		add(l_ts_title, BorderLayout.CENTER);
		
		JPanel p = new JPanel(new BorderLayout());
		p.setBackground(Config.__BANNER_TITLE_BG_COLOR);
		l_title.setFont(new Font(Config.__MAIN_FONT_FAMILIY, Font.PLAIN, 14));
		l_title.setBackground(Config.__BANNER_TITLE_BG_COLOR);
		l_title.setForeground(Color.white);
		p.add(l_title, BorderLayout.WEST);
		
		add(p, BorderLayout.SOUTH);
		setTitle(title);
	}
	
	public void setTitle(String title){
		l_title.setText(" " + title);
	}

}
