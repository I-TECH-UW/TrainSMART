package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import ts.db.SQLiteDB;
import ts.ds.Person;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultTable;

public class StudentClassHistoryTablePanel extends TablePanel{
	
	JComponent parent = null;
	Person person = null;
	
	public StudentClassHistoryTablePanel(Person person, JComponent parent, int width, int height) throws Exception{
		this.parent = parent;
		this.person = person;
		if(!person.isStudent()){
			throw new Exception("Student id is undefined.");
		}
		String[] columnNames = {"ID", Utils.wrapTableHeader("Class Name"), "Topic", Utils.wrapTableHeader("Start Date"), Utils.wrapTableHeader("End Date"), "Instructor", 
				Utils.wrapTableHeader("Course Type"), "CA Mark", Utils.wrapTableHeader("Exam Mark"), "Grade", "Credits"};
		List<LinkedHashMap<String, String>> student_class_history_results = SQLiteDB.getDBConn().getStudentClassHistory(person.getStudent());
		//prepare data for table
		Object[][] student_class_history_data = new Object[student_class_history_results.size()][11];
		for(int i=0; i<student_class_history_results.size(); i++){
			student_class_history_data[i][0] = Integer.parseInt(student_class_history_results.get(i).get("id"));
			student_class_history_data[i][1] = student_class_history_results.get(i).get("classname");
			student_class_history_data[i][2] = student_class_history_results.get(i).get("coursetopic");
			student_class_history_data[i][3] = student_class_history_results.get(i).get("startdate");
			student_class_history_data[i][4] = student_class_history_results.get(i).get("enddate");
			String first_name = student_class_history_results.get(i).get("first_name");
			String last_name = student_class_history_results.get(i).get("last_name");
			student_class_history_data[i][5] = first_name != null?first_name:"" + " " + last_name != null?last_name:"";
			student_class_history_data[i][6] = student_class_history_results.get(i).get("coursetype");
			student_class_history_data[i][7] = student_class_history_results.get(i).get("camark");
			student_class_history_data[i][8] = student_class_history_results.get(i).get("exammark");
			student_class_history_data[i][9] = student_class_history_results.get(i).get("grade");
			student_class_history_data[i][10] = student_class_history_results.get(i).get("credits");
		}
		//draw table
		//set model with correct column sorting type
		DefaultTableModel model = new DefaultTableModel(student_class_history_data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		        if (column == 0 ) {//columns are sorted as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		
		DefaultTable table = new DefaultTable(model, true);
		table.getColumnModel().getColumn(0).setMaxWidth(30);
		
		JButton b_update_classes = new JButton("Update classes");
		b_update_classes.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
					getDialogUpdateClasses(student_class_history_data, columnNames);
				}catch(Exception ex){
					ex.printStackTrace();
				}
		    }
		});
		init("Class History", table, b_update_classes, width, height);
	}
	
	private void getDialogUpdateClasses(Object[][] student_class_history_data, String[] columnNames) throws Exception{
		
		JPanel p_main = new JPanel(new BorderLayout());
		final JDialog dialog = Utils.getDialog("Update Classes", parent, 800, 500, p_main, true, false);
		//draw table
		//set model with correct column sorting type
		DefaultTableModel model = new DefaultTableModel(student_class_history_data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		    	if (column == 0 ) {//columns are sorted as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		
		DefaultTable table = new DefaultTable(model, true){
			public boolean isCellEditable(int row, int column) {
				if(column == 7 || column == 8 || column == 9 || column == 10)
					return true;
				return false;
			}};
		table.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);	//take value even cell focused
		table.getColumnModel().getColumn(0).setMaxWidth(30);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(800, 500));
		p_main.add(scrollPane, BorderLayout.WEST);
		
		JPanel p_button = new JPanel(new BorderLayout());
		JButton b_update = new JButton("Update");
		b_update.addActionListener( new ActionListener(){
			@Override
		    public void actionPerformed(ActionEvent e){
				try{
					List<LinkedHashMap<String, String>> student_classes_to_update = new ArrayList<LinkedHashMap<String, String>>();
					for(int i=0; i<model.getRowCount(); i++){
						LinkedHashMap<String, String> class_info = new LinkedHashMap<String, String>();
						class_info.put("class_id", model.getValueAt(i, 0).toString());
						class_info.put("grade", model.getValueAt(i, 9).toString());
						class_info.put("credits", model.getValueAt(i, 10).toString());
						class_info.put("exammark", model.getValueAt(i, 8).toString());
						class_info.put("camark", model.getValueAt(i, 7).toString());
						student_classes_to_update.add(class_info);
					}
					SQLiteDB.getDBConn().updateStudentClassHistory(student_classes_to_update, person.getStudent());
					JOptionPane.showMessageDialog(parent, "Students class history is updated in database", "Message", JOptionPane.INFORMATION_MESSAGE);
					MainPanel.getInstance().showPersonEditPage(String.valueOf(person.getPersonId()), PersonEditPagePanel.__SELECT_NEW_PERSON_TYPE_STUDENT);
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(parent, "Cannot update students class history\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}finally{
					dialog.dispose();
				}
		    }
		});
		p_button.add(b_update, BorderLayout.EAST);
		p_main.add(p_button, BorderLayout.SOUTH);
		
		dialog.setVisible(true);
	}

}
