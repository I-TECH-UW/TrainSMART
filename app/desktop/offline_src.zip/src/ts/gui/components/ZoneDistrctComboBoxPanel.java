package ts.gui.components;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JPanel;

public class ZoneDistrctComboBoxPanel extends JPanel{
	
	public static final String __ITEM_SELECT = "--choose--";
	
	JComboBox cb_zone = new JComboBox();
	JComboBox cb_dist = new JComboBox();
	
	public ZoneDistrctComboBoxPanel(final LinkedHashMap<String, List<String>> zones, String sel_zone, String sel_dist){
		this.setLayout(new GridBagLayout());
		if(zones != null){
			cb_zone = new JComboBox(zones.keySet().toArray());
			cb_zone.insertItemAt(__ITEM_SELECT, 0);
			cb_zone.addActionListener( new ActionListener(){
				@Override
			    public void actionPerformed(ActionEvent e){
					String zone = cb_zone.getSelectedItem().toString();
					cb_dist.removeAllItems();
					List<String> districts = zones.get(zone);
					cb_dist.addItem(__ITEM_SELECT);
					if(districts != null){
						for(int i=0; i<districts.size(); i++){
							cb_dist.addItem(districts.get(i));
						}
					}
			    }
			});
			Insets insets = new Insets(2,2,2,2);
			GridBagConstraints gbc = new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0);
			add(cb_zone, gbc);
			gbc = new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, insets, 0, 0);
			add(cb_dist,gbc);
			cb_zone.setSelectedItem(__ITEM_SELECT);
			if(sel_zone != null){
				cb_zone.setSelectedItem(sel_zone);
			}
			cb_dist.setSelectedItem(__ITEM_SELECT);
			if(sel_dist != null){
				cb_dist.setSelectedItem(sel_dist);
			}
		}	
	}
	
	public String getSelectedZoneName(){
		return cb_zone.getSelectedItem().toString();
	}
	
	public String getSelectedDistrictName(){
		return cb_dist.getSelectedItem().toString();
	}

}
