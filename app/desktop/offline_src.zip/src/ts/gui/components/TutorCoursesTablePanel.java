package ts.gui.components;

import java.util.LinkedHashMap;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.table.DefaultTableModel;

import ts.db.SQLiteDB;
import ts.ds.Person;
import ts.gui.Utils;
import ts.gui.components.utils.DefaultTable;

public class TutorCoursesTablePanel extends TablePanel{
	
	JComponent parent = null;
	Person person = null;
	
	public TutorCoursesTablePanel(Person person, JComponent parent, int width, int height) throws Exception{
		
		this.parent = parent;
		this.person = person;
		if(!person.isTutor()){
			throw new Exception("Tutor id is undefined.");
		}
		String[] columnNames = {"ID", "Course Name", "Course Type", "Date", "Cohort"};
		List<LinkedHashMap<String, String>> courses = SQLiteDB.getDBConn().getTutorCourses(person.getTutor());
		//prepare data for table
		Object[][] courses_data = new Object[courses.size()][5];
		for(int i=0; i<courses.size(); i++){
			courses_data[i][0] = Integer.parseInt(courses.get(i).get("id"));
			courses_data[i][1] = courses.get(i).get("classname"); 
			courses_data[i][2] = courses.get(i).get("coursetype");
			courses_data[i][3] = courses.get(i).get("startdate") + "-" + courses.get(i).get("enddate");
			courses_data[i][4] = courses.get(i).get("cohortname");
		}
		//draw table
		//set model with correct column sorting type
		DefaultTableModel model = new DefaultTableModel(courses_data, columnNames) {
		    @Override
		    public Class<?> getColumnClass(int column) {
		        if (column == 0 ) {//columns are sorted as integer
		            return Integer.class; 
		        }
		        return String.class;   
		    }
		};
		
		DefaultTable table = new DefaultTable(model, true);
		table.getColumnModel().getColumn(0).setMaxWidth(50);
		
		init("Courses Taught", table, null, width, height);
		
	}

}
