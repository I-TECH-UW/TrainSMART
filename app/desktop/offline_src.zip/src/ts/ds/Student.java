package ts.ds;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import ts.gui.Utils;

public class Student {
	
	int student_id = 0;
	int primary_key_student_id = 0; // unique primary key student id
	String emergency_contact = null;
	boolean graduated = false;
	int religious = 0;
	String zone_name = null;
	String district_name = null;
	int cadre = 0;
	int advisor_id =0;
	Date student_hs_start_date = null;
	Date student_hs_end_date = null;
	String student_last_school = null;
	boolean student_equival = false;
	String student_last_univer = null;
	String student_person_in_charge = null;
	String after_grad_zone_name = null;
	String after_grad_district_name = null;
	String after_grad_facility_name = null;
	String zone_name_perm = null;
	String district_name_perm = null;
	String address1_perm = null;
	String address2_perm = null;
	String postal_code_perm = null;
	String city_perm = null;
	Date join_date = null;
	int joinreason = 0;
	Date drop_date = null;
	int dropreason = 0;
	int yearofstudy = 0;
	int address_id = 0;
	String cohort_name = null;
	int cohort_id = 0;
	int inst_id =0;
	
	// list of fundings: [0] - funding source_id, [2] - funding amount
		List<String[]> fundings = new ArrayList<String[]>();
	
	public Student(){}
	
	public void init(LinkedHashMap<String, String> data) throws Exception{
		if(data != null){
			setGraduated((data.get("student_isgraduated") != null && Integer.parseInt(data.get("student_isgraduated")) == 1)?true:false);
			setZone_name(data.get("zone"));
			setDistrict_name(data.get("district"));
			setEmergency_contact(data.get("emergcontact"));
			setStudent_id(data.get("studentid") == null || data.get("studentid").trim().equals("")?data.get("student_id_table"):data.get("studentid"));
//			setStudent_id(data.get("studentid") == null || data.get("studentid").trim().equals("")?data.get("personid"):data.get("studentid"));
			setPrimary_key_student_id(data.get("student_id_table"));
			setReligious(data.get("studenttype"));
			setCadre(data.get("cadre"));
			setAdvisor_id(data.get("advisorid"));
			setStudent_hs_start_date(Utils.getDate(data.get("schoolstartdate")));
			setStudent_hs_end_date(Utils.getDate(data.get("hscomldate")));
			setStudent_last_school(data.get("lastinstatt"));
			setStudent_equival((data.get("equivalence") != null && Integer.parseInt(data.get("equivalence"))==1)?true:false);
			setStudent_last_univer(data.get("lastunivatt"));
			setStudent_person_in_charge(data.get("personincharge"));
			setAfter_grad_facility_name(data.get("postfacilityname"));
			setAfter_grad_zone_name(data.get("post_zone_name"));
			setAfter_grad_district_name(data.get("post_district_name"));
			setZone_name_perm(data.get("zone_perm"));
			setDistrict_name_perm(data.get("district_perm"));
			setAddress1_perm(data.get("address1"));
			setAddress2_perm(data.get("address2"));
			setCity_perm(data.get("city"));
			setPostal_code_perm(data.get("postalcode"));
			setJoin_date(Utils.getDate(data.get("joindate")));
			setJoinreason(data.get("joinreason"));
			setDrop_date(Utils.getDate(data.get("dropdate")));
			setDropreason(data.get("dropreason"));
			setYearofstudy(); 
			setAddress_id(data.get("address_id"));
			setCohort_name(data.get("cohortname"));
			setCohort_id(data.get("student_cohort_id"));
			setInst_id(data.get("institutionid"));
		}
	}
	
	
	
	public int getPrimary_key_student_id() {
		return primary_key_student_id;
	}

	public void setPrimary_key_student_id(String primary_key_student_id) {
		if(primary_key_student_id != null && !primary_key_student_id.trim().equals(""))
			this.primary_key_student_id = Integer.parseInt(primary_key_student_id);
	}

	public int getInst_id() {
		return inst_id;
	}

	public void setInst_id(String inst_id) {
		if(inst_id != null && !inst_id.trim().equals(""))
		this.inst_id = Integer.parseInt(inst_id);
	}

	public int getStudent_id() {
		return student_id;
	}
	
	
	public int getAddress_id() {
		return address_id;
	}

	public void setAddress_id(String address_id) {
		if(address_id != null && !address_id.trim().equals(""))
		this.address_id = Integer.parseInt(address_id);
	}

			// list of fundings: [0] - funding source_id, [2] - funding amount
			public List<String[]> getFundings() {
				return fundings;
			}

			// list of fundings: [0] - funding source_id, [2] - funding amount
			public void setFundings(List<String[]> fundings) {
				this.fundings = fundings;
			}
	
	public int getYearofstudy() {
		return yearofstudy;
	}

	public void setYearofstudy() throws Exception {
		if(join_date != null){
			Date drop_date_temp = Utils.getDate(Utils.getCurrentDate());
			if(drop_date !=  null){
				drop_date_temp = drop_date;
			}
			this.yearofstudy = Utils.getYears(join_date, drop_date_temp);
		}
	}

	public Date getJoin_date() {
		return join_date;
	}

	public void setJoin_date(Date join_date) {
		this.join_date = join_date;
	}

	public Date getDrop_date() {
		return drop_date;
	}

	public void setDrop_date(Date drop_date) {
		this.drop_date = drop_date;
	}

	public int getDropreason() {
		return dropreason;
	}

	public void setDropreason(String dropreason) {
		if(dropreason != null)
			this.dropreason = Integer.parseInt(dropreason);
	}

	public int getJoinreason() {
		return joinreason;
	}

	public void setJoinreason(String joinreason) {
		if(joinreason != null)
		this.joinreason = Integer.parseInt(joinreason);
	}
	
	public String getZone_name_perm() {
		return zone_name_perm;
	}

	public void setZone_name_perm(String zone_name_perm) {
		this.zone_name_perm = zone_name_perm;
	}

	public String getDistrict_name_perm() {
		return district_name_perm;
	}

	public void setDistrict_name_perm(String district_name_perm) {
		this.district_name_perm = district_name_perm;
	}

	public String getAddress1_perm() {
		return address1_perm;
	}

	public void setAddress1_perm(String address1_perm) {
		this.address1_perm = address1_perm;
	}

	public String getAddress2_perm() {
		return address2_perm;
	}

	public void setAddress2_perm(String address2_perm) {
		this.address2_perm = address2_perm;
	}

	public String getCity_perm() {
		return city_perm;
	}

	public void setCity_perm(String city_perm) {
		this.city_perm = city_perm;
	}

	public String getPostal_code_perm() {
		return postal_code_perm;
	}

	public void setPostal_code_perm(String postal_code_perm) {
		this.postal_code_perm = postal_code_perm;
	}
	
	public String getAfter_grad_zone_name() {
		return after_grad_zone_name;
	}

	public void setAfter_grad_zone_name(String after_grad_zone_name) {
		this.after_grad_zone_name = after_grad_zone_name;
	}

	public String getAfter_grad_district_name() {
		return after_grad_district_name;
	}

	public void setAfter_grad_district_name(String after_grad_district_name) {
		this.after_grad_district_name = after_grad_district_name;
	}

	public String getAfter_grad_facility_name() {
		return after_grad_facility_name;
	}

	public void setAfter_grad_facility_name(String after_grad_facility_name) {
		this.after_grad_facility_name = after_grad_facility_name;
	}

	public String getStudent_last_school() {
		return student_last_school;
	}

	public void setStudent_last_school(String student_last_school) {
		this.student_last_school = student_last_school;
	}

	public boolean isStudent_equival() {
		return student_equival;
	}

	public void setStudent_equival(boolean student_equival) {
		this.student_equival = student_equival;
	}

	public String getStudent_last_univer() {
		return student_last_univer;
	}

	public void setStudent_last_univer(String student_last_univer) {
		this.student_last_univer = student_last_univer;
	}

	public String getStudent_person_in_charge() {
		return student_person_in_charge;
	}

	public void setStudent_person_in_charge(String student_person_in_charge) {
		this.student_person_in_charge = student_person_in_charge;
	}
	
	public Date getStudent_hs_start_date() {
		return student_hs_start_date;
	}

	public void setStudent_hs_start_date(Date student_hs_start_date) {
		this.student_hs_start_date = student_hs_start_date;
	}

	public Date getStudent_hs_end_date() {
		return student_hs_end_date;
	}

	public void setStudent_hs_end_date(Date student_hs_end_date) {
		this.student_hs_end_date = student_hs_end_date;
	}

	public void setStudent_id(String student_id) {
		if(student_id != null && !student_id.trim().equals(""))
		this.student_id = Integer.parseInt(student_id);
	}
	
	public String getEmergency_contact() {
		return emergency_contact;
	}

	public void setEmergency_contact(String emergency_contact) {
		this.emergency_contact = emergency_contact;
	}
	
	public boolean isGraduated() {
		return graduated;
	}

	public void setGraduated(boolean graduated) {
		this.graduated = graduated;
	}
	
	public int getReligious() {
		return religious;
	}

	public void setReligious(String religious) {
		if(religious != null && !religious.trim().equals(""))
		this.religious = Integer.parseInt(religious);
	}
	
	public String getZone_name() {
		return zone_name;
	}

	public void setZone_name(String zone_name) {
		this.zone_name = zone_name;
	}

	public String getDistrict_name() {
		return district_name;
	}

	public void setDistrict_name(String district_name) {
		this.district_name = district_name;
	}
	
	public int getCadre() {
		return cadre;
	}

	public void setCadre(String cadre) {
		if(cadre != null)
			this.cadre = Integer.parseInt(cadre);
	}
	
	public int getAdvisor_id() {
		return advisor_id;
	}

	public void setAdvisor_id(String advisor_id) {
		if(advisor_id != null && !advisor_id.trim().equals(""))
			this.advisor_id = Integer.parseInt(advisor_id);
	}
	
	public String getCohort_name() {
		return cohort_name;
	}

	public void setCohort_name(String cohort_name) {
		this.cohort_name = cohort_name;
	}
	
	public int getCohort_id() {
		return cohort_id;
	}

	public void setCohort_id(String cohort_id) {
		if(cohort_id != null && !cohort_id.trim().equals(""))
			this.cohort_id = Integer.parseInt(cohort_id);
	}

}
