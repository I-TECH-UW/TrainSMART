package ts.ds;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import ts.gui.Utils;

public class Tutor{
	
	int tutor_id = 0;
	int inst_id =0;
	int facility_id =0;
	String facility_district_location_id = "0";
	String tutor_since = "";
	String tutor_time_here = "";
	String degree_inst = "";
	int degree_id = 0;
	String degree_year = "";
	String positionsheld = "";
	
	//list of languages ids
	List<String> languages = new ArrayList<String>();
	//list of type ids
	List<String> types = new ArrayList<String>();
	
	public Tutor(){
		
	}
	
//	// hash of keys: tutor_id, person_id, first_name, middle_name, last_name
//	public Tutor(LinkedHashMap<String, String> data) throws Exception{
//		super(data);
//		if(data != null){
//			setTutor_id(Integer.parseInt(data.get("tutor_id")));
//		}
//	}
	
	public void init(LinkedHashMap<String, String> data) throws Exception{
		if(data != null){
			
			//Utils.printRawData(data);
			
			setTutor_id(data.get("tutor_id"));
			setInst_id(data.get("institutionid"));
			setFacility_id(data.get("facilityid"));
			setTutor_since(data.get("tutorsince"));
			setTutor_time_here(data.get("tutortimehere"));
			setDegree_inst(data.get("degreeinst"));
			setDegree_id(data.get("degree"));
			setDegree_year(data.get("degreeyear"));
			setPositionsheld(data.get("positionsheld"));
			setFacility_district_location_id(data.get("facility_location_id"));
		}
	}

	public String getFacility_district_location_id() {
		return facility_district_location_id;
	}

	public void setFacility_district_location_id(String facility_district_location_id) {
		if(facility_district_location_id != null)
			this.facility_district_location_id = facility_district_location_id;
	}

	public List<String> getTypes() {
		return types;
	}

	public void setTypes(List<String> types) {
		this.types = types;
	}

	public List<String> getLanguages() {
		return languages;
	}

	public void setLanguages(List<String> languages) {
		this.languages = languages;
	}

	public String getPositionsheld() {
		return positionsheld;
	}

	public void setPositionsheld(String positionsheld) {
		this.positionsheld = positionsheld;
	}

	public String getDegree_year() {
		return degree_year;
	}

	public void setDegree_year(String degree_year) {
		if(degree_year != null){
			if(degree_year.trim().equals("0"))
				degree_year = "";
		}
		this.degree_year = degree_year;
	}

	public int getDegree_id() {
		return degree_id;
	}

	public void setDegree_id(String degree_id) {
		if(degree_id != null && !degree_id.trim().equals(""))
			this.degree_id = Integer.parseInt(degree_id);
	}

	public String getDegree_inst() {
		return degree_inst;
	}

	public void setDegree_inst(String degree_inst) {
		this.degree_inst = degree_inst;
	}

	public String getTutor_time_here() {
		return tutor_time_here;
	}

	public void setTutor_time_here(String tutor_time_here) {
		if(tutor_time_here == null){
			this.tutor_time_here = "";
		}else{
			this.tutor_time_here = tutor_time_here.trim();
			if(tutor_time_here.equals("0"))
				this.tutor_time_here = "";
		}
	}

	public String getTutor_since() {
		return tutor_since;
	}

	public void setTutor_since(String tutor_since) {
		if(tutor_since == null){
			this.tutor_since = "";
		}else{
			this.tutor_since = tutor_since.trim();
			if(tutor_since.equals("0"))
				this.tutor_since = "";
		}
	}

	public int getTutor_id() {
		return tutor_id;
	}

	public void setTutor_id(String tutor_id) {
		if(tutor_id != null && !tutor_id.trim().equals(""))
		this.tutor_id = Integer.parseInt(tutor_id);
	}
	
	public int getInst_id() {
		return inst_id;
	}

	public void setInst_id(String inst_id) {
		if(inst_id != null && !inst_id.trim().equals(""))
		this.inst_id = Integer.parseInt(inst_id);
	}

	public int getFacility_id() {
		return facility_id;
	}

	public void setFacility_id(String facility_id) {
		if(facility_id != null && !facility_id.trim().equals(""))
		this.facility_id = Integer.parseInt(facility_id);
	}
	
	

}
