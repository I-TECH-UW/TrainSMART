package ts.ds;

import java.util.LinkedHashMap;

public class Cohort {
	
	int id = 0;
	String name;
	String degree;
	String institution;
	String cadre;
	String start_date = "0000-00-00";
	String grad_date = "0000-00-00";
	int participants_start = 0;
	int participants_dropped = 0;
	int participants_current = 0;
	
	public Cohort(){	
	}
	
	public Cohort(LinkedHashMap<String, String> info){
		if(info != null){
			this.setId(Integer.parseInt(info.get("id")));
			this.setName(info.get("cohortname"));
			this.setDegree(info.get("degreename"));
			this.setInstitution(info.get("institutionname"));
			this.setCadre(info.get("cadrename"));
			this.setStart_date(info.get("startdate"));
			this.setGrad_date(info.get("graddate"));
			this.setParticipants_start(Integer.parseInt(info.get("students_count")));
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

	public String getCadre() {
		return cadre;
	}

	public void setCadre(String cadre) {
		this.cadre = cadre;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getGrad_date() {
		return grad_date;
	}

	public void setGrad_date(String grad_date) {
		this.grad_date = grad_date;
	}

	public int getParticipants_start() {
		return participants_start;
	}

	public void setParticipants_start(int participants_start) {
		this.participants_start = participants_start;
	}

	public int getParticipants_dropped() {
		return participants_dropped;
	}

	public void setParticipants_dropped(int participants_dropped) {
		this.participants_dropped = participants_dropped;
	}

	public int getParticipants_current() {
		return participants_current;
	}

	public void setParticipants_current(int participants_current) {
		this.participants_current = participants_current;
	}
	
}
