package ts.ds;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import ts.gui.Utils;

public class Person {
	
	int person_id = 0;
	String first_name = null;
	String middle_name = null;
	String last_name = null;
	int title = 0;
	String national_id = null;
	Date birth_date = null;
	String marital_status = null;
	String spouse_name = null;
	int nationality = 0;
	String gender = null;
	String address1 = null;
	String address2 = null;
	String city = null;
	String postal_code = null;
	boolean home_is_residential = false;
	String phone = null;
	String cell_phone = null;
	String cell_phone2 = null;
	String email = null;
	String email2 = null;
	String comments = null;
	String custom_field1 = null;
	String custom_field2 = null;
	String custom_field3 = null;
	int facility_id = 0;
	int home_location_id = 0;
	String home_district_name = "";
	String home_zone_name = "";
	
	Student student = new Student();
	Tutor tutor = new Tutor();
	
	public Person(){	
	}
	
	// hash of keys: person_id, first_name, middle_name, last_name
		public Person(LinkedHashMap<String, String> data) throws Exception{
			
			//Utils.printRawData(data);
			
			if(data != null){
				setPersonId(Integer.parseInt(data.get("person_id")));
				setFirst_name(data.get("first_name"));
				setMiddle_name(data.get("middle_name"));
				setLast_name(data.get("last_name"));
				setTitle(data.get("title_option_id"));
				setNational_id(data.get("national_id"));
				setBirth_date(Utils.getDate(data.get("birthdate")));
				setMarital_status(data.get("marital_status"));
				setSpouse_name(data.get("spouse_name"));
				setNationality(data.get("nationality_id"));
				setGender(data.get("gender"));
				setAddress1(data.get("home_address_1"));
				setAddress2(data.get("home_address_2"));
				setCity(data.get("home_city"));
				setPostal_code(data.get("home_postal_code"));
				setHome_is_residential((data.get("home_is_residential") != null && Integer.parseInt(data.get("home_is_residential")) == 1)?true:false);	
				setPhone(data.get("phone_work"));
				setCell_phone(data.get("phone_mobile"));
				setCell_phone2(data.get("phone_home"));
				setEmail(data.get("email"));
				setEmail2(data.get("email_secondary"));
				setComments(data.get("person_comments"));
				setCustom_field1(data.get("custom_field1"));
				setCustom_field2(data.get("custom_field2"));
				setCustom_field3(data.get("custom_field3"));
				setFacility_id(data.get("facility_id"));
				setHome_location_id(data.get("home_location_id"));
				
				student.init(data);
				tutor.init(data);
			}
		}
		
		public void setInst_id(String inst_id) {
			student.setInst_id(inst_id);
			tutor.setInst_id(inst_id);
		}
		
		public String getHome_zone_name() {
			return home_zone_name;
		}

		public void setHome_zone_name(String home_zone_name) {
			this.home_zone_name = home_zone_name;
		}

		public String getHome_district_name() {
			return home_district_name;
		}

		public void setHome_district_name(String home_district_name) {
			this.home_district_name = home_district_name;
		}

		public int getHome_location_id() {
			return home_location_id;
		}

		public void setHome_location_id(String home_location_id) {
			if(home_location_id != null && !home_location_id.trim().equals(""))
			this.home_location_id = Integer.parseInt(home_location_id);
		}

		public int getFacility_id() {
			return facility_id;
		}

		public void setFacility_id(String facility_id) {
			if(facility_id != null && !facility_id.trim().equals(""))
				this.facility_id = Integer.parseInt(facility_id);
		}

		public Student getStudent() {
			return student;
		}

		public void setStudent(Student student) {
			this.student = student;
		}

		public String getCustom_field1() {
			return custom_field1;
		}

		public void setCustom_field1(String custom_field1) {
			this.custom_field1 = custom_field1;
		}

		public String getCustom_field2() {
			return custom_field2;
		}

		public void setCustom_field2(String custom_field2) {
			this.custom_field2 = custom_field2;
		}

		public String getCustom_field3() {
			return custom_field3;
		}

		public void setCustom_field3(String custom_field3) {
			this.custom_field3 = custom_field3;
		}

		public String getComments() {
			return comments;
		}

		public void setComments(String comments) {
			this.comments = comments;
		}

		public String getPhone() {
			return phone;
		}

		public void setPhone(String phone) {
			this.phone = phone;
		}

		public String getCell_phone() {
			return cell_phone;
		}

		public void setCell_phone(String cell_phone) {
			this.cell_phone = cell_phone;
		}

		public String getCell_phone2() {
			return cell_phone2;
		}

		public void setCell_phone2(String cell_phone2) {
			this.cell_phone2 = cell_phone2;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getEmail2() {
			return email2;
		}

		public void setEmail2(String email2) {
			this.email2 = email2;
		}



		public boolean isHome_is_residential() {
			return home_is_residential;
		}

		public void setHome_is_residential(boolean home_is_residential) {
			this.home_is_residential = home_is_residential;
		}

		public String getAddress1() {
			return address1;
		}

		public void setAddress1(String address1) {
			this.address1 = address1;
		}

		public String getAddress2() {
			return address2;
		}

		public void setAddress2(String address2) {
			this.address2 = address2;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getPostal_code() {
			return postal_code;
		}

		public void setPostal_code(String postal_code) {
			this.postal_code = postal_code;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public int getNationality() {
			return nationality;
		}

		public void setNationality(String nationality) {
			if(nationality != null)
			this.nationality = Integer.parseInt(nationality);
		}

		public String getMarital_status() {
			return marital_status;
		}

		public void setMarital_status(String marital_status) {
			this.marital_status = marital_status;
		}

		public String getSpouse_name() {
			return spouse_name;
		}

		public void setSpouse_name(String spouse_name) {
			this.spouse_name = spouse_name;
		}

		public Date getBirth_date() {
			return birth_date;
		}

		public void setBirth_date(Date birth_date) {
			this.birth_date = birth_date;
		}

		public String getNational_id() {
			return national_id;
		}

		public void setNational_id(String national_id) {
			this.national_id = national_id;
		}

		public int getTitle() {
			return title;
		}

		public void setTitle(String title) {
			if(title != null)
			this.title = Integer.parseInt(title);
		}

		public int getPersonId() {
			return person_id;
		}

		public void setPersonId(int person_id) {
			this.person_id = person_id;
		}

		public String getFirst_name() {
			return first_name;
		}

		public void setFirst_name(String first_name) {
			this.first_name = first_name;
		}

		public String getMiddle_name() {
			return middle_name;
		}

		public void setMiddle_name(String middle_name) {
			this.middle_name = middle_name;
		}

		public String getLast_name() {
			return last_name;
		}

		public void setLast_name(String last_name) {
			this.last_name = last_name;
		}
		
		public String getFullName(){
			List<String> full_name_arr = new ArrayList<String>();
			String first_name = getFirst_name();
			if(first_name != null && !first_name.trim().equals(""))
				full_name_arr.add(first_name.trim());
			String middle_name = getMiddle_name();
			if(middle_name != null && !middle_name.trim().equals(""))
				full_name_arr.add(middle_name.trim());
			String last_name = getLast_name();
			if(last_name != null && !last_name.trim().equals(""))
				full_name_arr.add(last_name.trim());
			return String.join(" ", full_name_arr);
		}
		
		

		
	public Tutor getTutor() {
			return tutor;
		}

		public void setTutor(Tutor tutor) {
			this.tutor = tutor;
		}

	public boolean isStudent(){
		return getStudent().getPrimary_key_student_id() != 0;
	}
	
	public boolean isTutor(){
		return getTutor().getTutor_id() != 0;
	}
	
	public boolean isNew(){
		return getPersonId() == 0;
	}
		
}
