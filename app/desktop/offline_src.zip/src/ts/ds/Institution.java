package ts.ds;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class Institution {
	
	int id = 0;
	String name = new String();
	String address1 = new String();
	String address2 = new String();
	String city = new String();
	String postal_code = new String();
	String phone = new String();
	String fax = new String();
	int computer_count = 0;
	int tutor_count = 0;
	int student_count = 0;
	int dorm_count = 0;
	int bed_count = 0;
	boolean has_dorm = false;
	boolean tutor_house = false;
	int tutor_house_count = 0;
	String year_founded = new String("0");
	String comments = new String();
	String zone_name = new String();
	String district_name = new String();
	String type = new String();
	String sponsor = new String();
	List<String> cadres = new ArrayList<String>();
	List<String> quals = new ArrayList<String>();;
	
	public Institution(){	
	}
	
	public Institution(LinkedHashMap<String, String> info){
		if(info != null){
			this.setId(Integer.parseInt(info.get("id")));
			this.setName(info.get("institutionname"));
			this.setAddress1(info.get("address1"));
			this.setAddress2(info.get("address2"));
			this.setCity(info.get("city"));
			this.setPostal_code(info.get("postalcode"));
			this.setPhone(info.get("phone"));
			this.setFax(info.get("fax"));
			this.setZone_name(info.get("geo1_name"));
			this.setDistrict_name(info.get("geo2_name"));
			this.setType(info.get("type_name"));
			this.setSponsor(info.get("sponsor_name"));
			this.setComputer_count(info.get("computercount") != null?Integer.parseInt(info.get("computercount")):0);
			this.setTutor_count(info.get("tutor_count") != null?Integer.parseInt(info.get("tutor_count")):0);
			this.setStudent_count(info.get("active_student_count") != null?Integer.parseInt(info.get("active_student_count")):0);
			this.setHas_dorm(Integer.parseInt(info.get("hasdormitories"))==1?true:false);
			this.setDorm_count(info.get("dormcount") != null?Integer.parseInt(info.get("dormcount")):0);
			this.setBed_count(info.get("bedcount") != null?Integer.parseInt(info.get("bedcount")):0);
			this.setTutor_house(Integer.parseInt(info.get("tutorhousing"))==1?true:false);
			this.setTutor_house_count(info.get("tutorhouses") != null?Integer.parseInt(info.get("tutorhouses")):0);
			this.setYear_founded(info.get("yearfounded"));
			this.setComments(info.get("comments"));
		}
	}
	

	public List<String> getQuals() {
		return quals;
	}

	public void setQuals(List<String> quals) {
		this.quals = quals;
	}

	public List<String> getCadres() {
		return cadres;
	}

	public void setCadres(List<String> cadres) {
		this.cadres = cadres;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSponsor() {
		return sponsor;
	}

	public void setSponsor(String sponsor) {
		this.sponsor = sponsor;
	}

	public String getZone_name() {
		return zone_name;
	}

	public void setZone_name(String zone_name) {
		this.zone_name = zone_name;
	}

	public String getDistrict_name() {
		return district_name;
	}

	public void setDistrict_name(String district_name) {
		this.district_name = district_name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostal_code() {
		return postal_code;
	}

	public void setPostal_code(String postal_code) {
		this.postal_code = postal_code;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}
	
	public int getComputer_count() {
		return computer_count;
	}

	public void setComputer_count(int computer_count) {
		this.computer_count = computer_count;
	}

	public int getTutor_count() {
		return tutor_count;
	}

	public void setTutor_count(int tutor_count) {
		this.tutor_count = tutor_count;
	}

	public int getStudent_count() {
		return student_count;
	}

	public void setStudent_count(int student_count) {
		this.student_count = student_count;
	}

	public int getDorm_count() {
		return dorm_count;
	}

	public void setDorm_count(int dorm_count) {
		this.dorm_count = dorm_count;
	}

	public int getBed_count() {
		return bed_count;
	}

	public void setBed_count(int bed_count) {
		this.bed_count = bed_count;
	}

	public boolean isHas_dorm() {
		return has_dorm;
	}

	public void setHas_dorm(boolean has_dorm) {
		this.has_dorm = has_dorm;
	}

	public boolean isTutor_house() {
		return tutor_house;
	}

	public void setTutor_house(boolean tutor_house) {
		this.tutor_house = tutor_house;
	}

	public int getTutor_house_count() {
		return tutor_house_count;
	}

	public void setTutor_house_count(int tutor_house_count) {
		this.tutor_house_count = tutor_house_count;
	}

	public String getYear_founded() {
		return year_founded;
	}

	public void setYear_founded(String year_founded) {
		if(year_founded == null || year_founded.trim().equals(""))
			this.year_founded = "0";
		this.year_founded = year_founded;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
