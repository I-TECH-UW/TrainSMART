package ts.ds;

import java.util.LinkedHashMap;

public class Facility {
	
	int id = 0;
	String name;
	String zone_name = new String();
	String district_name = new String();
	
	// hash of keys: id, facility_name, district_name, zone_name
	public Facility(LinkedHashMap<String, String> data){
		if(data != null){
			setId(Integer.parseInt(data.get("id")));
			setName(data.get("facility_name"));
			setZone_name(data.get("zone_name"));
			setDistrict_name(data.get("district_name"));
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getZone_name() {
		return zone_name;
	}

	public void setZone_name(String zone_name) {
		this.zone_name = zone_name;
	}

	public String getDistrict_name() {
		return district_name;
	}

	public void setDistrict_name(String district_name) {
		this.district_name = district_name;
	}
	
	public String getNameWithLocations(){
		return getName() + " (" + getDistrict_name() + ", " + getZone_name() + ")";
	}
	
	public static String getPlainNameFromFullName(String full_name){
		if(full_name != null){
			return (full_name.trim().split("\\("))[0].trim();
		}
		return "";
	}

}
