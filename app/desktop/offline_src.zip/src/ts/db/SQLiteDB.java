/**
 * This is singleton class gets access to database and gets results from database
 * 
 * @author Tamara Astakhova (tamara7@uw.edu)
 * 
 */

package ts.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import org.sqlite.util.StringUtils;

import ts.config.Config;
import ts.ds.Cohort;
import ts.ds.Institution;
import ts.ds.Person;
import ts.ds.Student;
import ts.ds.Tutor;
import ts.gui.Utils;
import ts.gui.components.PersonEditPagePanel;
import ts.gui.components.TSFrame;

public final class SQLiteDB {
	
	public static final String _EMPTY_VALUE_STRING = "N/A";
	
	private boolean print_all = false;
	
	public static Connection conn;
	private Statement stmt;
	public static SQLiteDB db;
	
	public int last_cohort_id = 0;
	public int user_id = 0;
	
	//private static int _VPK_INSTITUTION = 0;
	
	/**
	 * Singleton database access
	 */
	private SQLiteDB() throws Exception{
	}
	
	 /* ============================================ General methods  =======================================================*/
	
	
	/**
	 * Database connection object
	 * @return
	 */
	public static synchronized SQLiteDB getDBConn() throws Exception{
		if(db == null){
			db = new SQLiteDB();
		}
		String db_sql_file = "";
		if(conn == null){
			try {
			Class.forName("org.sqlite.JDBC");
			
			//get db sql file, get first file that contains in name 'trainsmart.active.sqlite'
			// actually it is [user_id]_trainsmart.active.sqlite
			File[] files = new File(Config.__DB_PATH).listFiles();
			for (File file : files) {
			    if (file.isFile()) {
			    	db_sql_file = file.getName();
			    	if(db_sql_file.indexOf(Config.__DB_FILE) != 0){
			    		break;
			    	}
			    }
			}
			
			db_sql_file = Config.__DB_PATH + db_sql_file;
			  
		      System.out.println("Connection to database:" + db_sql_file + "\n");
		      conn = DriverManager.getConnection("jdbc:sqlite:" + db_sql_file);
		      }catch(Exception e){
				e.getStackTrace();
				throw new Exception("Cannot connect to database:" + db_sql_file + "\n" + e.getMessage());
				}
		}
		return db;
	}
	
	/**
	 * close Connection and ResultSet interfaces extends from AutoCloseable interface
	 * @param ac
	 */
	public void closeResource(AutoCloseable ac) {
	    try {
	        if (ac != null) {
	            ac.close();
	        }
	    } catch (Exception e) {
	    	e.getStackTrace();
	    }
	}
	
	
	/**
    *
    * @param query String The query to be executed
    * @return a ResultSet object containing the results or null if not available
    * @throws SQLException
    */
   private ResultSet query(String query) throws Exception{
	   stmt = conn.createStatement();
	   if(print_all)
		   System.out.println(query + "\n");
       ResultSet res = stmt.executeQuery(query);
       return res;
   }
   
   /**
    * Converts ResultSet to List of Hash <key, value> where key - column name, value - column value
    * @param query
    * @return
    * @throws Exception
    */
   private List<LinkedHashMap<String, String>> getResultAsHash(String query) throws Exception{
	  List<LinkedHashMap<String, String>> results = new ArrayList<LinkedHashMap<String, String>>();
	   ResultSet rs = null;
	   try{
	   rs = query(query);
	   if(rs != null){
		   ResultSetMetaData md = rs.getMetaData();
		   int columns = md.getColumnCount();
		   while(rs.next()) {
			   LinkedHashMap<String, String> row = new LinkedHashMap<String, String>(columns);
			   for(int i=1; i<=columns; ++i){ 
				   	  if(row.get(md.getColumnName(i)) == null)
				   		  row.put(md.getColumnName(i),rs.getString(i));
				   	  else
				   		 System.err.println("WARNING:" + md.getColumnName(i) + " is duplicated.");
			   }
			   results.add(row);
		   }
	   }
	   }catch ( Exception e ) {
		   e.getStackTrace();
		      throw new Exception(e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	   return results;
   }
   
   /**
    * Method to update or insert record to database
    */
   public void update(String updateQuery) throws SQLException{
	   stmt = conn.createStatement();
	   if(print_all)
		   System.out.println(updateQuery + "\n");
	   stmt.executeUpdate(updateQuery);
	   stmt.close();
   }
   
   /* ============================================ All methods to get data =======================================================*/
	
   /**
    * Get details about institute, their cohorts and students count in cohort (institute student count is sum of its cohorts student counts)
    * @return list of hash with keys ( inst_id, institutionname, inst_student_count, inst_student_count, cohortname, cohort_student_count)
    */
	public List<LinkedHashMap<String, String>> getInstituteWithCohortAndStudentCount() throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="select institution.id as inst_id, institution.institutionname,  cohort.id as cohort_id, cohort.cohortname, "
		      		+ "(select count(*) from link_student_cohort where id_cohort=cohort.id) as cohort_student_count, "
		    		+ "(SELECT count(*) FROM link_student_cohort WHERE link_student_cohort.id_cohort = cohort.id AND dropdate = '0000-00-00' and cohort.graddate >= date('now') and cohort.startdate <= date('now')) as active_students "
		      		+ " from institution left join cohort on institutionid=institution.id order by inst_id, cohort.id";
		      //show only institution with active student more than 0
		     sql = "select * from (" + sql + ") as temp where temp.active_students >0";
		    // System.out.println(sql);
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		      throw new Exception("Cannot get Institutes With Cohorts details.\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public List<LinkedHashMap<String, String>> getInstituteStudentCount() throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="select cohort.institutionid, count(*) as count from link_student_cohort  join cohort on id_cohort=cohort.id " +
		    		  "group by cohort.institutionid";
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		      throw new Exception("Cannot get Institutes student count.\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	//set user id from _app table, user who downloaded sqlite db from website
	public void setUser_id() throws Exception{
		ResultSet rs = null;
		 try {
		      String sql ="select user_id from _app where id=0";
		      List<LinkedHashMap<String, String>> res = getResultAsHash(sql);
		      if(res != null && res.size()>0){
		    	  user_id = Integer.parseInt(res.get(0).get("user_id"));
		      }
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		      throw new Exception(e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public int getUser_id() throws Exception{
		if(user_id == 0){
			try{
				setUser_id();
			}catch(Exception e){
				throw new Exception("Error occurs to get user_id. " + e.getMessage());
			}
		}
		return user_id;
	}
	
	/**
	 * Get details about all institutes
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getAllInstitutesInfo() throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="select institution.id as inst_id, institution.institutionname as inst_name, lookup_sponsors.sponsorname as sponsor_name, lookup_institutiontype.typename as type_name, "
		      		+ "location1.location_name as geo1, location2.location_name as geo2, location2.location_name as geo3 from institution "
		      		+ "left join lookup_sponsors on lookup_sponsors.id=institution.sponsor "
		      		+ "left join lookup_institutiontype on lookup_institutiontype.id=institution.type "
		      		+ "left join location as location1 on location1.id=institution.geography1 "
		      		+ "left join location as location2 on location2.id=institution.geography2 "
		      		+ "left join location as location3 on location3.id=institution.geography3 order by institution.id";
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		      throw new Exception(e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public LinkedHashMap<String, String> getInstituteById(String id) throws Exception{
		ResultSet rs = null;
		 try {
		      String sql ="select institution.*, lookup_sponsors.sponsorname as sponsor_name, lookup_institutiontype.typename as type_name, "
		    		 + "(SELECT COUNT(*) AS totalcount FROM student "
+ " INNER JOIN link_student_cohort ON link_student_cohort.id_student = student.id "
+ " INNER JOIN cohort ON link_student_cohort.id_cohort = cohort.id "
+ " WHERE (cohort.institutionid = " + id + ") "
+ " AND (link_student_cohort.dropdate = '0000-00-00') "
+ " AND (cohort.graddate >= date('now')) "
+ " AND (cohort.startdate <= date('now'))) as active_student_count, "
+ "(select count(*) from link_tutor_institution where id_institution=" + id + ") as tutor_count, "
		      		+ "location1.location_name as geo1_name, location2.location_name as geo2_name, location2.location_name as geo3_name from institution "
		      		+ "left join lookup_sponsors on lookup_sponsors.id=institution.sponsor "
		      		+ "left join lookup_institutiontype on lookup_institutiontype.id=institution.type "
		      		+ "left join location as location1 on location1.id=institution.geography1 "
		      		+ "left join location as location2 on location2.id=institution.geography2 "
		      		+ "left join location as location3 on location3.id=institution.geography3 where institution.id=" + id;
		      List<LinkedHashMap<String, String>> result = getResultAsHash(sql);
		      if(result.size() >0){
		    	  return result.get(0);
		      }
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		      throw new Exception(e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
		 return null;
	}
	
	/*
	 * Hash of zones with distrcits
	 * key - zone name ((alphabetically ordered)
	 * value - list of districts for this zone (alphabetically ordered)
	 */
	public LinkedHashMap<String, List<String>> getAllZonesWithDistricts() throws Exception{
		LinkedHashMap<String, List<String>> results = new LinkedHashMap<String, List<String>>();
		ResultSet rs = null;
		try {
			String sql = "select district_location.id as district_location_id,  district_location.location_name as district_location_name, "
					+ "district_location.tier as district_location_tier, district_location.parent_id as district_location_parent_id, "
					+ "zone_location.location_name as zone_location_name, zone_location.tier as zone_location_tier from location as district_location "
					+ "left join location as zone_location on district_location.parent_id=zone_location.id "
					+ "where district_location.tier =2 order by zone_location.location_name, district_location.location_name";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					String zone = rs.getString("zone_location_name");
					List<String> districts = results.get(zone);
					if(districts == null){
						districts = new ArrayList<String>();
					}
					districts.add(rs.getString("district_location_name"));
					results.put(zone, districts);
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all location names by tier
	 * 
	 * @return
	 */
	public List<String> getAllLocationsByTier(int tier) throws Exception{
		List<String> results = new ArrayList<String>();
		ResultSet rs = null;
		try {
			String sql = "select location_name from location where tier=" + tier + " order by location_name";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(rs.getString("location_name"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * List of all zone names from location table with tier =1
	 */
	public List<String> getAllZones() throws Exception{
		return getAllLocationsByTier(1);
	}
	
	/**
	 * List all district names from location table with tier =2 
	 */
	public List<String> getAllDistricts() throws Exception{
		return getAllLocationsByTier(2);
	}
	
	/**
	 * Gets list of all institution types
	 * 
	 * @return
	 */
	public List<String> getAllInstitutionTypes() throws Exception{
		List<String> results = new ArrayList<String>();
		ResultSet rs = null;
		try {
			String sql = "select typename from lookup_institutiontype order by typename";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(rs.getString("typename"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all institution names with ids
	 */
	public List<String[]> getAllInstitutionTypesWithIds() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from lookup_institutiontype order by typename";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("typename")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get institutions anmes.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all sponsors 
	 * 
	 * @return
	 */
	public List<String> getAllSponsors() throws Exception{
		List<String> results = new ArrayList<String>();
		ResultSet rs = null;
		try {
			String sql = "select sponsorname from lookup_sponsors order by sponsorname";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(rs.getString("sponsorname"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all cadres 
	 * 
	 * @return
	 */
	public List<String[]> getAllCadres() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select id,cadrename from cadres order by cadrename";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{rs.getString("id"), rs.getString("cadrename")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all cadres 
	 * 
	 * @return
	 */
	public List<String> getAllCadresNames() throws Exception{
		List<String> results = new ArrayList<String>();
		ResultSet rs = null;
		try {
			String sql = "select id,cadrename from cadres order by cadrename";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(rs.getString("cadrename"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all cadres for institution
	 * 
	 * @return
	 */
	public List<String> getInstutionCadres(int inst_id) throws Exception{
		List<String> results = new ArrayList<String>();
		ResultSet rs = null;
		try {
			String sql = "select cadrename from cadres INNER JOIN link_cadre_institution on id_cadre = cadres.id "
					+ "where status=1 and id_institution = '" + inst_id + "' order by cadrename;";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(rs.getString("cadrename"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all Qualifications 
	 * 
	 * @return
	 */
	public List<String> getAllQualifications() throws Exception {
		List<String> results = new ArrayList<String>();
		ResultSet rs = null;
		try {
			String sql = "select degree from lookup_degrees order by degree";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(rs.getString("degree"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all Qualifications With Ids 
	 */
	public List<String[]> getAllQualificationsWithIds() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select id, degree from lookup_degrees order by degree";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("degree")});
					//System.out.println("SEL:" + rs.getString("id") + "->" + rs.getString("degree"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get all Qualifications.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all cadres for institution
	 * 
	 * @return
	 */
	public List<String> getInstutionQualifications(int inst_id) throws Exception{
		List<String> results = new ArrayList<String>();
		ResultSet rs = null;
		try {
			String sql = "select degree from link_institution_degrees "
					+ "join lookup_degrees on lookup_degrees.id=id_degree where id_institution=" + inst_id + " order by degree";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(rs.getString("degree"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/*
	 * Add institution details with cadre and qualification
	 * @return new institution id
	 */
	public String addInstitution(Institution inst) throws Exception{
		ResultSet rs = null;
		String new_inst_id = null;
		try{
		String sql = "INSERT INTO institution (created_by, timestamp_created, institutionname, address1, address2, city, postalcode, phone, fax, type, sponsor, degrees,computercount,"
				+ "dormcount, bedcount, hasdormitories, tutorhousing, yearfounded, comments, customfield1, customfield2, geography1, geography2) "
				+ "VALUES ("
				+ this.getUser_id() + ", '" + Utils.getCurrentDateTime() + "',"
				+ "'" + inst.getName() + "','" + inst.getAddress1() + "','" + inst.getAddress2() + "','"
				+ inst.getCity() + "','" + inst.getPostal_code() + "','"  + inst.getPhone() + "','" + inst.getFax() + "',"
				+ "(CASE WHEN (select id from lookup_institutiontype where typename='" + inst.getType() + "') IS NULL THEN '0' ELSE (select id from lookup_institutiontype where typename='" + inst.getType() + "') END),"
				+ "(CASE WHEN (select id from lookup_sponsors where sponsorname='" + inst.getSponsor() + "') IS NULL THEN '0' ELSE (select id from lookup_sponsors where sponsorname='" + inst.getSponsor() + "') END),'',"
				+ String.valueOf(inst.getComputer_count()) + "," + String.valueOf(inst.getDorm_count()) + "," + String.valueOf(inst.getBed_count()) + ","
				+ String.valueOf(inst.isHas_dorm()==true?1:0) + "," + String.valueOf(inst.isTutor_house()==true?1:0) + ",'" + inst.getYear_founded() + "','"
				+ inst.getComments() + "','','',"
				+ "(CASE WHEN (select id from location where location_name='" + inst.getZone_name() + "' and tier=1) IS NULL THEN '0' ELSE (select id from location where location_name='" + inst.getZone_name() + "' and tier=1) END),"
				+ "(CASE WHEN (select id from location where location_name='" + inst.getDistrict_name() + "' and tier=2) IS NULL THEN '0' ELSE (select id from location where location_name='" + inst.getDistrict_name() + "' and tier=2) END)) ";
		update(sql);
		
		//get last institution id
				sql = "select max(id) as last_id from institution";
				rs = query(sql);
				if (rs != null) {
					while (rs.next()) {
						new_inst_id = rs.getString("last_id");
						break;
					}
				}
		inst.setId(Integer.parseInt(new_inst_id));	
		updateCadreForInstitution(inst);
		updateQualificationForInstitution(inst);
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update institution details for institution with id=" + inst.getId() + ".\n" + e.getMessage());
		    }finally {
		    	closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
		return new_inst_id;
	}
	
	/*
	 * Update institution details with cadre and qualification
	 */
	public void updateInstitution(Institution inst) throws Exception{
		try{
		String sql = "UPDATE institution SET "
				+ " modified_by=" + this.getUser_id()
				+ ", timestamp_updated='" + Utils.getCurrentDateTime() + "',"
				+ " institutionname='" + inst.getName() + "', address1='" + inst.getAddress1() + "', address2='" + inst.getAddress2() + "', "
				+ "city='" + inst.getCity() + "', postalcode='" + inst.getPostal_code() + "', phone='" + inst.getPhone() + "', fax='" + inst.getFax() + "', "
				+ "type=(CASE WHEN (select id from lookup_institutiontype where typename='" + inst.getType() + "') IS NULL THEN '0' ELSE (select id from lookup_institutiontype where typename='" + inst.getType() + "') END),  "
				+ "sponsor=(CASE WHEN (select id from lookup_sponsors where sponsorname='" + inst.getSponsor() + "') IS NULL THEN '0' ELSE (select id from lookup_sponsors where sponsorname='" + inst.getSponsor() + "') END),"
				+ "computercount=" + String.valueOf(inst.getComputer_count()) + ", dormcount=" + String.valueOf(inst.getDorm_count()) + ", bedcount=" + String.valueOf(inst.getBed_count()) + ", tutorhouses="+ String.valueOf(inst.getTutor_house_count()) + ","
				+ "hasdormitories=" + String.valueOf(inst.isHas_dorm()==true?1:0)+ ", tutorhousing=" + String.valueOf(inst.isTutor_house()==true?1:0) +", yearfounded='" + inst.getYear_founded() + "', comments='" + inst.getComments() + "', "
				+ "geography1=(CASE WHEN (select id from location where location_name='" + inst.getZone_name() + "' and tier=1) IS NULL THEN '0' ELSE (select id from location where location_name='" + inst.getZone_name() + "' and tier=1) END),"
				+ "geography2=(CASE WHEN (select id from location where location_name='" + inst.getDistrict_name() + "' and tier=2) IS NULL THEN '0' ELSE (select id from location where location_name='" + inst.getDistrict_name() + "' and tier=2) END) WHERE id=" + String.valueOf(inst.getId());
		update(sql);
		
		updateCadreForInstitution(inst);
		updateQualificationForInstitution(inst);
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update institution details for institution with id=" + inst.getId() + ".\n" + e.getMessage());
		    }finally {
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/*
	 * Update cadre for institution
	 */
	public void updateCadreForInstitution(Institution inst) throws Exception{
		try{
		String sql = "delete from link_cadre_institution where id_institution=" + inst.getId();
		update(sql);
		List<String> cadres = inst.getCadres();
		for(int i=0; i<cadres.size(); i++){
			sql = "insert into link_cadre_institution (id_cadre, id_institution) VALUES ((select id from cadres where cadrename='" + cadres.get(i) + "') , " + inst.getId() + ")";
			update(sql);
		}
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update cadre for institution with id=" + inst.getId() + ".\n" + e.getMessage());
		    }finally {
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/*
	 * Update qualification info for institution
	 */
	public void updateQualificationForInstitution(Institution inst) throws Exception{
		try{
		String sql = "delete from link_institution_degrees where id_institution=" + inst.getId();
		update(sql);
		List<String> quals = inst.getQuals();
		for(int i=0; i<quals.size(); i++){
			sql = "insert into link_institution_degrees (id_institution, id_degree) VALUES (" + inst.getId() + ", (select id from lookup_degrees where degree='" + quals.get(i) + "'))";
			update(sql);
		}
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update qualification for institution with id=" + inst.getId() + ".\n" + e.getMessage());
		    }finally {
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}

	/**
	 * Get details about all cohorts (id, name, start date, grad date, institution name, cadre, degree, number of students at start)
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getAllCohortsInfo() throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT cohort.*, institution.institutionname, cadres.cadrename, lookup_degrees.degree as degreename, "
		      		+ "count(cohort.cohortid) as students_count FROM cohort "
		      		+ "LEFT JOIN cadres ON cadres.id = cohort.cadreid "
		      		+ "LEFT JOIN institution ON institution.id = cohort.institutionid "
		      		+ "LEFT JOIN lookup_degrees on cohort.degree = lookup_degrees.id "
		      		+ "LEFT JOIN link_student_cohort ON link_student_cohort.id_cohort = cohort.id "
		      		+ "group by cohort.id ORDER BY cohortname, startdate, graddate";
		      List<LinkedHashMap<String, String>> cohort_info = getResultAsHash(sql);
		      if(last_cohort_id == 0) //set last cohort id come from remote database
		    	  last_cohort_id = cohort_info.size();
		      return cohort_info;
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		      throw new Exception("ERROR: cannot get all cohorts.\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/*
	 * TODO: Set last cohort id come from remote database. Do not allow user to delete cohort that added not by him.
	 */
	public int getLastCohortId(){
		return last_cohort_id;
	}
	
	/**
	 * Gets list of all institution name
	 */
	public List<String> getAllInstitutionNames() throws Exception{
		List<String> results = new ArrayList<String>();
		ResultSet rs = null;
		try {
			String sql = "select institutionname from institution order by institutionname";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(rs.getString("institutionname"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get institution names.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all facilities (id, facility_name, distrct_name, zone_name)
	 */
	public List<LinkedHashMap<String, String>> getAllFacilityWithLocation() throws Exception{
		ResultSet rs = null;
		try {
			String sql = "select facility.id, facility_name, l1.location_name as district_name, l2.location_name as zone_name from facility "
					+ "left join location as l1 on l1.id = facility.location_id "
					+ "left join location as l2 on l2.parent_id = l1.id order by facility_name, l1.location_name, l2.location_name";
			//System.out.println(sql);
			return getResultAsHash(sql);
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get facilities with their location info.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
	}
	
	/**
	 * Gets list of all facilities (person_id, tutor_id, first_name, middle_name, last_name)
	 */
	public List<LinkedHashMap<String, String>> getAllTutors() throws Exception{
		ResultSet rs = null;
		try {
			String sql = "select tutor.id as tutor_id, person.id as person_id, person.first_name, person.middle_name, person.last_name from person  "
					+ "join tutor on tutor.personid=person.id order by person.first_name, person.last_name";
			//System.out.println(sql);
			return getResultAsHash(sql);
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get tutors info.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
	}
	
	/*
	 * Get cohort by cohort id
	 */
	public LinkedHashMap<String, String> getCohortById(String id) throws Exception{
		ResultSet rs = null;
		 try {
			 String sql ="SELECT cohort.*, institution.institutionname, cadres.cadrename, lookup_degrees.degree as degreename, "
			      		+ "count(link_student_cohort.id) as students_count FROM cohort "
			      		+ "LEFT JOIN cadres ON cadres.id = cohort.cadreid "
			      		+ "LEFT JOIN institution ON institution.id = cohort.institutionid "
			      		+ "LEFT JOIN lookup_degrees on cohort.degree = lookup_degrees.id "
			      		+ "LEFT JOIN link_student_cohort ON link_student_cohort.id_cohort = cohort.id "
			      		//+ "WHERE (link_student_cohort.dropdate = '0000-00-00' OR link_student_cohort.dropdate = cohort.graddate) and " not show record
			      		+ "WHERE "
			      		+ " cohort.id=" + id 
			      		+ " group by cohort.id ORDER BY cohortname, startdate, graddate";
		      List<LinkedHashMap<String, String>> result = getResultAsHash(sql);
		      if(result.size() >0){
		    	  return result.get(0);
		      }
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		      throw new Exception("ERROR: cannot get cohort by id=" + id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
		 return null;
	}
	
	/*
	 * Get cohort student graduated count by cohort id
	 */
	public String getCohortStudentGraduatedCount(String cohort_id) throws Exception{
		ResultSet rs = null;
		 try {
			 String sql ="SELECT count(cohort.cohortid) as students_count_grad FROM cohort "
			 		+ "INNER JOIN link_student_cohort ON link_student_cohort.id_cohort = cohort.id "
			 		+ "WHERE (link_student_cohort.dropdate = '0000-00-00' OR link_student_cohort.dropdate = cohort.graddate) "
			      		+ " and cohort.id=" + cohort_id;
			rs = query(sql);
				if (rs != null) {
					while (rs.next()) {
						return rs.getString("students_count_grad");
					}
				}
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get student graduated count for cohort with id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
		 return null;
	}
	
	/*
	 * Get cohort student dropped count by cohort id
	 */
	public String getCohortStudentDroppedCount(String cohort_id) throws Exception{
		ResultSet rs = null;
		 try {
			 String sql ="SELECT count(cohort.cohortid) as students_count_drop FROM cohort "
			 		+ "INNER JOIN link_student_cohort ON link_student_cohort.id_cohort = cohort.id "
			 		+ "WHERE (link_student_cohort.dropdate <> '0000-00-00' AND link_student_cohort.dropdate < cohort.graddate) "
			      		+ " and cohort.id=" + cohort_id;
			rs = query(sql);
				if (rs != null) {
					while (rs.next()) {
						return rs.getString("students_count_drop");
					}
				}
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get student dropped count for cohort with id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
		 return null;
	}
	
	public String addCohort(Cohort cohort) throws Exception{
		ResultSet rs;
		String new_cohort_id = null;
		System.out.println(cohort.getInstitution());
		try{
			String sql = "INSERT INTO cohort (created_by, timestamp_created, cohortid, cohortname, startdate, graddate, degree, cadreid, institutionid) " 
					+ " VALUES (" 
					+ this.getUser_id() + ", '" + Utils.getCurrentDateTime() + "',"
					+ "'','" 
					+ cohort.getName() + "','" + cohort.getStart_date()
					+ "','" + cohort.getGrad_date() + "',"
					+ "(CASE WHEN (select id from lookup_degrees where degree='" + cohort.getDegree() + "') IS NULL THEN '0' "
					+ "ELSE (select id from lookup_degrees where degree='" + cohort.getDegree() + "') END),"
					+ "(CASE WHEN (select id from cadres where cadrename='" + cohort.getCadre() + "') IS NULL THEN '0' "
					+ "ELSE (select id from cadres where cadrename='" + cohort.getCadre() + "') END),"
					+ "(CASE WHEN (select id from institution where institutionname='" + cohort.getInstitution() + "') IS NULL THEN '0' "
					+ "ELSE (select id from institution where institutionname='" + cohort.getInstitution() + "') END))";
			System.out.println(sql);
			update(sql);
			
			//get last institution id
			sql = "select max(id) as last_id from cohort";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					new_cohort_id = rs.getString("last_id");
					break;
				}
			}
	
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot add cohort details with name=" + cohort.getName() + ".\n" + e.getMessage());
			    }finally {
			       // closeResource(conn); //TA:TODO close connection?????
			    }
		return new_cohort_id;
	}
	
	public void updateCohort(Cohort cohort) throws Exception{
		try{
			String sql = "UPDATE cohort SET "
					+ " modified_by=" + this.getUser_id()
					+ ", timestamp_updated='" + Utils.getCurrentDateTime() + "',"
					+ " cohortname='" + cohort.getName() + "', startdate='" + cohort.getStart_date() + "', "
					+ "graddate='" + cohort.getGrad_date() + "', degree="
					+ "(CASE WHEN (select id from lookup_degrees where degree='" + cohort.getDegree() + "') IS NULL THEN '0' "
					+ "ELSE (select id from lookup_degrees where degree='" + cohort.getDegree() + "') END), cadreid= "
					+ "(CASE WHEN (select id from cadres where cadrename='" + cohort.getCadre() + "') IS NULL THEN '0' "
					+ "ELSE (select id from cadres where cadrename='" + cohort.getCadre() + "') END),  institutionid= "
					+ "(CASE WHEN (select id from institution where institutionname='" + cohort.getInstitution() + "') IS NULL THEN '0' "
					+ "ELSE (select id from institution where institutionname='" + cohort.getInstitution() + "') END) " 
					+ " where id=" + String.valueOf(cohort.getId());
			update(sql);
			
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot update cohort details with id=" + cohort.getId() + ".\n" + e.getMessage());
			    }finally {
			       // closeResource(conn); //TA:TODO close connection?????
			    }
	}
	
	/*
	 * Delete cohort by id
	 */
	public void deleteCohort(String id) throws Exception{
		try{
			String sql = "DELETE FROM cohort where id=" + id;
			update(sql);
			// remove cohort class link
			sql = "DELETE FROM link_cohorts_classes WHERE cohortid=" + id;
			update(sql);
			// remove student cohort link
			sql = "DELETE FROM link_student_cohort WHERE id_cohort = " + id;
			update(sql);
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot delete cohort with id=" + id + ".\n" + e.getMessage());
			    }finally {
			       // closeResource(conn); //TA:TODO close connection?????
			    }
	}
	
	/**
	 * Get all students associated with cohort
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getAllStudentsAssociatedWithCohort(String cohort_id) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT person.id, person.first_name, person.last_name, person.gender, person.birthdate, "
		      		+ "student.id AS student_id, link_student_cohort.isgraduated, link_student_cohort.dropdate, link_student_cohort.joindate FROM person "
		      		+ "INNER JOIN student ON student.personid = person.id "
		      		+ "INNER JOIN link_student_cohort ON link_student_cohort.id_student = student.id WHERE (link_student_cohort.id_cohort = " + cohort_id + ") ORDER BY person.first_name";
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get students associated with cohort id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get all students for cohort
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getAllStudentsForCohort(String cohort_id) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT person.id, person.first_name, person.last_name, person.gender, person.birthdate, student.id as student_id FROM person "
		      		+ "INNER JOIN student ON student.personid = person.id "
		      		+ "WHERE (student.id NOT IN (SELECT id_student FROM link_student_cohort WHERE id_cohort != " + cohort_id + ")) ORDER BY person.last_name";
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get all students for cohort with id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public void updateAllStudentsAssociatedWithCohort(String cohort_id, List<String> associated_students_ids, List<String> not_associated_students_ids)throws Exception{
		try {
		      String sql ="delete from link_student_cohort where id_cohort=" + cohort_id + " and id_student in(" + StringUtils.join(not_associated_students_ids, ",") + ")";
		      update(sql);
		      for(int i=0; i<associated_students_ids.size(); i++){
		    	  sql = "INSERT INTO link_student_cohort (id_student, id_cohort, joindate) "
		    	  		+ "SELECT " + associated_students_ids.get(i) + "," + cohort_id + ",'" + Utils.getCurrentDate() + "' WHERE NOT EXISTS "
		    	  		+ "(SELECT id FROM link_student_cohort WHERE id_student=" + associated_students_ids.get(i) + " and id_cohort=" + cohort_id + ") LIMIT 1";
		    	 // System.out.println(sql);
		    	  update(sql);
		      }
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot update students for cohort with id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get all Licenses for cohort
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getAllLicensesForCohort(String cohort_id) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="select * from licenses WHERE cohortid = " + cohort_id + " ORDER BY licensedate DESC";
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get all Licenses for cohort with id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get delete License for cohort
	 * @return
	 */
	public void deleteLicenseForCohort(String license_id) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="delete from licenses WHERE id = " + license_id;
		      update(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot delete License with id=" + license_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * add License for cohort
	 * @return
	 */
	public void addLicenseForCohort(String cohort_id, String licence_name, Date licence_date) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="insert into licenses (licensename, licensedate, cohortid) values ('" + licence_name + "','" + Utils.getDate(licence_date) + "'," + cohort_id + ")";
		      update(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot add License for cohort with id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * edit License for cohort
	 * @return
	 */
	public void editLicenseForCohort(String licence_id, String licence_name, Date licence_date) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="update licenses set licensename='" + licence_name + "', licensedate='" + Utils.getDate(licence_date) + "' where id = " + licence_id;
		      update(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot edit License with id=" + licence_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get all classes associated with cohort
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getAllClassesAssociatedWithCohort(String cohort_id) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT classes.*, person.first_name, person.last_name, lct.coursetype FROM classes "
		      		+ "INNER JOIN link_cohorts_classes ON link_cohorts_classes.classid = classes.id "
		      		+ "LEFT JOIN tutor ON tutor.id = classes.instructorid "
		      		+ "LEFT JOIN person ON tutor.personid = person.id "
		      		+ "LEFT JOIN lookup_coursetype lct ON lct.id = classes.coursetypeid "
		      		+ "WHERE link_cohorts_classes.cohortid = '" + cohort_id + "' ORDER BY classes.classname, person.first_name, person.last_name";
		      //System.out.println(sql);
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get classes associated with cohort id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get all classes
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getAllClasses() throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT classes.*, person.first_name, person.last_name FROM classes "
		      		+ "LEFT JOIN tutor ON tutor.id = classes.instructorid "
		      		+ "LEFT JOIN person ON tutor.personid = person.id ORDER BY classes.classname, person.first_name, person.last_name";
		      //System.out.println(sql);
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get all classes.\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public void updateAllClassesAssociatedWithCohort(String cohort_id, List<String> associated_classes_ids, List<String> not_associated_classes_ids)throws Exception{
		try {
		      String sql ="delete from link_cohorts_classes where cohortid=" + cohort_id + " and classid in(" + StringUtils.join(not_associated_classes_ids, ",") + ")";
		      update(sql);
		      for(int i=0; i<associated_classes_ids.size(); i++){
		    	  sql = "INSERT INTO link_cohorts_classes (cohortid, classid, status) "
		    	  		+ "SELECT " + cohort_id + "," + associated_classes_ids.get(i) + ",1 WHERE NOT EXISTS "
		    	  		+ "(SELECT id FROM link_cohorts_classes WHERE classid=" + associated_classes_ids.get(i) + " and cohortid=" + cohort_id + ") LIMIT 1";
		    	  update(sql);
		      }
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot update classes for cohort with id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get all clinical allocation for cohort
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getAllClinicalForCohort(String cohort_id) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT practicum.*, facility.facility_name, person.first_name, person.last_name, person.id AS personid FROM practicum "
		      		+ "LEFT JOIN facility ON facility.id = practicum.facilityid "
		      		+ "LEFT JOIN tutor ON tutor.id = practicum.advisorid "
		      		+ "LEFT JOIN person ON person.id = tutor.personid WHERE cohortid = " + cohort_id + " ORDER BY practicumdate DESC, practicumname";
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get all Clinical Allocations for cohort with id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get delete Clinical allocation for cohort
	 * @return
	 */
	public void deleteClinicalForCohort(String clinical_id) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="delete from practicum WHERE id = " + clinical_id;
		      update(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot delete Clinical allocation with id=" + clinical_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * add Clinical allocation for cohort
	 * @return
	 */
	public void addClinicalForCohort(String cohort_id, String clinical_name, Date clinical_date, String facility_id, String tutor_id, String hours) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="insert into practicum (practicumname, practicumdate, facilityid, advisorid, hoursrequired, cohortid) values ('" + 
		 clinical_name + "','" + Utils.getDate(clinical_date) + "'," + facility_id + "," + tutor_id + "," + hours + "," + cohort_id + ")";
		      update(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot add clinical allocation for cohort with id=" + cohort_id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * edit Clinical allocation for cohort
	 * @return
	 */
	public void editClinicalForCohort(String id, String clinical_name, Date clinical_date, String facility_id, String tutor_id, String hours) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="update practicum set practicumname='" + clinical_name + "'," + 
		 "practicumdate='" + Utils.getDate(clinical_date) + "'," +
		  "facilityid=" + facility_id + "," +
		  "advisorid=" + tutor_id + "," +
		  "hoursrequired=" + hours + " where id=" + id;
		      update(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot edit clinical allocation with id=" + id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get details about all persons (person_id, first_name, middle_name, last_name, birthdate, qualification_phrase, facility_name, location_name, tutor_id)
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getAllPersonsInfo() throws Exception{
		 ResultSet rs = null;
		 try {
			 String sql ="select person.id as person_id, first_name, middle_name, last_name, birthdate, qualification_phrase, "
			      		+ "facility.facility_name, location.location_name, tutor.id as tutor_id, cohort.cohortname from person "
			      		+ "left join facility on person.facility_id=facility.id "
			      		+ "left join location on facility.location_id=location.id "
			      		+ "left join person_qualification_option on person_qualification_option.id=person.primary_qualification_option_id "
			      		+ "left join tutor on person.id=tutor.personid "
			      		+ "left join student on person.id=student.personid "
			      		+ "left join link_student_cohort on student.id=link_student_cohort.id_student "
			      		+ "left join cohort on cohort.id=link_student_cohort.id_cohort "
			      		+ "order by first_name";
			 System.out.println(sql);
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		      throw new Exception(e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/*
	 * Get student details by person id
	 */
	public LinkedHashMap<String, String> getStudentById(String id) throws Exception{
		ResultSet rs = null;
		 try {
			 
		      String sql ="select person.id as person_id, person.comments as person_comments, person.*, student.id as student_id_table, student.isgraduated as student_isgraduated, student . *,"
		      		+ "link_student_cohort.id_cohort as student_cohort_id, link_student_cohort . *,"
		      		+ "addresses.id as address_id, addresses.address1, addresses.address2, addresses.city,addresses.postalcode,addresses.state,addresses.country,"
		      		+ "id_geog1, id_geog2, id_geog3, cohort.id as cohort_id_record, cohort . *, cadres.id as cadres_id_record, cadres . *,"
		      		+ "loc_zone.location_name as zone, loc_district.location_name as district, loc_zone_perm.location_name as zone_perm, loc_district_perm.location_name as district_perm, "
		      		+ "loc_zone_post.location_name as post_zone_name, loc_district_post.location_name as post_district_name, "
		      		+ "tutor.id as tutor_id, tutor.degree as tutor_degree "
		      		+ "from person "
		      		+ "left join student ON person.id = student.personid "
        + "left join link_student_cohort ON link_student_cohort.id_student = student.id " //in link_student_cohort table id_student=student.id (as it is use online version)
        + "left join link_student_addresses ON link_student_addresses.id_student = student.id "
        + "left join addresses ON addresses.id = link_student_addresses.id_address "
        + "left join location as loc_zone ON student.geog1 = loc_zone.id "
        + "left join location as loc_district ON student.geog2 = loc_district.id "
        + "left join location as loc_zone_post ON student.postgeo1 = loc_zone_post.id "
        + "left join location as loc_district_post ON student.postgeo2 = loc_district_post.id "
        + "left join location as loc_zone_perm ON addresses.id_geog1 = loc_zone_perm.id "
        + "left join location as loc_district_perm ON addresses.id_geog2 = loc_district_perm.id "
        + "left join cohort ON cohort.id = link_student_cohort.id_cohort "
        + "left join cadres ON cadres.id = cohort.cadreid "
        + "left join tutor on person.id=tutor.personid "
			      		+ "where person.id=" + id;
		      //System.out.println(sql);
		      List<LinkedHashMap<String, String>> result = getResultAsHash(sql);
		      if(result.size() >0){
		    	  return result.get(0);
		      }
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: cannot get  student info for person id " + id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
		 return null;
	}
	
	/*
	 * Get tutor details by person id
	 */
	public LinkedHashMap<String, LinkedHashMap<String, String>> getTutorById(String id) throws Exception{
		ResultSet rs = null;
		LinkedHashMap<String, LinkedHashMap<String, String>> data = new LinkedHashMap<String, LinkedHashMap<String, String>>();
		 try {
		      String sql ="SELECT person.id as person_id, person.comments as person_comments, person.* FROM person where id=" + id;
		      List<LinkedHashMap<String, String>> result = getResultAsHash(sql);
		      if(result.size() >0){
		    	  data.put("person", result.get(0));
		      }
		      
		      sql ="SELECT tutor.id as tutor_id, tutor.*, facility.location_id as facility_locaction_id FROM tutor "
		    		  + "LEFT JOIN facility ON facility.id=tutor.facilityid "
		      		+ "WHERE personid = " + id;
		      result = getResultAsHash(sql);
		      if(result.size() >0){
		    	  data.put("tutor", result.get(0));
		      }
		      
		      sql ="SELECT address1, address2, city, postalcode, id_geog1, id_geog2, link_tutor_addresses.* FROM addresses "
		      		+ "INNER JOIN link_tutor_addresses ON addresses.id = link_tutor_addresses.id_address "
		      		+ "WHERE (link_tutor_addresses.id_tutor = " + result.get(0).get("id") + ") AND (addresses.id_addresstype = 1)";
		      result = getResultAsHash(sql);
		      if(result.size() >0){
		    	  data.put("tutor_address", result.get(0));
		      }
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: cannot get  tutor info for person id " + id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
		 return data;
	}
	
	/**
	 * Gets list of all title name
	 */
	public List<String[]> getAllPersonTitle() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from person_title_option order by title_phrase";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("title_phrase")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get title names.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all nationality names
	 */
	public List<String[]> getAllNationalities() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from lookup_nationalities order by nationality";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("nationality")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get nationality names.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all Religious name
	 */
	public List<String[]> getAllReligious() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from lookup_studenttype order by studenttype";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("studenttype")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get religious names.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/*
	 * Get list of reasons to join
	 */
	public List<String[]> getAllJoinReasons() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from lookup_reasons where reasontype='join' order by reason";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("reason")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get  reasons to join.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/*
	 * Get list of reasons to drop
	 */
	public List<String[]> getAllDropReasons() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from lookup_reasons where reasontype='drop' order by reason";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("reason")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get  reasons to join.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/*
	 * Get list of fundings
	 */
	public List<String[]> getAllFundingNames() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from lookup_fundingsources order by fundingname";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("fundingname")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get  fundings.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/*
	 * Get Student Funding By Student Id
	 */
	public List<LinkedHashMap<String, String>> getStudentFundingByStudentId(String id) throws Exception{
		ResultSet rs = null;
		 try {
		      String sql ="select * from link_student_funding where studentid=" + id;
		     return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		      throw new Exception("ERROR: cannot get  student fundings for student id " + id + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public void updateStudentFunding(Student student) throws Exception{
		try{
			String sql = "delete from link_student_funding where studentid=" + student.getPrimary_key_student_id();
			update(sql);
			List<String[]> funds = student.getFundings();
			for(int i=0; i<funds.size(); i++){
				String[] fund = funds.get(i);
			    if(fund[1] == null || fund[1].trim().equals("")){
			    	throw new Exception("ERROR: Funding amount is not defined.");
			    }
			}
			for(int i=0; i<funds.size(); i++){
				String[] fund = funds.get(i);
				sql = "insert into link_student_funding (studentid, fundingsource, fundingamount) VALUES (" + student.getPrimary_key_student_id() + "," + fund[0] + ", " + fund[1] + ")";
				//System.out.println("++" + sql);
				update(sql);
			}
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot update Student Funding with student id=" + student.getStudent_id() + ".\n" + e.getMessage());
			    }finally {
			       // closeResource(conn); //TA:TODO close connection?????
			    }
	}
	
	/**
	 * Gets list of all tutors for cohort: [0] - tutor_id, [1] - first and last name
	 */
	public List<String[]> getAllTutors(String cohort_id) throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "SELECT person.id as person_id, person.first_name, person.last_name, "
					+ "tutor.id as tutor_id, tutor.*, link_tutor_institution.*, cohort.* FROM person "
					+ "INNER JOIN tutor ON person.id = tutor.personid "
					+ "LEFT JOIN link_tutor_institution ON link_tutor_institution.id_tutor = tutor.id "
					+ "LEFT JOIN cohort ON link_tutor_institution.id_institution = cohort.institutionid or tutor.institutionid = cohort.institutionid "
					+ "WHERE (cohort.id = " + cohort_id + ") group by person.id ORDER BY person.last_name, person.first_name";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("tutor_id"), rs.getString("first_name") + " " + rs.getString("last_name")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get tutors names for cohort id=" + cohort_id + ".\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all facility names
	 */
	public List<String[]> getAllFacilities(boolean with_locations) throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select facility.id, facility.facility_name, l1.location_name as district_name, l2.location_name as zone_name from facility "
					+ "left join location as l1 on l1.id = facility.location_id "
					+ "left join location as l2 on l2.parent_id = l1.id "
					+ "order by facility.facility_name, l1.location_name, l2.location_name";
			//System.out.println(sql);
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					String location = "";
					if(with_locations){
						String connection = "";
						String district_name = rs.getString("district_name");
						if(district_name == null)
							district_name = "";
						String zone_name = rs.getString("zone_name");
						if(zone_name == null)
							zone_name = "";
						if(!district_name.equals("") && !zone_name.equals(""))
							connection = ", ";
						location = " (" + district_name + connection + zone_name + ")";
					}
					results.add(new String[]{ rs.getString("id"), rs.getString("facility_name") + location});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get facility names.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}

	
	/*
	 * Update person info
	 */
	public String addPerson(Person person, String person_type) throws Exception{
		ResultSet rs = null;
		String new_person_id = null;
		try{
			String sql = "INSERT INTO person (created_by, timestamp_created, title_option_id, first_name, middle_name,last_name, national_id, nationality_id,gender,birthdate, "
					+ "marital_status, spouse_name, home_address_1, home_address_2, home_city,home_postal_code, home_is_residential,"
					+ "phone_work, phone_mobile, phone_home, email, email_secondary, comments, custom_field1,custom_field2,custom_field3, facility_id, primary_qualification_option_id,"
					+ "timestamp_created, timestamp_updated) "
					+ "values "
					+ "("
					+ this.getUser_id() + ", '" + Utils.getCurrentDateTime() + "',"
					+ person.getTitle() + ",'" + person.getFirst_name() + "','" + person.getMiddle_name() + "','" + person.getLast_name() + "','"
					+ person.getNational_id() + "'," + person.getNationality() + ",'" + person.getGender() + "','" + Utils.getDate(person.getBirth_date()) + "','"
							+ person.getMarital_status() + "','" + person.getSpouse_name() + "','" + person.getAddress1() + "','" + person.getAddress2()  + "','"
							+ person.getCity() +  "','" + person.getPostal_code() +  "'," + String.valueOf(person.isHome_is_residential()==true?1:0) + ",'"
							+ person.getPhone()  + "','" + person.getCell_phone()  + "','" + person.getCell_phone2()  + "','" + person.getEmail()  + "','"
							+ person.getEmail2()  + "','" + person.getComments()  + "','" + person.getCustom_field1() + "','" + person.getCustom_field2()
							+ "','" + person.getCustom_field3() + "'," + person.getFacility_id() + ",0, '" + Utils.getCurrentDateTime() + "','" + Utils.getCurrentDateTime() + "')";
			//System.out.println(sql);
		update(sql);
		
		//get last person id
		sql = "select max(id) as last_id from person";
		rs = query(sql);
		if (rs != null) {
			while (rs.next()) {
				new_person_id = rs.getString("last_id");
				break;
			}
		}
		person.setPersonId(Integer.parseInt(new_person_id));
		
		if(person_type != null){
			if(person_type.equals(PersonEditPagePanel.__SELECT_NEW_PERSON_TYPE_STUDENT)){
				sql = "INSERT INTO student (personid, studentid, institutionid, comments, postaddress1, postfacilityname, hscomldate, lastinstatt, schoolstartdate, lastunivatt, "
						+ "personincharge, emergcontact, geog1, geog2) VALUES (" + 
						person.getPersonId() + "," + person.getPersonId() + "," + person.getStudent().getInst_id() + ",'', '', '', '', '', '', '', '', ''," + 
						"(CASE WHEN (select id from location where location_name='" + person.getStudent().getZone_name() + "' and tier=1) IS NULL THEN '0' ELSE (select id from location where location_name='" + person.getStudent().getZone_name() + "' and tier=1) END)," +
						"(CASE WHEN (select id from location where location_name='" + person.getStudent().getDistrict_name() + "' and tier=2) IS NULL THEN '0' ELSE (select id from location where location_name='" + person.getStudent().getDistrict_name() + "' and tier=2) END)" +
						")";
				//System.out.println(sql);
				update(sql);
			}else if(person_type.equals(PersonEditPagePanel.__SELECT_NEW_PERSON_TYPE_TUTOR)){
				sql = "INSERT INTO tutor (personid, degree, positionsheld, comments, specialty, contract_type, degreeinst, languagesspoken, positionsheld,"
						+ "specialty, contract_type) VALUES ("
						+ person.getPersonId() + ", 0, '', '', 0, 0, '', '', '', '', '')";
				update(sql);
			}
		}

		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot add person to database.\n" + e.getMessage());
		    }finally {
		    	closeResource(rs);
			       // closeResource(conn); //TA:TODO close connection?????
			    }
		return new_person_id;
	}
	
	public void updatePerson(Person person) throws Exception{
		try{
			String sql = "UPDATE person SET title_option_id='" + person.getTitle() + "',"
					+ " modified_by=" + this.getUser_id()
					+ ", timestamp_updated='" + Utils.getCurrentDateTime() + "',"
					+ "first_name='" + person.getFirst_name() + "',"
					+ "middle_name='" + person.getMiddle_name() + "',"
					+ "last_name='" + person.getLast_name() + "',"
					+ "national_id='" + person.getNational_id() + "',"
					+ "nationality_id='" + person.getNationality() + "',"
					+ "gender='" + person.getGender() + "',"
					+ "birthdate='" + Utils.getDate(person.getBirth_date()) + "',"
					+ "marital_status='" + person.getMarital_status() + "',"
					+ "spouse_name='" + person.getSpouse_name() + "',"
					+ "home_address_1='" + person.getAddress1() + "',"
					+ "home_address_2='" + person.getAddress2() + "',"
					+ "home_city='" + person.getCity() + "',"
					+ "home_postal_code='" + person.getPostal_code() + "',"
					+ "home_location_id=(CASE WHEN (select id from location where location_name='" + person.getHome_district_name() + "' and tier=2) IS NULL THEN '0' ELSE (select id from location where location_name='" + person.getHome_district_name() + "' and tier=2) END),"
					+ "home_is_residential='" + String.valueOf(person.isHome_is_residential()==true?1:0) + "',"
					+ "phone_work='" + person.getPhone() + "',"
					+ "phone_mobile='" + person.getCell_phone() + "',"
					+ "phone_home='" + person.getCell_phone2() + "',"
					+ "email='" + person.getEmail() + "',"
					+ "email_secondary='" + person.getEmail2() + "',"
					+ "comments='" + person.getComments() + "',"
					+ "custom_field1='" + person.getCustom_field1() + "',"
					+ "custom_field2='" + person.getCustom_field2() + "',"
					+ "custom_field3='" + person.getCustom_field3() + "',"
					+ "timestamp_updated='" + Utils.getCurrentDateTime() + "'"
					+ " where id=" + String.valueOf(person.getPersonId());
			update(sql);
		
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update person.\n" + e.getMessage());
		    }finally {
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public void updateStudent(Person person) throws Exception{
		try{
			updatePerson(person);
			if(person.getStudent() != null && person.getStudent().getStudent_id() != null){
				updateStudentDetails(person);
		}
		
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update student.\n" + e.getMessage());
		    }finally {
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	
	
	public void updateStudentDetails(Person person) throws Exception{
		try{
			Student student = person.getStudent();
			String sql = "UPDATE student SET isgraduated='" + String.valueOf(student.isGraduated()==true?1:0) + "',"
					+ " emergcontact='" + student.getEmergency_contact() + "',"
					+ " studenttype='" + student.getReligious() + "',"
					+ " geog1=(CASE WHEN (select id from location where location_name='" + student.getZone_name() + "' and tier=1) IS NULL THEN '0' ELSE (select id from location where location_name='" + student.getZone_name() + "' and tier=1) END),"
					+ " geog2=(CASE WHEN (select id from location where location_name='" + student.getDistrict_name() + "' and tier=2) IS NULL THEN '0' ELSE (select id from location where location_name='" + student.getDistrict_name() + "' and tier=2) END),"
					+ " cadre='" + student.getCadre() + "',"
					+ " advisorid='" + student.getAdvisor_id() + "',"
					+ " schoolstartdate='" + Utils.getDate(student.getStudent_hs_start_date()) + "',"
					+ " hscomldate='" + Utils.getDate(student.getStudent_hs_end_date()) + "',"
					+ " lastinstatt='" + student.getStudent_last_school() + "',"
					+ " lastunivatt='" + student.getStudent_last_univer() + "',"
					+ " personincharge='" + student.getStudent_person_in_charge() + "',"
					+ " equivalence='" + String.valueOf(student.isStudent_equival()==true?1:0) + "',"
					+ " postfacilityname='" + student.getAfter_grad_facility_name() + "',"
					+ " postgeo1=(CASE WHEN (select id from location where location_name='" + student.getAfter_grad_zone_name() + "' and tier=1) IS NULL THEN '0' ELSE (select id from location where location_name='" + student.getAfter_grad_zone_name() + "' and tier=1) END),"
					+ " postgeo2=(CASE WHEN (select id from location where location_name='" + student.getAfter_grad_district_name() + "' and tier=2) IS NULL THEN '0' ELSE (select id from location where location_name='" + student.getAfter_grad_district_name() + "' and tier=2) END) "
					+ " where personid=" + person.getPersonId();
			//System.out.println(sql);   
		update(sql);
		
		updateStudentAddressDetails(student);
		updateStudentCohortDetails(student);
		updateStudentFunding(student);
		
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update student details.\n" + e.getMessage());
		    }finally {
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public void updateStudentAddressDetails(Student student) throws Exception{
		ResultSet rs = null;
		try{
			if(student.getAddress_id() == 0){
				String sql = "INSERT INTO addresses (id_geog1, id_geog2, address1, address2, city, postalcode, id_addresstype, state, country) VALUES (" + 
						"(CASE WHEN (select id from location where location_name='" + student.getZone_name_perm() + "' and tier=1) IS NULL THEN '0' ELSE (select id from location where location_name='" + student.getZone_name_perm() + "' and tier=1) END),"
						+ "(CASE WHEN (select id from location where location_name='" + student.getDistrict_name_perm()+ "' and tier=2) IS NULL THEN '0' ELSE "
						+ "(select id from location where location_name='" + student.getDistrict_name_perm()+ "' and tier=2) END),'"		
						+ student.getAddress1_perm() + "','"
								+ student.getAddress2_perm() + "','"
								+ student.getCity_perm() +  "','"
								+ student.getPostal_code_perm() + "',1, 0, 0)";
				//System.out.println(sql);
				update(sql);
				//get last person id
				sql = "select max(id) as last_id from addresses";
				rs = query(sql);
				if (rs != null) {
					while (rs.next()) {
						String new_address_id = rs.getString("last_id");
						sql = "INSERT INTO link_student_addresses (id_student, id_address) VALUES ( " + student.getPrimary_key_student_id() + ","+ new_address_id+ ")";
						//System.out.println(sql);
						update(sql);
						break;
					}
				}
			}else{
				String sql = "UPDATE addresses SET "
						+ "id_geog1=(CASE WHEN (select id from location where location_name='" + student.getZone_name_perm() + "' and tier=1) IS NULL THEN '0' ELSE (select id from location where location_name='" + student.getZone_name_perm() + "' and tier=1) END),"
						+ "id_geog2=(CASE WHEN (select id from location where location_name='" + student.getDistrict_name_perm() + "' and tier=2) IS NULL THEN '0' ELSE (select id from location where location_name='" + student.getDistrict_name_perm() + "' and tier=2) END),"
						+ "address1='" + student.getAddress1_perm() + "',"
						+ "address2='" + student.getAddress2_perm() + "',"
						+ "city='" + student.getCity_perm() + "',"
						+ "postalcode='" + student.getPostal_code_perm() + "' "
						+ " where id=" + String.valueOf(student.getAddress_id());
				update(sql);
			}
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update student address details.\n" + e.getMessage());
		    }finally {
		    	closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public void updateStudentCohortDetails(Student student) throws Exception{
		ResultSet rs = null;
		try{
			//check if this cohort_student link exists
			String sql = "select id from link_student_cohort where id_student=" + student.getPrimary_key_student_id() + " and id_cohort=" + student.getCohort_id();
			//System.out.println(sql);
			rs = query(sql);
			String id = null;
			if (rs != null) {
				while (rs.next()) {
					id = rs.getString("id");
				}
			}
			Date student_join_date = student.getJoin_date();
			if(student_join_date == null){
				student.setJoin_date(Utils.getDate(Utils.getCurrentDate()));
			}
			if(id == null){
				//insert new record
				//first, clean up old records about student cohort link
				sql = "delete from link_student_cohort where id_student=" + student.getPrimary_key_student_id();
				update (sql);
				sql = "INSERT INTO link_student_cohort (id_student, id_cohort, joindate, joinreason, dropdate, dropreason) "
						+ "VALUES (" + student.getPrimary_key_student_id() + ", " + student.getCohort_id() + ", '" + Utils.getDate(student.getJoin_date()) + "','" + student.getJoinreason() + "','"
						+ Utils.getDate(student.getDrop_date()) + "','" + student.getDropreason() + "')";
				update (sql);
				//System.out.println(sql);
			}else{
				sql = "UPDATE link_student_cohort SET "
					+ "joindate='" + Utils.getDate(student.getJoin_date()) + "',"
					+ "joinreason='" + student.getJoinreason() + "',"
					+ "dropdate='" + Utils.getDate(student.getDrop_date()) + "',"
					+ "dropreason='" + student.getDropreason() + "' "
					+ " where id_student=" + student.getPrimary_key_student_id() + " and id_cohort=" + student.getCohort_id();
			update(sql);
			//System.out.println(sql);
			}
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update student cohort details.\n" + e.getMessage());
		    }finally {
		    	 closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get details about student class history
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getStudentClassHistory(Student student) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT classes.*, person.first_name, person.last_name, lookup_coursetype.coursetype, "
		      		+ "CASE WHEN sc.linkclasscohortid IS NULL THEN 0 ELSE sc.linkclasscohortid END linkid, "
		      		+ "CASE WHEN sc.classid IS NULL OR LENGTH(camark) = 0 OR camark IS NULL THEN '" + _EMPTY_VALUE_STRING + "' ELSE camark END camark, "
		      		+ "CASE WHEN sc.classid IS NULL OR LENGTH(exammark) = 0 OR exammark IS NULL THEN '" + _EMPTY_VALUE_STRING + "' ELSE exammark END exammark, "
		      		+ "CASE WHEN sc.classid IS NULL OR LENGTH(grade) = 0 OR grade IS NULL THEN '" + _EMPTY_VALUE_STRING + "' ELSE grade END grade, "
		      		+ "CASE WHEN sc.classid IS NULL OR LENGTH(credits) = 0 OR credits IS NULL THEN '" + _EMPTY_VALUE_STRING + "' ELSE credits END credits FROM classes "
		      		+ "LEFT JOIN link_cohorts_classes lcc ON lcc.classid = classes.id "
		      		+ "LEFT JOIN tutor ON tutor.id = classes.instructorid "
		      		+ "LEFT JOIN person ON tutor.personid = person.id "
		      		+ "LEFT JOIN lookup_coursetype ON lookup_coursetype.id = classes.coursetypeid "
		      		+ "LEFT JOIN ( SELECT classid, linkclasscohortid, camark, exammark, grade, credits FROM link_student_classes WHERE studentid =" +  student.getPrimary_key_student_id() + " AND "
		      		+ "classid IN (SELECT classid FROM link_cohorts_classes WHERE cohortid = " + student.getCohort_id() + ") ) AS sc ON sc.classid = classes.id "
		      				+ "WHERE lcc.cohortid = " +  student.getCohort_id()  
		      		+ " ORDER BY classes.classname, person.first_name, person.last_name";
		      //System.out.println(sql);
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get student class history for studenth id=" + student.getStudent_id() + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/*
	 * Update student class history
	 */
	public void updateStudentClassHistory(List<LinkedHashMap<String, String>> student_classes_to_update, Student student) throws Exception{
		ResultSet rs = null;
		try{
			for(int i=0; i<student_classes_to_update.size(); i++){
				//check if record exists
				String sql = "select id from link_student_classes where studentid=" + student.getPrimary_key_student_id() + " and classid=" + student_classes_to_update.get(i).get("class_id");
				rs = query(sql);
				String id = null;
				if (rs != null) {
					while (rs.next()) {
						id = rs.getString("id");
					}
				}
				String grade = student_classes_to_update.get(i).get("grade");
				if(grade == null || grade.trim().equals(_EMPTY_VALUE_STRING))
					grade = "";
				String credits = student_classes_to_update.get(i).get("credits");
				if(credits== null || credits.trim().equals(_EMPTY_VALUE_STRING))
					credits = "";
				String exammark = student_classes_to_update.get(i).get("exammark");
				if(exammark == null || exammark.trim().equals(_EMPTY_VALUE_STRING))
					exammark = "";
				String camark = student_classes_to_update.get(i).get("camark");
				if(camark == null || camark.trim().equals(_EMPTY_VALUE_STRING))
					camark = "";
				if(id == null){
					//insert new record
					sql = "INSERT INTO link_student_classes (studentid, classid, cohortid, grade, credits,exammark, camark) VALUES (" +
							student.getPrimary_key_student_id() + "," + student_classes_to_update.get(i).get("class_id") + "," + student.getCohort_id() + 
							",'" + grade + "','" +
							credits  + "','" +
							exammark  + "','" +
							camark  + "')";
				}else{
					sql = "UPDATE link_student_classes SET grade='" + grade + "', credits='" + credits + "', "
							+ "exammark='" + exammark + "', camark='" + camark + 
							"' where studentid=" + student.getPrimary_key_student_id() + " and classid=" + student_classes_to_update.get(i).get("class_id");
				}
				update(sql);
				//System.out.println(sql);
			}
			
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot update student class history for student id=" + student.getStudent_id() + ".\n" + e.getMessage());
			    }finally {
			    	closeResource(rs);
			       // closeResource(conn); //TA:TODO close connection?????
			    }
	}
	
	/**
	 * Get details about student clinical
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getStudentClinical(Student student) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT p.*, facility.facility_name, person.first_name, person.last_name, person.id AS personid, "
		      		+ "CASE WHEN sp.linkcohortpracticumid IS NULL THEN 0 ELSE sp.linkcohortpracticumid END linkid, "
		      		+ "CASE WHEN sp.practicumid IS NULL OR LENGTH(grade) = 0 OR grade IS NULL THEN '" + _EMPTY_VALUE_STRING + "' ELSE grade END grade, "
		      		+ "CASE WHEN sp.practicumid IS NULL OR LENGTH(hourscompleted) = 0 OR hourscompleted IS NULL THEN '" + _EMPTY_VALUE_STRING + "' ELSE hourscompleted END hourscompleted FROM practicum p "
		      		+ "LEFT JOIN facility ON facility.id = p.facilityid "
		      		+ "LEFT JOIN tutor ON tutor.id = p.advisorid "
		      		+ "LEFT JOIN person ON person.id = tutor.personid "
		      		+ "LEFT JOIN "
		      		+ "( SELECT practicumid, linkcohortpracticumid, grade, hourscompleted FROM link_student_practicums "
		      		+ "WHERE studentid = " + student.getPrimary_key_student_id() + " AND practicumid IN (SELECT id FROM practicum WHERE cohortid = " + student.getCohort_id() + ") ) AS sp ON sp.practicumid = p.id "
		      		+ "WHERE cohortid = " + student.getCohort_id() + " ORDER BY practicumdate DESC, practicumname";
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get student clinical allocation for studenth id=" + student.getStudent_id() + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/*
	 * Update student clinical allocation
	 */
	public void updateStudentClinical(List<LinkedHashMap<String, String>> student_clinical_to_update, Student student) throws Exception{
		ResultSet rs = null;
		try{
			for(int i=0; i<student_clinical_to_update.size(); i++){
				//check if record exists
				String sql = "select id from link_student_practicums where studentid=" + student.getPrimary_key_student_id() + " and practicumid=" + student_clinical_to_update.get(i).get("practicum_id");
				rs = query(sql);
				String id = null;
				if (rs != null) {
					while (rs.next()) {
						id = rs.getString("id");
					}
				}
				String grade = student_clinical_to_update.get(i).get("grade");
				if(grade == null || grade.trim().equals(_EMPTY_VALUE_STRING))
					grade = "";
				String hours_completed = student_clinical_to_update.get(i).get("hours_completed");
				if(hours_completed == null || hours_completed.trim().equals(_EMPTY_VALUE_STRING))
					hours_completed = "";
				if(id == null){
					//insert new record
					sql = "INSERT INTO link_student_practicums (studentid, practicumid, cohortid, grade, hourscompleted) VALUES (" +
							student.getPrimary_key_student_id() + "," + student_clinical_to_update.get(i).get("practicum_id") + "," + student.getCohort_id() + 
							",'" + grade + "','" +
							hours_completed  + "')";
				}else{
					sql = "UPDATE link_student_practicums SET grade='" + grade + "', hourscompleted='" + hours_completed + "' "
							+ " where studentid=" + student.getPrimary_key_student_id() + " and practicumid=" + student_clinical_to_update.get(i).get("practicum_id");
				}
				update(sql);
				//System.out.println(sql);
			}
			
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot update student clinical allocation for student id=" + student.getStudent_id() + ".\n" + e.getMessage());
			    }finally {
			    	closeResource(rs);
			       // closeResource(conn); //TA:TODO close connection?????
			    }
	}
	
	/**
	 * Get details about student Licenses
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getStudentLicenses(Student student) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT l.id, licensename, licensedate, "
		      		+ "CASE WHEN sl.linkclasslicenseid IS NULL THEN 0 ELSE sl.linkclasslicenseid END linkid, "
		      		+ "CASE WHEN sl.licenseid IS NULL OR LENGTH(grade) = 0 OR grade IS NULL THEN '" + _EMPTY_VALUE_STRING + "' ELSE grade END grade, "
		      		+ "CASE WHEN sl.licenseid IS NULL OR LENGTH(credits) = 0 OR credits IS NULL THEN '" + _EMPTY_VALUE_STRING + "' ELSE credits END credits FROM licenses l "
		      		+ "LEFT JOIN ( SELECT licenseid, linkclasslicenseid, grade, credits FROM link_student_licenses WHERE studentid = "+ student.getPrimary_key_student_id() + " AND licenseid "
		      		+ "IN (SELECT id FROM licenses WHERE cohortid = "+ student.getCohort_id() + ") ) AS sl ON sl.licenseid = l.id WHERE cohortid = "+ student.getCohort_id() + 
		      		" ORDER BY licensedate, licensename";
		      //System.out.println(sql);
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get student Licenses for studenth id=" + student.getStudent_id() + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/*
	 * Update student Licenses
	 */
	public void updateStudentLicenses(List<LinkedHashMap<String, String>> student_lic_to_update, Student student) throws Exception{
		ResultSet rs = null;
		try{
			for(int i=0; i<student_lic_to_update.size(); i++){
				//check if this cohort_student link exists
				String sql = "select id from link_student_licenses where studentid=" + student.getPrimary_key_student_id() + " and licenseid=" + student_lic_to_update.get(i).get("license_id");
				rs = query(sql);
				String id = null;
				if (rs != null) {
					while (rs.next()) {
						id = rs.getString("id");
					}
				}
				String grade = student_lic_to_update.get(i).get("grade");
				if(grade == null || grade.trim().equals(_EMPTY_VALUE_STRING))
					grade = "";
				if(id == null){
					//insert new record
					sql = "INSERT INTO link_student_licenses (studentid, licenseid, cohortid, linkclasslicenseid, grade, credits) "
							+ "VALUES (" + student.getPrimary_key_student_id() + ", " + student_lic_to_update.get(i).get("license_id") + "," + student.getCohort_id() + ", 0,'" + 
							grade + "','')";
				}else{
					sql = "UPDATE link_student_licenses SET grade='" + grade + "' "
					+ " where studentid=" + student.getPrimary_key_student_id() + " and licenseid=" + student_lic_to_update.get(i).get("license_id");
				}
				update(sql);
			}
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot update student Licenses for student id=" + student.getStudent_id() + ".\n" + e.getMessage());
			    }finally {
			    	closeResource(rs);
			       // closeResource(conn); //TA:TODO close connection?????
			    }
	}
	
	/**
	 * Gets list of all cohort names
	 */
	public List<String[]> getAllCohorts() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from cohort order by cohortname";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("cohortname")});
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get cohort names.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all tutor types 
	 */
	public List<String[]> getAllTutorTypes() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from lookup_tutortype order by typename";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("typename")});
					//System.out.println("ALL:" + rs.getString("id") + "->" + rs.getString("typename"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get tutor types.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all tutor types 
	 */
	public List<String[]> getTutorTypesForTutorId(Tutor tutor) throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "SELECT `t`.`id`, `t`.`typename` FROM `lookup_tutortype` AS `t` "
					+ "INNER JOIN `link_tutor_tutortype` AS `l` ON l.id_tutortype = t.id WHERE (t.status = 1) AND (l.id_tutor = " + tutor.getTutor_id() + ") ORDER BY `typename`;";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("typename")});
					//System.out.println("SEL:" + rs.getString("id") + "->" + rs.getString("typename"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get tutor types for tutor id " + tutor.getTutor_id() + ".\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all Languages 
	 */
	public List<String[]> getAllLanguages() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select * from lookup_languages order by language";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("language")});
					//System.out.println("ALL:" + rs.getString("id") + "->" + rs.getString("language"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get all Languages.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/**
	 * Gets list of all Languages for tutor 
	 */
	public List<String[]> getTutorLanguages(Tutor tutor) throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select link_tutor_languages.*, lookup_languages.language from link_tutor_languages "
					+ "left join lookup_languages on lookup_languages.id=link_tutor_languages.id_language where id_tutor=" + tutor.getTutor_id();
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id_language"), rs.getString("language")});
					//System.out.println("ALL:" + rs.getString("id") + "->" + rs.getString("language"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get all Languages for tutor with id: " + tutor.getTutor_id() + ".\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	/*
	 * Update tutor info
	 */
	public void updateTutor(Person person) throws Exception{
		try{
			updatePerson(person);
			
			if(person.getTutor() != null && person.getTutor().getTutor_id() != 0){
				String sql ="UPDATE tutor set "+
						"facilityid='" + person.getTutor().getFacility_id() + "', " +
						"institutionid='" + person.getTutor().getInst_id() + "', " +
						"tutorsince='" + person.getTutor().getTutor_since() + "', " +
						"tutortimehere='" + person.getTutor().getTutor_time_here() + "', " +
						"degree='" + person.getTutor().getDegree_id() + "', " +
						"degreeyear='" + person.getTutor().getDegree_year() + "', " +
						"positionsheld='" + person.getTutor().getPositionsheld() + "', " +
						"comments='" + person.getComments() + "', " +
						"degreeinst='" + person.getTutor().getDegree_inst() + "' where personid=" + person.getPersonId();
						update(sql);
						//System.out.println(sql);
						
				updateTutorLanguages(person.getTutor());
				updateTutorTypes(person.getTutor());
				updateTutorInstitution(person.getTutor());
			}
		
		}catch ( Exception e ) {
			e.getStackTrace();
		      throw new Exception("ERROR: Cannot update tutor details.\n" + e.getMessage());
		    }finally {
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/*
	 * Update tutor languages
	 */
	public void updateTutorLanguages(Tutor tutor) throws Exception{
		try{
			String sql = "delete from link_tutor_languages where id_tutor=" + tutor.getTutor_id();
			update(sql);
			List<String> langs = tutor.getLanguages();
			for(int i=0; i<langs.size(); i++){
				sql = "insert into link_tutor_languages (id_tutor, id_language) VALUES (" + tutor.getTutor_id() + "," + langs.get(i) + ")";
				//System.out.println(sql);
				update(sql);
			}
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot update tutor languages with tutor id=" + tutor.getTutor_id() + ".\n" + e.getMessage());
			    }finally {
			       // closeResource(conn); //TA:TODO close connection?????
			    }
	}
	
	/*
	 * Update tutor institution
	 */
	public void updateTutorInstitution(Tutor tutor) throws Exception{
		try{
			String sql = "delete from link_tutor_institution where id_tutor=" + tutor.getTutor_id();
			update(sql);
			sql = "insert into link_tutor_institution (id_tutor, id_institution) VALUES (" + tutor.getTutor_id() + "," + tutor.getInst_id() + ")";
			//System.out.println(sql);
			update(sql);
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot update tutor institution with tutor id=" + tutor.getTutor_id() + ".\n" + e.getMessage());
			    }finally {
			       // closeResource(conn); //TA:TODO close connection?????
			    }
	}
	
	/*
	 * Update tutor types
	 */
	public void updateTutorTypes(Tutor tutor) throws Exception{
		try{
			String sql = "delete from link_tutor_tutortype where id_tutor=" + tutor.getTutor_id();
			update(sql);
			List<String> types = tutor.getTypes();
			for(int i=0; i<types.size(); i++){
				sql = "insert into link_tutor_tutortype (id_tutor, id_tutortype) VALUES (" + tutor.getTutor_id() + "," + types.get(i) + ")";
				//System.out.println(sql);
				update(sql);
			}
			}catch ( Exception e ) {
				e.getStackTrace();
			      throw new Exception("ERROR: Cannot update tutor types with tutor id=" + tutor.getTutor_id() + ".\n" + e.getMessage());
			    }finally {
			       // closeResource(conn); //TA:TODO close connection?????
			    }
	}
	
	/**
	 * Gets list of all institutions
	 */
	public List<String[]> getAllInstitutions() throws Exception{
		List<String[]> results = new ArrayList<String[]>();
		ResultSet rs = null;
		try {
			String sql = "select id, institutionname from institution order by institutionname";
			rs = query(sql);
			if (rs != null) {
				while (rs.next()) {
					results.add(new String[]{ rs.getString("id"), rs.getString("institutionname")});
					//System.out.println("SEL:" + rs.getString("id") + "->" + rs.getString("institutionname"));
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("ERROR: cannot get all institutions.\n" + e.getMessage());
		} finally {
			closeResource(rs);
			// closeResource(conn); //TA:TODO close connection?????
		}
		return results;
	}
	
	
	
	/**
	 * Get list of students for tutor
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getTutorStudents(Tutor tutor) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT `s`.`id`, `p2`.`first_name`, `p2`.`last_name` FROM `student` AS `s` "
		      		+ "INNER JOIN `tutor` AS `t` ON s.advisorid = t.id "
		      		+ "INNER JOIN `person` AS `p2` ON s.personid = p2.id "
		      		+ "WHERE (s.isgraduated = 0) AND (t.id = " + tutor.getTutor_id() + ") ORDER BY `first_name` ASC";
		      System.out.println(sql);
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get list of Students Advised by tutor with id=" + tutor.getTutor_id() + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	/**
	 * Get list of courses for tutor
	 * @return
	 */
	public List<LinkedHashMap<String, String>> getTutorCourses(Tutor tutor) throws Exception{
		 ResultSet rs = null;
		 try {
		      String sql ="SELECT * FROM classes "
		      		+ "LEFT JOIN link_cohorts_classes ON link_cohorts_classes.classid = classes.id "
		      		+ "LEFT JOIN cohort ON cohort.id = link_cohorts_classes.cohortid "
		      		+ "LEFT JOIN lookup_coursetype ON classes.coursetypeid = lookup_coursetype.id "
		      		+ "WHERE instructorid = (SELECT id FROM tutor WHERE id = " + tutor.getTutor_id() + ")";
		     // System.out.println(sql);
		      return getResultAsHash(sql);
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: Cannot get list of courses for tutor with id=" + tutor.getTutor_id() + ".\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
	}
	
	public LinkedHashMap<String, String> getLocationNamesByDistrictId(String id) throws Exception{
		ResultSet rs = null;
		 try {
		      String sql ="select location.location_name as district_name, loc_zone.location_name as zone_name from location "
		      		+ "left join location as loc_zone ON location.parent_id = loc_zone.id "
		      		+ "where location.id=" + id + " and location.tier=2";
		      List<LinkedHashMap<String, String>> result = getResultAsHash(sql);
		      //System.out.println(sql);
		      if(result.size() >0){
		    	  return result.get(0);
		      }
		    } catch ( Exception e ) {
		    	e.getStackTrace();
		    	throw new Exception("ERROR: cannot get  Location Names By District id '" + id + "'.\n" + e.getMessage());
		    }finally {
		        closeResource(rs);
		       // closeResource(conn); //TA:TODO close connection?????
		    }
		 return null;
	}
	
	/*
	 * Get student details by person id
	 */
	public LinkedHashMap<String, String> getGUILabels() throws Exception{
		  LinkedHashMap<String, String> results = new LinkedHashMap<String, String>();
		   ResultSet rs = null;
		   try{
		   rs = query("SELECT key_phrase, phrase from translation where is_deleted=0");
		   if(rs != null){
			   while(rs.next()) {
				   results.put(rs.getString("key_phrase"), rs.getString("phrase"));
			   }
		   }
		   }catch ( Exception e ) {
			   e.getStackTrace();
			      throw new Exception("Cannot get GUI lables from 'translation' table.\n" + e.getMessage());
			    }finally {
			        closeResource(rs);
			       // closeResource(conn); //TA:TODO close connection?????
			    }
		   return results;
	   }
	
	public static void  main(String[] args){
		/*
		 * Test case
		 */
//		List<LinkedHashMap<String, String>> results = SQLiteDB.getDBConn().getInstituteWithCohortAndStudentCount();
//		for(int i=0; i<results.size(); i++){
//	    	  System.out.println(results.get(i).get("inst_id") + ", " + results.get(i).get("institutionname") + ", " +  
//	    			  results.get(i).get("cohortname") + ", " + results.get(i).get("cohort_student_count"));
//	      }
		
		try{
			
			  Date date1 = Utils.getDate(Utils.getCurrentDate());
			  Date date2 = Utils.getDate("1971-05-22");
			      SimpleDateFormat simpleDateformat=new SimpleDateFormat("yyyy");
			      System.out.println(Integer.parseInt(simpleDateformat.format(date1))- Integer.parseInt(simpleDateformat.format(date2)));

			    
		
	}catch(Exception e){
		e.printStackTrace();
		  
		
		
	}
	}
}
