package ts.config;

import java.awt.Color;
import java.awt.Font;

public class Config {
	
	// styles
	public static final Color __MAIN_BG_COLOR = new Color(54, 105, 170);
	public static final String __MAIN_FONT_FAMILIY = "Verdana";
	public static final Color __BANNER_BG_COLOR = new Color(108, 182, 71);
	public static final Color __BANNER_TITLE_BG_COLOR = new Color(81, 150, 91);
	public static final Color __BANNER_FONT_COLOR = new Color(153, 204, 126);
	public static final Color __TABLE_SELECTION_BG_COLOR = new Color(204, 204, 204);
	public static final Font __FORM_TITLE_FONT = new Font(__MAIN_FONT_FAMILIY, Font.PLAIN, 18);
	public static final Font __TABLE_HEADER_FONT = new Font(__MAIN_FONT_FAMILIY, Font.BOLD, 12);
	
	//app login
	public static final String __APP_PASSWORD = "mango";
	
	//database
//	public static final String __DB_PATH = "src/ts/data/itechweb_malawipreservice.current.sqlite";
	//public static final String __DB_PATH = "./data/trainsmart.active.sqlite";
	public static final String __DB_PATH = "./data/";
	public static final String __DB_FILE = "trainsmart.active.sqlite";
	
	

}
